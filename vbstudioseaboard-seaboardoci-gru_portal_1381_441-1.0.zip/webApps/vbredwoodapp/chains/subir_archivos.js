define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class subir_archivos extends ActionChain {

    /**
     * Sube una lista de adjuntos a jde o a object storage según se indique.
     * @param {Object} context
     * @param {Object} params
     * @param {archivoAdjunto[]} params.inParamListaArchivos 
     * @param {inParamListaArchivos} params.inParamRequestSubirAdjunto 
     * @param {boolean} params.inParamAdjunto flag que indica si se sube como inParamAdjunto a JDE o se sube como archivo a object storage
     * @return {boolean} 
     */
    async run(context, { inParamListaArchivos, inParamRequestSubirAdjunto, inParamAdjunto = true }) {
      const { $application } = context;
      let errores = [];
      let error = false;
      const results = await ActionUtils.forEach(inParamListaArchivos, async (item, index) => {
        if (inParamAdjunto === true) {

          const response = await Actions.callRest(context, {
            endpoint: 'GatewayPortal/postQ71PO_SubirAdjunto',
            body: {
              numeroProveedor: inParamRequestSubirAdjunto.numeroProveedor === undefined ? '' : inParamRequestSubirAdjunto.numeroProveedor,
              tipoObjeto: inParamRequestSubirAdjunto.tipoObjeto === undefined ? '' : inParamRequestSubirAdjunto.tipoObjeto,
              ciaDocumento: inParamRequestSubirAdjunto.ciaDocumento === undefined ? '' : inParamRequestSubirAdjunto.ciaDocumento,
              tipoDocumento: inParamRequestSubirAdjunto.tipoDocumento === undefined ? '' : inParamRequestSubirAdjunto.tipoDocumento,
              nroDocumento: inParamRequestSubirAdjunto.nroDocumento === undefined ? '' : inParamRequestSubirAdjunto.nroDocumento,
              itemPagoDocumento: inParamRequestSubirAdjunto.itemPagoDocumento === undefined ? '' : inParamRequestSubirAdjunto.itemPagoDocumento,
              nroLinea: inParamRequestSubirAdjunto.nroLinea === undefined ? '' : inParamRequestSubirAdjunto.nroLinea,
              depositoPlanif: inParamRequestSubirAdjunto.depositoPlanif === undefined ? '' : inParamRequestSubirAdjunto.depositoPlanif,
              nroCarga: inParamRequestSubirAdjunto.nroCarga === undefined ? '' : inParamRequestSubirAdjunto.nroCarga,
              idUnicoTareaWorkflow: inParamRequestSubirAdjunto.idUnicoTareaWorkflow === undefined ? '' : inParamRequestSubirAdjunto.idUnicoTareaWorkflow,
              incluirMetadatos: inParamRequestSubirAdjunto.incluirMetadatos === undefined ? false : inParamRequestSubirAdjunto.incluirMetadatos,
              metadatos: {
                estadoObjeto: inParamRequestSubirAdjunto.metadatos.estadoObjeto === undefined ? '' : inParamRequestSubirAdjunto.metadatos.estadoObjeto,
                codigosCategoria: inParamRequestSubirAdjunto.metadatos.codigosCategoria === undefined ? [] : inParamRequestSubirAdjunto.metadatos.codigosCategoria,
                fechaVigenciaDesde: inParamRequestSubirAdjunto.metadatos.fechaVigenciaDesde === undefined ? '' : inParamRequestSubirAdjunto.metadatos.fechaVigenciaDesde,
                fechaVigenciaHasta: inParamRequestSubirAdjunto.metadatos.fechaVigenciaHasta === undefined ? '' : inParamRequestSubirAdjunto.metadatos.fechaVigenciaHasta,
                nroVehiculo: inParamRequestSubirAdjunto.metadatos.nroVehiculo === undefined ? '' : inParamRequestSubirAdjunto.metadatos.nroVehiculo,
                descripcion: inParamRequestSubirAdjunto.metadatos.descripcion === undefined ? '' : inParamRequestSubirAdjunto.metadatos.descripcion,
                mokey: inParamRequestSubirAdjunto.metadatos.mokey === undefined ? '' : inParamRequestSubirAdjunto.metadatos.mokey
              },
              archivo: item.archivo,
              nombreArchivo: item.nombreArchivo,
              tipoAdjunto: item.tipoAdjunto,
              token: $application.variables.token
            }
          });

          await Actions.callChain(context, {
            chain: 'verificar_respuesta_jdeError',
            params: {
              error: !response.ok,
              funcion: 'SubirAdjunto',
              tokenExpirado: response.body.tokenExpirado,
              transaccion: item.nombreArchivo,
              status: response.status,
            },
          });

          if (response.ok === false || response.body.success === false) {

            if (typeof response.body.errorsList !== 'undefined') {

              errores.push(response.body.errorsList);
            }

            error = true;
          }

          const guardarLog = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              funcionalidad: 'SUBIR_ARCHIVO',
              accion: 'SUBIR',
              pagina: $application.currentPage.id,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
              roles: $application.variables.userRoles.userRolesSt,
              transaccion: item.nombreArchivo + " - " + (inParamRequestSubirAdjunto.metadatos.mokey === undefined ? '' : inParamRequestSubirAdjunto.metadatos.mokey.replaceAll('|', '-')),
              observaciones: error ? 'FAILED' : 'SUCCESS',
            },
          });

        } else {
          let nombreArchivo = inParamListaArchivos[0].nombreArchivo;
          let parts = nombreArchivo.split('.');
          let extensionTest = parts.length > 1 ? parts.pop() : '';
          let extension = "." + extensionTest;
          const response2 = await Actions.callRest(context, {
            endpoint: 'GatewayPortal/postQ71PO_SubirArchivo',
            body: {
              //bucketName: "suscriptor-" + $application.variables.suscriptor.id,
              bucketName: $application.variables.suscriptor.objectStorageBucket,
              objectName: inParamRequestSubirAdjunto.nombreArchivo + extension,
              fileContent: item.archivo,
            },
          });
          await Actions.callChain(context, {
            chain: 'verificar_respuesta_jdeError',
            params: {
              error: !response2.ok,
              funcion: 'SubirAdjunto',
              tokenExpirado: response2.body.tokenExpirado,
              transaccion: item.nombreArchivo,
              status: response2.status,
            },
          });

          if (response2.ok === true) {
            const notificarError2 = await Actions.callChain(context, {
              chain: 'notificar_error',
              params: {
                codigo: 'exito-subir-archivo',
              },
            });
          } else {
            const notificarError3 = await Actions.callChain(context, {
              chain: 'notificar_error',
              params: {
                codigo: 'error-subir-archivo',
              },
            });

            error = true;
          }

          const guardarLog2 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              funcionalidad: 'SUBIR_ARCHIVO',
              accion: 'SUBIR',
              pagina: $application.currentPage.id,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
              roles: $application.variables.userRoles.userRolesSt,
              transaccion: inParamRequestSubirAdjunto.nombreArchivo + extension + " - " + (inParamRequestSubirAdjunto.metadatos.mokey === undefined ? '' : inParamRequestSubirAdjunto.metadatos.mokey.replaceAll('|', '-')),
              observaciones: error ? 'FAILED' : 'SUCCESS',
            },
          });

        }
      }, { mode: 'serial' });
      if (error) {
        const notificarError = await Actions.callChain(context, {
          chain: 'notificar_error',
          params: {
            codigo: 'subir-adjunto-error',
          },
        });
      }
      else {
        if (inParamListaArchivos.length > 0) {

          const notificarError = await Actions.callChain(context, {
            chain: 'notificar_error',
            params: {
              codigo: 'subir-adjunto-ok',
              modoVisualizacion: '',
            },
          });
        }
      }

      return { error: error, errores: errores };
    }
  }

  return subir_archivos;
});
