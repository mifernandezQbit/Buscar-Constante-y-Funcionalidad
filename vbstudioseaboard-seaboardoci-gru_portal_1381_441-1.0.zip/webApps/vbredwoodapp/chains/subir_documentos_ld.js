define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class subir_documentos_ld extends ActionChain {

    /**
     * Sube una lista de documentos al libro de direcciones. Estos documentos conforman el legajo del proveedor.
     * @param {Object} context
     * @param {Object} params
     * @param {inParamListaArchivos[]} params.inParamListaDocumentosLD 
     * @return {boolean} 
     */
    async run(context, {  inParamListaDocumentosLD }) {
      const { $application, $variables } = context;
let errores = [];
      let error = false;
      const results = await ActionUtils.forEach(inParamListaDocumentosLD, async (item, index) => {

          const response = await Actions.callRest(context, {
            endpoint: 'GatewayPortal/postQ71PO_SubirAdjunto',
            body: {
    numeroProveedor: item.numeroProveedor === undefined ? '' : item.numeroProveedor,
    tipoObjeto: item.tipoObjeto === undefined ? '' : item.tipoObjeto,
    ciaDocumento: item.ciaDocumento === undefined ? '' : item.ciaDocumento,
    tipoDocumento: item.tipoDocumento === undefined ? '' : item.tipoDocumento,
    nroDocumento: item.nroDocumento === undefined ? '' : item.nroDocumento,
    itemPagoDocumento: item.itemPagoDocumento === undefined ? '' : item.itemPagoDocumento,
    nroLinea: item.nroLinea === undefined ? '' : item.nroLinea,
    depositoPlanif: item.depositoPlanif === undefined ? '' : item.depositoPlanif,
    nroCarga: item.nroCarga === undefined ? '' : item.nroCarga,
    incluirMetadatos: item.incluirMetadatos === undefined ? false : item.incluirMetadatos,
    metadatos: {
        estadoObjeto: item.metadatos.estadoObjeto === undefined ? '' : item.metadatos.estadoObjeto,
        codigosCategoria: item.metadatos.codigosCategoria === undefined ? [] : item.metadatos.codigosCategoria,
        fechaVigenciaDesde: item.metadatos.fechaVigenciaDesde === undefined ? '' : item.metadatos.fechaVigenciaDesde,
        fechaVigenciaHasta: item.metadatos.fechaVigenciaHasta === undefined ? '' : item.metadatos.fechaVigenciaHasta,
        nroVehiculo: item.metadatos.nroVehiculo === undefined ? '' : item.metadatos.nroVehiculo,
        descripcion: item.metadatos.descripcion === undefined ? '' : item.metadatos.descripcion,
        mokey: item.metadatos.mokey === undefined ? '' : item.metadatos.mokey
    },
    archivo: item.archivo,
    nombreArchivo: item.nombreArchivo,
    tipoAdjunto: item.tipoAdjunto,
    token: $application.variables.token
}
          });

        await Actions.callChain(context, {
          chain: 'verificar_respuesta_jdeError',
          params: {
            error: !response.ok,
            funcion: 'SubirAdjunto',
            funcionalidad: $variables.funcionalidad,
            observaciones: 'Subir documentos proveedor',
            transaccion: item.numeroProveedor,
            tokenExpirado: response.tokenExpirado !== undefined ? response.tokenExpirado : false,
         status:response.status,
          },
        });

          if (response.ok === false || response.body.success === false) {

            if (typeof response.body.errorsList !== 'undefined') {

errores.push(response.body.errorsList);
            }

          error = true;

           // GUARDAR entrada en tabla log
			   await Actions.callChain(context, {
					chain: 'application:guardar_log',
					params: {
					  accion: 'SUBIR_ERROR',
					  suscriptorId: $application.variables.suscriptor.id,
					  numeroAn8: $application.variables.user.numeroAn8,
					  proveedor: $application.variables.user.esProveedor,
					  pagina: $application.currentPage.id,
					  roles: $application.variables.userRoles.userRolesSt,
					  usuario: $application.variables.user.ociUser,
					  funcionalidad: "SUBIR_DOCUMENTOS",
					  transaccion: item.nombreArchivo,
            observaciones:item.metadatos.mokey !=null ? item.metadatos.mokey :"",
					},
				  });


          }
          else {
                       // GUARDAR entrada en tabla log
			   await Actions.callChain(context, {
					chain: 'application:guardar_log',
					params: {
					  accion: 'SUBIR_OK',
					  suscriptorId: $application.variables.suscriptor.id,
					  numeroAn8: $application.variables.user.numeroAn8,
					  proveedor: $application.variables.user.esProveedor,
					  pagina: $application.currentPage.id,
					  roles: $application.variables.userRoles.userRolesSt,
					  usuario: $application.variables.user.ociUser,
					  funcionalidad: "SUBIR_DOCUMENTOS",
					  transaccion: item.nombreArchivo,
            observaciones:item.metadatos.mokey !=null ? item.metadatos.mokey :"",
					},
				  });
          }

      }, { mode: 'serial' });
      if (error) {
        const notificarError = await Actions.callChain(context, {
          chain: 'notificar_error',
          params: {
            codigo: 'subir-adjunto-error',
          },
        });
      }
      else {
         const notificarError = await Actions.callChain(context, {
           chain: 'notificar_error',
           params: {
             codigo: 'subir-adjunto-ok',
             modoVisualizacion: '',
           },
         });
      }

      return {error:error,errores:errores};
    }
  }

  return subir_documentos_ld;
});
