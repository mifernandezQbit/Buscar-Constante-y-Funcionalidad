define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class buscar_constante extends ActionChain {

    /**
     * Busca una constante y retorna su valor
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.constante Valor a buscar
     * @return {constanteEncontrada} 
     */
    async run(context, { constante }) {
      const { $application } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_Constante',
        uriParams: {
          q: "suscriptorID='" + $application.variables.suscriptor.id + "' and clave='" + constante + "'",
        },
      });

      if (response.ok === true && response.body.count !==0) {
        return {
  clave: response.body.items[0].clave,
  valor: response.body.items[0].valor,
  existe: true,
constanteId:response.body.items[0].id
};
      } else {
          return {
  clave: constante,
  valor: '',
  existe: false,
constanteId:null
};
      }
    }
  }

  return buscar_constante;
});
