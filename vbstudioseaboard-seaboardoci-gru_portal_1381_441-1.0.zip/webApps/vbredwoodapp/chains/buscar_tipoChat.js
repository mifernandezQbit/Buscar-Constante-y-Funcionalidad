define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
)  => {
  'use strict';

  class buscar_tipoChat extends ActionChain {

    /**
     * Si se informa el ID, busca el código, si se informa el código busca el ID
     * @param {Object} context
     * @param {Object} params
     * @param {number} params.tipoChatID ID del tipo de chat
     * @param {string} params.tipoObjetoChat Código hard coded a buscar o recuperar
     */
    async run(context, { tipoChatID = 0, tipoObjetoChat='' }) {
      const { $application, $constants, $variables } = context;

 let tipoChat = {
  tipoChatID: tipoChatID,
  tipoObjetoChat : tipoObjetoChat
 };
      // si se informa ID, buscar codigo
      if (tipoChatID !==0) {

        const response = await Actions.callRest(context, {
          endpoint: 'businessObjects/get_TipoChat',
        });
if (response.ok === true) {
  tipoChat.tipoObjetoChat = response.body.tipoObjetoChat;
} else {
          const notificarError = await Actions.callChain(context, {
            chain: 'notificar_error',
            params: {
              codigo: 'falta-configuracion-mensajes',
            },
          });

}
        
      } else {
        // busco  por cóidigo y devuelvo ID

        const response2 = await Actions.callRest(context, {
          endpoint: 'businessObjects/getall_TipoChat',
                  uriParams: {
            q: "suscriptorID = '" + $application.variables.suscriptor.id + "' and  tipoObjetoChat= '" + tipoObjetoChat + "'"
          },
        });

        if (response2.ok && response2.body.items.length >0) {
           tipoChat.tipoChatID = response2.body.items[0].id;
        } else {
          const notificarError2 = await Actions.callChain(context, {
            chain: 'notificar_error',
            params: {
              codigo: 'falta-configuracion-mensajes',
            },
          });
        }
        

      }

      return tipoChat;
    }
  }

  return buscar_tipoChat;
});
