define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class userFunctionalityListListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:postQ71PO_ObtenerPermisosFuncionalidad[],value:postQ71PO_ObtenerPermisosFuncionalidad[]}} params.event
     */
    async run(context, { event }) {
      const { $application, $constants, $variables } = context;


      if ($variables.userFunctionalityList.length >0) {
      const verificarPermisosFuncionalidadObj = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: "CHAT_SOPORTE",
        },
      });

      const verificarPermisosFuncionalidadObj2 = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: "CENTRO_DE_NOTIFICACIONES",
        },
      });
      
      const verificarPermisosFuncionalidadObjGuiaUsoPortal = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: "VISUALIZAR_GUIA_USO_PORTAL",
        },
      });

      $application.variables.permisoCentroMsg = verificarPermisosFuncionalidadObj2.existe;
      $application.variables.permisoSoporte = verificarPermisosFuncionalidadObj.existe;

      $application.variables.permisoGuiaUsoPortal = verificarPermisosFuncionalidadObjGuiaUsoPortal.existe;

    }
    }
  }

  return userFunctionalityListListener;
});
