define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class guardarMensaje extends ActionChain {

    /**
     * Guarda mensaje en la tabla y envia mail
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.nroProveedor 
     * @param {any} params.tipoObjetoChat 
     * @param {any} params.nroDocumento 
     * @param {string} params.tipoDocumento 
     * @param {any} params.ciaDocumento 
     * @param {any} params.sfxDocumento 
     * @param {any} params.depositoPlanif 
     * @param {any} params.nroCarga 
     * @param {any} params.tipoUsuario 
     * @param {any} params.usuarioPortal 
     * @param {any} params.rolInterlocutorID 
     * @param {any} params.destinatario 
     * @param {any} params.remitente 
     * @param {boolean} params.esProveedor 
     * @param {any} params.mensaje 
     * @param {any} params.suscriptorID 
     * @param {any} params.nroTransaccion 
     */
    async run(context, { nroProveedor, tipoObjetoChat, nroDocumento, tipoDocumento, ciaDocumento, sfxDocumento, depositoPlanif, nroCarga, tipoUsuario, usuarioPortal, rolInterlocutorID, destinatario, remitente, esProveedor, mensaje, suscriptorID, nroTransaccion }) {
      const { $fragment, $application, $page } = context;

      let titulo = '';
      let supplierNbr = '';
      let supplierName = '';

      if (esProveedor === true) {
        titulo = "Mail para Proveedor - " + $fragment.variables.nroTransaccionFormateado;
        supplierName = $application.variables.infoProveedor.alphaName;
        supplierNbr = $application.variables.infoProveedor.addressNumber;
      } else {
        // Falta agregar los supplier cuando el usuario no es proveedor
        titulo = "Mail para Usuario - " + $fragment.variables.nroTransaccionFormateado;
      }

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/create_Mensaje',
        tipoObjetoChat: tipoObjetoChat,
        tipoUsuario: tipoUsuario,
        usuarioPortal: usuarioPortal,
        rolInterlocutorID: rolInterlocutorID,
        destinatario: destinatario,
        body: {
          nroProveedor: nroProveedor,
          tipoObjetoChat: tipoObjetoChat,
          usuarioPortal: usuarioPortal,
          rolInterlocutorID: rolInterlocutorID,
          mensaje: mensaje,
          destinatario: destinatario,
          tipoUsuario: tipoUsuario,
          suscriptorID: suscriptorID,
          nuevoMensaje: true,
          nroTransaccion: nroTransaccion,
        },
      });

      await Actions.resetVariables(context, {
        variables: [
    '$fragment.variables.mensajeNuevo',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$fragment.variables.destinatarioSeleccionado',
  ],
      });

      if (response.status === 200) {
        const guardarLog = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'INGRESA',
            funcionalidad: $fragment.variables.funcionalidad,
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $fragment.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
          },
        });
        // Guarda mensaje en la tabla y envia mail
        await Actions.callChain(context, {
          chain: 'application:enviar_mail',
          params: {
            body: mensaje,
            mailTo: destinatario,
            authorName: $application.variables.user.nombre,
            notificationType: '002',
            companyDesc: $application.variables.selectedCompany.name,
            subject: titulo,
          },
        });

        return true;
      } else {
        return false;
      }
    }
  }

  return guardarMensaje;
});
