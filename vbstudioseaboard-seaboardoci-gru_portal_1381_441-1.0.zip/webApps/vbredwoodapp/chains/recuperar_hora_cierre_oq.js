define([
        'vb/action/actionChain',
        'vb/action/actions',
        'vb/action/actionUtils',
    ], (
        ActionChain,
        Actions,
        ActionUtils) => {
    'use strict';

    class recuperar_hora_cierre_oq extends ActionChain {

        /**
         * Buscar para una OQ determinada la fecha y hora de cierre.
         * @param {Object} context
         * @param {Object} params
         * @param {string} params.parTipoOrden
         * @param {string} params.parNroOrden
         * @param {string} params.parCiaOrden
         * @param {string} params.parNroProveedor
         * @param {string} params.parP4334_Version
         * @return {object}
         */
        async run(context, {
            parTipoOrden,
            parNroOrden,
            parCiaOrden,
            parNroProveedor,
            parP4334_Version
        }) {
            const {
                $application,
                $constants,
                $variables
            } = context;

            // inicializo objeto para respuesta
            let datos = {
                fechaRequerida: "",
                horaCierre: ""
            };
            // buscar cotización
            const response = await Actions.callRest(context, {
                endpoint: 'GatewayPortal/postQ71PO_ConsultaLicitaciones',
                body: {
                    "token": $application.variables.token,
                    "Prov": parNroProveedor,
                    "P4334_Version": parP4334_Version,
                    "orderCompany": parCiaOrden,
                    "nOrden": parNroOrden,
                    "orderType": parTipoOrden,
                    "fechaRequerida": "",
                    "fechaResp": "",
                    "VerLicitaciones": "T"
            }
        });


      await Actions.callChain(context, {
        chain: 'verificar_respuesta_jdeError',
        params: {
          error: !response.ok,
          funcion: 'ConsultaLicitaciones',
          funcionalidad: $variables.funcionalidad,
          observaciones: 'recuperar_hora_cierre_oq',
          tokenExpirado: response.body.message.tokenExpirado,
          transaccion: parNroProveedor + " - " +parTipoOrden+" - "+parNroOrden+" - " + parCiaOrden,
       status:response.status,
        },
      });
        

        if (response.ok && !response.body.message.errorJde && response.body.message.rowset.length > 0) {
            // tomo fecha y hora de cierre y devuelvo esa inforamción
            datos.fechaRequerida = response.body.message.rowset[0].fechaRequerida !== undefined ? response.body.message.rowset[0].fechaRequerida : "2000-01-01";
        let hora= response.body.message.rowset[0].horaCierre !== undefined ? response.body.message.rowset[0].horaCierre : "000000";
  hora = hora.padStart(6,"0");            
            datos.horaCierre =   `${hora.substring(0,2)}:${hora.substring(2,4)}:${hora.substring(4,6)}`;
        }

        return datos;
    }
}

    return recuperar_hora_cierre_oq;
    });
