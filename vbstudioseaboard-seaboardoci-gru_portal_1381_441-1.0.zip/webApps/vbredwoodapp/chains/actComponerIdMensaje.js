define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actComponerIdMensaje extends ActionChain {

    /**
     * Esta función concatena los valores clave de una transacción para componer el ID del mensaje para esa transacción.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.tipoChatID ID del tipo de objeto sobre el que trata el mensaje (factura, orden, etc - definidos en tabla TipoChat)
     * @param {string} params.tipoDocumento 
     * @param {string} params.nroDocumento 
     * @param {string} params.ciaDocumento 
     * @param {string} params.nroProveedor 
     * @param {string} params.sfxOrden 
     * @param {string} params.depositoPlanif 
     * @param {string} params.tipoObjChat Si se conoce el tipo de objeto chat (valor hard coded de tabla tipoChat , pasarlo por este parámetro, caso contrario , informar ID en el otro parámetro)
     * @return {string} 
     */
    async run(context, { tipoChatID = '', tipoDocumento = '', nroDocumento = '', ciaDocumento = '', nroProveedor = '', sfxOrden = '', depositoPlanif = '', tipoObjChat = '' }) {
      const { $application, $constants, $variables } = context;
      let nroTransaccion1='';
let tipoChatObj = tipoObjChat;
      // si no se informó el tipo de objeto chat, buscarlo en el BO, caso contrario usar el informado

    if (tipoObjChat ==='' && tipoChatID!=='') {
// busco el tipo de objeto

        const response = await Actions.callRest(context, {
          endpoint: 'businessObjects/get_TipoChat',
          uriParams: {
            'TipoChat_Id': tipoChatID,
          },
        });
        if (response.ok) {
          tipoChatObj = response.body.tipoObjetoChat;
        }

    }

if (tipoChatObj!=='') {
//  compoongo el string que es el id del mensaje.
  if (tipoChatObj === 'FC' || tipoChatObj === 'OC' || tipoChatObj === 'LC') {
        //nroTransaccion1 = tipoObjChat + "-" + tipo + "-" + nro + "-" + cia + "-" + sfx;
        nroTransaccion1   = tipoDocumento + "-" + nroDocumento + "-" + ciaDocumento + "-" + sfxOrden;
      } else {
        switch (tipoChatObj) {
          case ('FL'):
            nroTransaccion1 = nroDocumento + "-" + depositoPlanif;
            break;
          case ('PG'):
            // nroTransaccion1 = tipoObjChat + "-" + tipo + "-" + nro + "-" + cia;
            nroTransaccion1    = tipoDocumento + "-" + nroDocumento + "-" + ciaDocumento;
            break;
          case ('PR'):
            nroTransaccion1 = nroProveedor;
            break;
          case ('NT'):
            break;
        }
      }
      }
      return nroTransaccion1;
    }
  }

  return actComponerIdMensaje;
});
