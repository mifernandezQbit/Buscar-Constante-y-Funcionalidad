define([
    'vb/action/actionChain',
    'vb/action/actions',
    'vb/action/actionUtils',
], (
    ActionChain,
    Actions,
    ActionUtils
) => {
    'use strict';

    class buscar_mensajes extends ActionChain {

        /**
         * OBSOLETA, SE REEMP,L.AZA CON V2 Busca los mensajes según parámetros indicados
         * @param {Object} context
         * @param {Object} params
         * @param {string} params.inParamSearchType
         * @param {string} params.inParamFromDate
         * @param {string} params.inParamSupplierNbr
         * @param {string} params.inParamJdeTransactionId
         * @param {string} params.inParamSuscriptorID
         * @param {boolean} params.inParamIsSupplier
         * @param {string} params.inParamChatObjectType
         * @param {boolean} params.inParamOnlyNew
         * @param {boolean} params.inParamIncludeSystemGeneratedMsg
         * @param {string} params.inParamPortalUser
         * @param {string[]} params.inParamUserRolesID
         */
        async run(context, { inParamSearchType, inParamFromDate, inParamSupplierNbr, inParamJdeTransactionId, inParamSuscriptorID, inParamIsSupplier, inParamChatObjectType, inParamOnlyNew = false, inParamIncludeSystemGeneratedMsg = true, inParamPortalUser, inParamUserRolesID }) {
            const { $application } = context;
            var infoParams = {
                inParamSearchType: inParamSearchType,
                inParamFromDate: inParamFromDate,
                inParamSupplierNbr: inParamSupplierNbr,
                inParamJdeTransactionId: inParamJdeTransactionId,
                inParamSuscriptorID: inParamSuscriptorID,
                inParamIsSupplier: inParamIsSupplier,
                inParamChatObjectType: inParamChatObjectType,
                inParamPortalUser: inParamPortalUser,
                inParamUserRolesID: inParamUserRolesID
            }

            $application.variables.q = "suscriptorID = '" + inParamSuscriptorID + "'";
            // Cambio CJC: Anteriormente el condicional tenía un error, ya que validaba si inParamFromDate era undefined o diferente a una cadena vacía.
            if (inParamFromDate === undefined || inParamFromDate == "") {

            }
            else {
                //MIF limpio mensajes anteriores
                $application.variables.mensajes = [];
                // MIF comienza lógica para armar el query 
                $application.variables.buscar = true;
                var queryCC = $application.variables.q;
                if (inParamFromDate !== undefined && inParamFromDate !== "") {
                    $application.variables.q = $application.variables.q + " and creationDate>'" + inParamFromDate + "'";
                    queryCC = queryCC + " and creationDate>'" + inParamFromDate + "'";
                }
                // Tipo búsqueda 1 msg para todos los proveedores
                if (inParamSearchType === "1") {
                    $application.variables.q = $application.variables.q + " and nroProveedor=0";
                } else {
                    // todos los mensajes para el proveedor no vinculados a transacciones.
                    if (inParamSearchType === "2") {

                        if (inParamSupplierNbr === undefined || inParamSupplierNbr === "") {
                            $application.variables.buscar = false;
                        } else {
                            $application.variables.q = $application.variables.q + " and nroProveedor=" + parseInt(inParamSupplierNbr) + " and destinatarioProveedor=true";
                            if (inParamOnlyNew === true) {
                                $application.variables.q = $application.variables.q + " and nuevoMensaje=true";
                            }

                            // Solo los que no son automáticos del sistema
                            if (inParamIncludeSystemGeneratedMsg === false) {
                                $application.variables.q = $application.variables.q + " and tipoUsuario!='S'";
                            }

                            $application.variables.q = $application.variables.q + " and nroTransaccion IS NULL"; // Cambio CJC: Se reemplaza nroTransaccion='' por IS NULL, ya que con '' no obtenia resultados porque en la base de datos el valor real es NULL
                        }

                    }
                    else {
                        // Todos los mensjaes nuevos del proveedor no vistos
                        if (inParamSearchType === "3") {
                            if (inParamSupplierNbr === undefined || inParamSupplierNbr === "") {
                                $application.variables.buscar = false;
                            } else {
                                $application.variables.q = $application.variables.q + " and nroProveedor=" + parseInt(inParamSupplierNbr) + " and destinatarioProveedor=true";
                                $application.variables.q = $application.variables.q + " and nuevoMensaje=true";

                                // Solo los que no son automáticos del sistema
                                if (inParamIncludeSystemGeneratedMsg === false) {
                                    $application.variables.q = $application.variables.q + " and tipoUsuario!='S'";
                                }

                                $application.variables.q = $application.variables.q + " and nroTransaccion IS NOT NULL"; // CJC: Se reemplaza nroTransaccion != '' por IS NOT NULL, ya que se evidenció que la query no era correcta.
                            }
                        }
                        else {
                            // Todos los mensajes vinculados a una transaccion en particular
                            if (inParamSearchType === "4") {
                                //MIF if (inParamSupplierNbr === "" && inParamChatObjectType !== 'LC') {
                                if (inParamSupplierNbr === "") {
                                    // Todos los mensajes vinculados a una transacción en particular
                                    $application.variables.buscar = false;
                                } else {
                                    // Cambio CJC: No existe el método strip. Por ende, se reemplaza por una expresión regular
                                    //if (inParamJdeTransactionId.strip(' \t\n\r') === "") {
                                    try {
                                        var paramJdeTransactionId = inParamJdeTransactionId !== undefined ? inParamJdeTransactionId.replace(/[\t\n\r]+/g, "") : null;
                                    } catch (e) {
                                        paramJdeTransactionId = inParamJdeTransactionId !== undefined ? inParamJdeTransactionId : null;
                                        console.warn('Error in buscar_mensajes: ', e);
                                    }
                                    if (inParamJdeTransactionId === undefined || inParamJdeTransactionId.replace(/[\t\n\r]+/g, "") === "") {
                                        // Nro de transaccion no puede estar vacío
                                        $application.variables.buscar = false;
                                    }
                                }

                                if ($application.variables.buscar === true) {
                                    /*
                                     * Si no es licitacion, busco las del proveedor, caso contrario
                                     * # busco los mensajes de la licitación de todos los proveedores porque son públicos.
                                     */
                                    //MIF if (inParamChatObjectType !== 'LC') {
                                    $application.variables.q = $application.variables.q + " and nroProveedor= " + parseInt(inParamSupplierNbr);
                                    queryCC = queryCC + " and nroProveedor= " + parseInt(inParamSupplierNbr);
                                    //}

                                    // Busco para una transaccion en particular
                                    // CJC: Comentado por error debido a que no existe el método strip.
                                    // $application.variables.q = $application.variables.q + "and nroTransaccion='" + inParamJdeTransactionId.strip(' \t\n\r') + "'";
                                    $application.variables.q = $application.variables.q + " and nroTransaccion LIKE '%" + paramJdeTransactionId + "%'"; // CJC 2025_04_08: Se reemplaza el uso de = por LIKE
                                    queryCC = queryCC + " and nroTransaccion LIKE '%" + paramJdeTransactionId + "%'"; // CJC 2025_04_08: Se reemplaza el uso de = por LIKE
                                    // Solo los que no son automáticos del sistema
                                    if (inParamIncludeSystemGeneratedMsg === false) {
                                        $application.variables.q = $application.variables.q + " and tipoUsuario!='S'";
                                        queryCC = queryCC + " and tipoUsuario!='S'";
                                    }
                                }
                            }
                            else {
                                // Mensajes nuevos para un usuario para mostrar en el dashboard
                                if (inParamSearchType === "5") {
                                    if (inParamPortalUser === undefined || inParamPortalUser === "") {
                                        $application.variables.buscar = false;
                                    } else {
                                        $application.variables.q = $application.variables.q + " and destinatarioProveedor=false";

                                        if (inParamOnlyNew === true) {
                                            $application.variables.q = $application.variables.q + " and nuevoMensaje=true";
                                        }

                                        // Solo los que no son automáticos del sistema
                                        if (inParamIncludeSystemGeneratedMsg === false) {
                                            $application.variables.q = $application.variables.q + " and tipoUsuario!='S'";
                                        }

                                        $application.variables.q = $application.variables.q + " and destinatario like '%" + inParamPortalUser + "%'";
                                    }
                                }
                                else {
                                    if (inParamSearchType === "6") {

                                        if ((inParamIsSupplier === true)) {
                                            if (inParamSupplierNbr === undefined || inParamSupplierNbr === "") {
                                                $application.variables.buscar = false;
                                            }
                                            else {
                                                if (parseInt(inParamSupplierNbr) !== $application.variables.user.numeroAn8) {
                                                    $application.variables.buscar = false;
                                                }
                                            }
                                        }
                                        if ((inParamIsSupplier === false) && (inParamPortalUser === undefined || inParamPortalUser === "")) {
                                            $application.variables.buscar = false;
                                        }

                                        if ($application.variables.buscar === true) {
                                            // Busca un proveedor
                                            if (inParamSupplierNbr !== undefined && inParamSupplierNbr !== "") {
                                                $application.variables.q = $application.variables.q + " and nroProveedor=" + parseInt(inParamSupplierNbr);
                                            }
                                            // Busca un tipo de objeto en particular
                                            if (inParamChatObjectType !== undefined && inParamChatObjectType !== "") {
                                                $application.variables.q = $application.variables.q + " and tipoObjetoChat='" + inParamChatObjectType + "'";
                                            }
                                            // Busco para una transaccion en particular //
                                            if (inParamJdeTransactionId !== undefined && inParamJdeTransactionId !== "") {
                                                $application.variables.q = $application.variables.q + "and nroTransaccion LIKE '*" + inParamJdeTransactionId + "*'"; // CJC 2025_04_08: Se reemplaza el uso de = por LIKE
                                            }

                                            if (inParamIsSupplier === false) {

                                                $application.variables.q = $application.variables.q + "and (usuarioPortal like '*" + inParamPortalUser + "*' or destinatario like '*";
                                                $application.variables.q = $application.variables.q + inParamPortalUser + "*')"

                                            }

                                            // CJC Inicio Cambio 2025_04_08: Si el parametro inParamOnlyNew es true, se añade en la query
                                            if (inParamOnlyNew == true) {
                                                $application.variables.q = $application.variables.q + " and nuevoMensaje=true";
                                            }
                                            // Fin Cambio 2025_04_08

                                        }
                                    } else {
                                        $application.variables.buscar = false;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if ($application.variables.buscar === true) {
                // Inicio Cambio CJC: La diferencia es que queryCC tiene como parametro creationDate en lugar de fechaCreacion. Se evidencia
                // que al utilizar fechaCreacion, al menos la búsqueda de mensajes rompe.En cambio, con creationDate funciona bien la consulta
                // y permite mostrar los mensajes en base a los resultados obtenidos
                var sqlQuery = $application.variables.q;
                if (inParamSearchType == "4") {
                    sqlQuery = queryCC;
                }
                // Fin Cambio CJC

                const response = await Actions.callRest(context, {
                    endpoint: 'businessObjects/getall_Mensaje',
                    uriParams: {
                        q: sqlQuery, // Ajuste CJC
                        limit: 1000,
                    },
                });
                if (response.ok) {
                    // retornar mensajes
                    $application.variables.mensajes = response.body.items;

                    // Inicio Cambio 1/2 07/2025 CJC - Get Usuarios
                    const usuarios = await Actions.callRest(context, {
                        endpoint: 'businessObjects/getall_Usuario',
                        uriParams: {
                            q: "suscriptorID = '" + inParamSuscriptorID + "' and email IS NOT NULL and estaActivo =true",
                        },
                    });

                    // Se construye un objeto en el que, por cada usuario obtenido en la consulta anterior,
                    // se agrega una entrada donde la clave es el email y el valor es el nombre del usuario
                    const objEmails = Object.values(usuarios.body.items).reduce((objetoNuevo, user) => {
                        if (user.email && user.nombre) {
                            objetoNuevo[user.email] = user.nombre;
                        }
                        return objetoNuevo;
                    }, {});

                    // Fin cambio 1/2 07/2025

                    // completar remitentes y destinatarios
                    for (let i = 0; i < $application.variables.mensajes.length; i++) {
                        // Inicio cambio 2/2 07/2025 CJC: Para cada mensaje, se consulta el email del Remitente y/o destinatario.
                        // Luego, utilizando ese email, se obtiene el nombre del Remitente y/o destinatario,
                        // el cual se asigna a la propiedad "_nombreRemitente" o "_nombreDestinatario" del objeto mensaje

                        var currentEmail = $application.variables.mensajes[i].destinatario;
                        currentEmail ? objEmails[currentEmail] ? $application.variables.mensajes[i]._nombreDestinatario = objEmails[currentEmail] :$application.variables.mensajes[i]._nombreDestinatario = currentEmail : "";

                        var remitente = $application.variables.mensajes[i].createdBy;
                        remitente ? $application.variables.mensajes[i]._nombreRemitente = objEmails[remitente] : "";

                        var usuarioVisto = ($application.variables.mensajes[i].usuarioVisto !== undefined && $application.variables.mensajes[i].usuarioVisto !== "") ? $application.variables.mensajes[i].usuarioVisto : "";
                        usuarioVisto !== "" ? $application.variables.mensajes[i]._nombreUsuarioVisto = objEmails[usuarioVisto] : "";
                        // Fin cambio 2/2 07/2025
                    }
                } else {
                    $application.variables.mensajes = [];
                }

            }

            return;
        }
    }

    return buscar_mensajes;
});