define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  function base64ToBlob(base64, mimeType) {
    const characters = atob(base64);
    const byte = new Array(characters.length);
    for (let idx = 0; idx < characters.length; idx++) {
      byte[idx] = characters.charCodeAt(idx);
    }

    const byteArray = new Uint8Array(byte);
    return new Blob([byteArray], { type: mimeType });
  }

  class descargar_archivo extends ActionChain {

    /**
     * Descargar archivo almacenado en Object Storage
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.nroProveedor 
     * @param {string} params.tpDocumento 
     * @param {string} params.nroDocumento 
     * @param {string} params.ciaDocumento 
     * @param {string} params.ordenSufijo 
     * @param {string} params.flagTipoOrden Indica si se va a descargar una orden de compra C - un certificado de retención R o un pago P
     * @param {string} params.nroBeneficiario igual al nro de proveedor, completar ambos
     * @param {string} params.instrumentoPago 
     * @param {string} params.nombreCarpeta 
     */
    async run(context, { nroProveedor, tpDocumento, nroDocumento, ciaDocumento, ordenSufijo, flagTipoOrden, nroBeneficiario, instrumentoPago, nombreCarpeta }) {
      const { $application } = context;

      let error = "";
      let content = "";
      let carpeta = nombreCarpeta ? nombreCarpeta : "";
      // recuperamos carpeta de object storage donde se dejan los PDFs si no se informa por parámetro
      if (carpeta === "") {

        const buscarConstante = await Actions.callChain(context, {
          chain: 'buscar_constante',
          params: {
            constante: 'CARPETA_OS_PDF',
          },
        });

        if (buscarConstante.existe && buscarConstante.valor !== undefined) {
          carpeta = buscarConstante.valor;
        }
      }
      // si no está configurada la carpeta, informamos error de configuración
      if (carpeta === "") {
        const notificarError = await Actions.callChain(context, {
          chain: 'notificar_error',
          params: {
            codigo: 'carpeta-no-configurada',
          },
        });
      }
      else {

        const response = await Actions.callRest(context, {
          endpoint: 'GatewayPortal/postQ71PO_DescargarArchivo',
          body: {
            //"bucketName" : "suscriptor-" + $application.variables.suscriptor.id,
            "bucketName": $application.variables.suscriptor.objectStorageBucket,
            "nroProveedor": nroProveedor,
            "tpDocumento": tpDocumento,
            "nroDocumento": nroDocumento,
            "ciaDocumento": ciaDocumento,
            "ordenSufijo": ordenSufijo,
            "flagTipoOrden": flagTipoOrden,
            "nroBeneficiario": nroBeneficiario,
            "instrumentoPago": instrumentoPago,
            "nombreCarpeta": carpeta,
            "token": $application.variables.token
          }
        });

        await Actions.callChain(context, {
          chain: 'verificar_respuesta_jdeError',
          params: {
            error: !response.ok,
            funcion: 'DescargarArchivo',
            tokenExpirado: response.body.tokenExpirado,
            status: response.status,
          },
        });

        if (response.ok) {
          // Obtener contenido en base64 y el mimeType que devuelve la function
          if (response.body.success) {
            content = response.body.data.content;
            const mimeType = response.body.data.mimeType;

            const blob = base64ToBlob(content, mimeType);
            const fileURL = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = fileURL;
            a.download = response.body.data.fileName;
            document.body.appendChild(a);
            a.click();
            // Limpiar DOM
            document.body.removeChild(a);

            const notificarError2 = await Actions.callChain(context, {
              chain: 'notificar_error',
              params: {
                codigo: 'archivo-descargado-ok',
              },
            });

            const guardarLog = await Actions.callChain(context, {
              chain: 'application:guardar_log',
              params: {
                funcionalidad: 'DESCARGAR_ARCHIVO',
                accion: 'DESCARGAR',
                pagina: $application.currentPage.id,
                proveedor: $application.variables.user.esProveedor,
                suscriptorId: $application.variables.suscriptor.id,
                usuario: $application.variables.user.ociUser,
                numeroAn8: $application.variables.user.numeroAn8,
                transaccion: response.body.data.fileName,
                roles: $application.variables.userRoles.userRolesSt,
              },
            });

          } else {
             await Actions.callChain(context, {
              chain: 'application:guardar_log',
              params: {
                funcionalidad: 'DESCARGAR_ARCHIVO',
                accion: 'DESCARGAR_ERROR',
                pagina: $application.currentPage.id,
                proveedor: $application.variables.user.esProveedor,
                suscriptorId: $application.variables.suscriptor.id,
                usuario: $application.variables.user.ociUser,
                numeroAn8: $application.variables.user.numeroAn8,
                transaccion: response.body.data.fileName,
                roles: $application.variables.userRoles.userRolesSt,
              },
            });
            const notificarError3 = await Actions.callChain(context, {
              chain: 'notificar_error',
              params: {
                codigo: 'archivo-descarga-fallida',
              },
            });

          }

        }
      }
    }
  }

  return descargar_archivo;
});
