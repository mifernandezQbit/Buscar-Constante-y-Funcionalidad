define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class iniciar_wf extends ActionChain {

    /**
     * Ejecuta la funcíon para iniciar un wf si corresponde.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.modulo
     * @param {string} params.funcionalidadPortal
     * @param {string} params.accionWF
     * @param {string} params.accionJDE
     * @param {number} params.usuarioSolicitante
     * @param {number} params.usuarioOriginadorTR
     * @param {number} params.usuarioOriginadorWF
     * @param {number} params.nroProveedor
     * @param {string} params.tipoDocumento
     * @param {number} params.nroDocumento
     * @param {string} params.ciaDocumento
     * @param {string} params.mailProveedor
     * @param {boolean} params.actDatosGenerales
     * @param {boolean} params.actDatosImpuestos
     * @param {boolean} params.actDatosTesoreria
     * @param {boolean} params.actDatosContabilidad
     * @param {boolean} params.actDatosTransportista
     * @param {boolean} params.actDatosOfac
     * @param {boolean} params.actDatosContactos
     * @param {number} params.importeTotal Total del comprobante en moneda doméstica
     * @param {number} params.importeMonedaExtranjera Total del comprobante en moneda extranjera
     * @param {number} params.importeTotalDolares Total del comprobante en dólares independientemente de la moneda en la que se ingresó
     * @param {string} params.pais
     * @param {string} params.tipoDctoLegal
     * @param {string} params.ruteoVoucher
     * @param {number} params.lineaContacto
     * @param {number} params.nroAprobador
     * @param {string} params.cdCatMaestro
     * @param {string} params.estadoPago
     * @param {string} params.motivoAprRech
     * @param {string} params.flag01
     * @param {string} params.flag02
     * @param {string} params.flag03
     * @param {string} params.flag04
     * @param {string} params.flag05
     * @param {string} params.flag06
     * @param {string} params.flag07
     * @param {string} params.flag08
     * @param {string} params.flag09
     * @param {string} params.flag10
     * @param {string} params.tipoBusqueda
     */
    async run(context, { modulo, funcionalidadPortal, accionWF, accionJDE, usuarioSolicitante, usuarioOriginadorTR, usuarioOriginadorWF, nroProveedor, tipoDocumento, nroDocumento, ciaDocumento, mailProveedor, actDatosGenerales, actDatosImpuestos, actDatosTesoreria, actDatosContabilidad, actDatosTransportista, actDatosOfac, actDatosContactos, importeTotal = 0, importeMonedaExtranjera = 0, importeTotalDolares = 0, pais, tipoDctoLegal, ruteoVoucher, lineaContacto, nroAprobador, cdCatMaestro, estadoPago, motivoAprRech, flag01, flag02, flag03, flag04, flag05, flag06, flag07, flag08, flag09, flag10, tipoBusqueda }) {
      const { $application, $constants, $variables } = context;
      let idTransaccion =  (tipoDocumento !== undefined && tipoDocumento !== "") ? "|" + tipoDocumento + "|" + nroDocumento + "|" + ciaDocumento.padStart(5,"0")+ "|" :"|" + nroProveedor+ "|";
      const response = await Actions.callRest(context, {
        endpoint: 'GatewayPortal2/postQ71PO_IniciarWF',
        body: {
       "token": $variables.token,
       "modulo":  modulo !==undefined ? modulo : "",
       "funcionalidadPortal": funcionalidadPortal !==undefined ? funcionalidadPortal : "",
       "accionWF": accionWF !==undefined ? accionWF :"",
       "accionJDE": accionJDE !==undefined ? accionJDE :"",
       "usuarioSolicitante": usuarioSolicitante !==undefined ? usuarioSolicitante :0,
       "usuarioOriginadorTR": usuarioOriginadorTR !==undefined ? usuarioOriginadorTR :0,
       "usuarioOriginadorWF":usuarioOriginadorWF !==undefined ? usuarioOriginadorWF : 0,
       "nroProveedor": nroProveedor !==undefined ? nroProveedor :0,
              "tipoBusqueda": tipoBusqueda !==undefined ? tipoBusqueda :"",
       "tipoDocumento": tipoDocumento !==undefined ? tipoDocumento :"",
       "nroDocumento": nroDocumento !==undefined ? nroDocumento :0,
       "ciaDocumento": ciaDocumento !==undefined ? ciaDocumento :"",
       "mailProveedor": mailProveedor !==undefined ? mailProveedor :"",
       "actDatosGenerales": actDatosGenerales !==undefined ? actDatosGenerales :true,
       "actDatosImpuestos": actDatosImpuestos !==undefined ? actDatosImpuestos :true,
       "actDatosTesoreria": actDatosTesoreria !==undefined ? actDatosTesoreria :true,
       "actDatosContabilidad": actDatosContabilidad !==undefined ? actDatosContabilidad :true,
       "actDatosTransportista": accionWF ==='A' && actDatosTransportista !==undefined ? actDatosTransportista :false,
       "actDatosContactos": actDatosContactos !==undefined ? actDatosContactos :true,
       "importeTotal": importeTotal !==undefined ? importeTotal :0,
       "actDatosOfac": actDatosOfac !==undefined ? actDatosOfac :true,
       "importeMonedaExtranjera": importeMonedaExtranjera !==undefined ? importeMonedaExtranjera :0,
       "importeTotalDolares": importeTotalDolares !==undefined ? importeTotalDolares :0,
           "pais": pais !==undefined ? pais :"",
"tipoDctoLegal": tipoDctoLegal !==undefined ? tipoDctoLegal :"",
"ruteoVoucher": ruteoVoucher !==undefined ? ruteoVoucher :"",
"lineaContacto": lineaContacto !==undefined ? lineaContacto :0,
"nroAprobador": nroAprobador !==undefined ? nroAprobador :0,
"cdCatMaestro": cdCatMaestro !==undefined ? cdCatMaestro :"",
"estadoPago": estadoPago !==undefined ? estadoPago :"",
"flag01": flag01 !==undefined ? flag01 :"",
"flag02": flag02 !==undefined ? flag02 :"",
"flag03": flag03 !==undefined ? flag03 :"",
"flag04": flag04 !==undefined ? flag04 :"",
"flag05": flag05 !==undefined ? flag05 :"",
"flag06": flag06 !==undefined ? flag06 :"",
"flag07": flag07 !==undefined ? flag07 :"",
"flag08": flag08 !==undefined ? flag08 :"",
"flag09": flag09 !==undefined ? flag09 :"",
"flag10": flag10 !==undefined ? flag10 :""

      }
      });

      await Actions.callChain(context, {
        chain: 'verificar_respuesta_jdeError',
        params: {
          error: !response.ok,
          funcion: 'IniciarWF',
          funcionalidad: funcionalidadPortal,
          tokenExpirado: response.body.tokenExpirado !== undefined ? response.body.tokenExpirado : false,
          transaccion: idTransaccion,
          success: response.body.success,
          status:response.status,
        },
      });
      if (response.body.success ) {
        if (response.body.data.wfIniciado==="1") {

          await Actions.callChain(context, {
            chain: 'guardar_log',
            params: {
              accion: 'WF_INICIADO',
              funcionalidad: funcionalidadPortal,
              numeroAn8: $variables.user.numeroAn8,
              pagina: $application.currentPage.id,
              proveedor: $variables.user.esProveedor,
              roles: $variables.userRoles.userRolesSt,
              suscriptorId: $variables.suscriptor.id,
              usuario: $variables.user.ociUser,
              transaccion: response.body.data.nombreProceso + "-" + response.body.data.versionProceso + "-" + response.body.data.instanciaProceso,// + " / " + idTransaccion,
              observaciones: idTransaccion,
            },
          });

          const notificarError = await Actions.callChain(context, {
            chain: 'notificar_error',
            params: {
              titulo: "Flujo de aprobación "+ response.body.data.nombreProceso  + " iniciado.",
              descripcion: "Se ha iniciado el flujo de revisión y o aprobación "+ response.body.data.nombreProceso + "-" + response.body.data.versionProceso + "-"+ response.body.data.instanciaProceso + "." + ((response.body.data.estadoProceso && response.body.data.estadoProceso!=="") ?(" Estado actual: " +(response.body.data.estadoProceso==="01"?  "Activo.":(response.body.data.estadoProceso==="03"?  "Terminado.":  response.body.data.estadoProceso))) :""),
              tipoNotificacion: 'info',
              modoVisualizacion: 'transient',
            },
          });
        } else {
          if (response.body.data.wfIniciado === "2"  ) {
                     await Actions.callChain(context, {
                       chain: 'guardar_log',
                       params: {
                         accion: 'WF_INICIADO_ERROR',
                         funcionalidad: funcionalidadPortal,
                         numeroAn8: $variables.user.numeroAn8,
                         pagina: $application.currentPage.id,
                         proveedor: $variables.user.esProveedor,
                         roles: $variables.userRoles.userRolesSt,
                         suscriptorId: $variables.suscriptor.id,
                         usuario: $variables.user.ociUser,
                         transaccion: response.body.data.nombreProceso + "-" + response.body.data.versionProceso + "-" + response.body.data.instanciaProceso,
                         observaciones: idTransaccion,
                       },
                     });

            const notificarError2 = await Actions.callChain(context, {
              chain: 'notificar_error',
              params: {
                titulo: "Flujo de aprobación "+ response.body.data.nombreProceso  + " iniciado con error.",
                descripcion: "El flujo de revisión y o aprobación se inició, pero terminó en error.  "+ response.body.data.nombreProceso + "-" + response.body.data.versionProceso + "-"+ response.body.data.instanciaProceso,
                tipoNotificacion: 'error',
                modoVisualizacion: 'persist',
              },
            });
          } 
          else {
                      if (response.body.data.wfIniciado === "3"  ) {
                    await Actions.callChain(context, {
                       chain: 'guardar_log',
                       params: {
                         accion: 'WF_INICIADO_INDEFINIDO',
                         funcionalidad: funcionalidadPortal,
                         numeroAn8: $variables.user.numeroAn8,
                         pagina: $application.currentPage.id,
                         proveedor: $variables.user.esProveedor,
                         roles: $variables.userRoles.userRolesSt,
                         suscriptorId: $variables.suscriptor.id,
                         usuario: $variables.user.ociUser,
                         transaccion: response.body.data.nombreProceso + "-" + response.body.data.versionProceso + "-" + response.body.data.instanciaProceso + " / " + idTransaccion,
                         observaciones: idTransaccion,
                       },
                     });
              const notificarError3 = await Actions.callChain(context, {
                chain: 'notificar_error',
                params: {
                  titulo: "Flujo de aprobación "+ response.body.data.nombreProceso  + " quedo en estado indefinido.",
                  descripcion: "El flujo de revisión y/o aprobación se inició, pero quedó en un estado indefinido. "+ response.body.data.nombreProceso + "-" + response.body.data.versionProceso + "-"+ response.body.data.instanciaProceso + "." + ((response.body.data.estadoProceso && response.body.data.estadoProceso!=="") ? ("Estado: " + response.body.data.estadoProceso) :""),
                  tipoNotificacion: 'error',
                  modoVisualizacion: 'persist',
                },
              });
            } else {
                        await Actions.callChain(context, {
                       chain: 'guardar_log',
                       params: {
                         accion: 'WF_INDEFINIDO',
                         funcionalidad: funcionalidadPortal,
                         numeroAn8: $variables.user.numeroAn8,
                         pagina: $application.currentPage.id,
                         proveedor: $variables.user.esProveedor,
                         roles: $variables.userRoles.userRolesSt,
                         suscriptorId: $variables.suscriptor.id,
                         usuario: $variables.user.ociUser,
                         transaccion: idTransaccion,
                         observaciones: 'No hay workflow definido para ser iniciado para este comprobante',
                       },
                     });
          }
          }

        }
      }

      return response.body.data.wfIniciado;
    }
  }
  return iniciar_wf;
});
