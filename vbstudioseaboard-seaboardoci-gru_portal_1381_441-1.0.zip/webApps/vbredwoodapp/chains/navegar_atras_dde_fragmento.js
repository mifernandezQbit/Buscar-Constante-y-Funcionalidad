define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navegar_atras_dde_fragmento extends ActionChain {

    /**
     * Navegar a la página anterior para usar desde dentro de un fragmento.
     * @param {Object} context
     */
    async run(context) {
      const { $application, $constants, $variables } = context;

      await Actions.navigateBack(context, {
      });
    }
  }

  return navegar_atras_dde_fragmento;
});