define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class gestionar_usuario_oci extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.paramUsuarioPortal 
     * @param {string} params.paramNroProveedor 
     * @param {string} params.paramNroSuscriptor 
     * @param {string} params.paramMail 
     * @param {string} params.paramNroMensaje 
     * @param {string} params.paramModo 
     * @param {any[]} params.paramRolesPortal 
     */
    async run(context, { paramUsuarioPortal, paramNroProveedor, paramNroSuscriptor, paramMail, paramNroMensaje, paramModo, paramRolesPortal }) {
      const { $application } = context;

      console.log("Llamar API - Gestionar Usuario Portal");

      if (paramModo === 'alta') {
        if (true) {
          console.log("successPortal = true Y successOci = true")

          await Actions.callChain(context, {
            chain: 'enviar_mail',
          });
        }
      }

      if (true) {
        console.log("successPortal = true Y successOci = true");

        const notificarError = await Actions.callChain(context, {
          chain: 'notificar_error',
          params: {
            modoVisualizacion: '',
            codigo: 'fallo-alta-baja-usuario',
          },
        });
      }
    }
  }

  return gestionar_usuario_oci;
});
