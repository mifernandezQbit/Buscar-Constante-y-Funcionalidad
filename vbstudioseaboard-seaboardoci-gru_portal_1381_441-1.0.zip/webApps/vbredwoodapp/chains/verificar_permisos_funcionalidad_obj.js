define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class verificar_permisos_funcionalidad_obj extends ActionChain {

    /**
     * Verifica si existe una funcionalidad dada en la lista de permisos del usuario y devuelve un objeto con todos sus datos.
     * @param {Object} context
     */
   
/**
 * Verifica si existe una funcionalidad dada en la lista de permisos del usuario y devuelve un objeto con todos sus datos.
 * @param {Object} context
 * @param {Object} params
 * @param {any} params.funcionalidad 
 * @return {object} 
 */
async run(context, { funcionalidad }) {
      const { $application } = context;

      const callFunction = await this.verificarExistenciaFuncionalidad(context, { funcionalidad: funcionalidad, permisosFuncionalidad: $application.variables.userFunctionalityList });

      return callFunction;
    }

    /**
     * Verfica si existe una funcionalidad dada en la lista de permisos del usuario y devuelve el objeto asociado
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.funcionalidad 
     * @param {postQ71PO_ObtenerPermisosFuncionalidad[]} params.permisosFuncionalidad 
     * @return {object} 
     */
    async verificarExistenciaFuncionalidad(context, { funcionalidad, permisosFuncionalidad }) {
      const { $application } = context;

    let k = 'funcionalidad';
let objIndex = permisosFuncionalidad.findIndex(
    (elemento) => elemento[k] === funcionalidad);
  if (objIndex ===-1) {
  return {'existe':false,
  'tipoObjetoChat':''};
} 
else {

  return {'existe':true, 
  'tipoObjetoChat': permisosFuncionalidad[objIndex].tipoObjetoChat};
}


    }
  }

  return verificar_permisos_funcionalidad_obj;
});
