define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class guardar_log extends ActionChain {

    /**
     * guarda entrada en tabla de log
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.suscriptorId 
     * @param {number} params.numeroAn8 
     * @param {boolean} params.proveedor 
     * @param {string} params.funcionalidad lista de funcionalidades a las que tiene permiso (el nombre, no el id) separadas por ,
     * @param {string} params.accion 
     * @param {string} params.transaccion 
     * @param {string} params.usuario 
     * @param {string} params.roles lista de id roles vigentes del usuario separados por coma
     * @param {string} params.pagina 
     * @param {string} params.observaciones 
     * @return {boolean} 
     */
    async run(context, { suscriptorId, numeroAn8, proveedor, funcionalidad, accion, transaccion, usuario, roles, pagina, observaciones }) {
      const { $application } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/create_Log',
        body: {
          suscriptorID: suscriptorId,
          numeroAn8: numeroAn8,
          proveedor: proveedor,
          funcionalidad: funcionalidad,
          accion: accion,
          transaccion: transaccion,
          rol: roles,
          pagina: pagina,
          fechaCreacion: new Date(),
          usuarioOCI: $application.user.username,
      observaciones: observaciones
        },
      });

      if (response.ok === false) {
        $application.variables.menu = [];

        return false;
      } else {
         return true;
      }

    }
  }

  return guardar_log;
});
