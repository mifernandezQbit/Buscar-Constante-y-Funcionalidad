define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class verificar_proveedor extends ActionChain {

    /**
     * Action chain que verifica al proveedor
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.paramNroProveedor 
     * @param {any} params.paramTipoBusqueda 
     * @param {string} params.paramAccion 
     * @param {boolean} params.inactivo 
     * @return {boolean} 
     */
    async run(context, { paramNroProveedor, paramTipoBusqueda, paramAccion, inactivo }) {
      const { $application, $variables } = context;

      const valorUdc = await Actions.callRest(context, {
        endpoint: 'GatewayPortal/postQ71PO_BuscarValoresUDC',
        body: {
          token: $application.variables.token,
          'P0004A_Version': '',
          udcToSearch: [
            {
              productCode: 'Q71',
              userDefinedCode: 'ZW',
              description1: '',
              description2: '',
              specialHandling: '01',
            },
          ],
        },
      });

      await Actions.callChain(context, {
        chain: 'verificar_respuesta_jdeError',
        params: {
          error: !valorUdc.ok,
          tokenExpirado: valorUdc.body.tokenExpirado !== undefined ? valorUdc.body.tokenExpirado : false,
          funcion: 'BuscarValoresUDC',
          status:valorUdc.status,
        },
      });

      let proveedorOK = true;
      let wfActivo = false;
      let wfNombre = "";
      let wfInstancia=0;

      if (valorUdc.ok && valorUdc.body.errorJde !== undefined && !valorUdc.body.errorJde) {


        // armo lista de procesos para buscarworkflows
        let procesos = [];
        for (let j = 0; j < valorUdc.body.rowset[0].codesList.length; j++) {
          procesos.push({
            idProceso: valorUdc.body.rowset[0].codesList[j].code,
            procesoDesc: valorUdc.body.rowset[0].codesList[j].description01
          });
        }
        // busco workflows activos o waiting para ese proveedor
        const workFlow = await Actions.callRest(context, {
          endpoint: 'GatewayPortal2/postQ71PO_BuscarWFActivosClave',
          body: {
            token: $application.variables.token,
            buscarClave: paramNroProveedor,
            buscarAtributo: '',
            procesos: procesos,
            estados: [
              {
                estado: '01',
              },
              {
                estado: '07',
              },
            ],
            fechaDesde: '',
          },
        });

        await Actions.callChain(context, {
          chain: 'verificar_respuesta_jdeError',
          params: {
            error: !workFlow.ok,
            funcion: 'BuscarWorkflows',
            funcionalidad: $variables.funcionalidad,
            tokenExpirado: workFlow.body.tokenExpirado,
            transaccion: paramNroProveedor,
            status:workFlow.status,
          },
        });


        if (workFlow.body.rowset !== undefined && workFlow.body.rowset.length > 0) {

          const notificarError = await Actions.callChain(context, {
            chain: 'notificar_error',
            params: {
              codigo: 'error_workflow_proveedor',
              descripcion: 'Workflow: ' + workFlow.body.rowset[0].processName + ', Instancia:' + workFlow.body.rowset[0].processInstance.toString(),
            },
          });

          proveedorOK = false;
          wfActivo = true;
          wfNombre =workFlow.body.rowset[0].processName ;
          wfInstancia = workFlow.body.rowset[0].processInstance;
        };

        // si el proveedor no está en ningún workflow activo, verificar que el tipo de proveedor sea adecuado para la validación solicitada
        if (proveedorOK) {

          const TIPO_BUSQUEDA_PROV_RECH = await Actions.callChain(context, {
            chain: 'buscar_constante',
            params: {
              constante: 'TIPO_BUSQUEDA_PROV_RECH',
            },
          });

          const TIPO_BUSQUEDA_PROV_POTENCIAL = await Actions.callChain(context, {
            chain: 'buscar_constante',
            params: {
              constante: 'TIPO_BUSQUEDA_PROV_POTENCIAL',
            },
          });

          const TIPO_BUSQUEDA_CLIENTE = await Actions.callChain(context, {
            chain: 'buscar_constante',
            params: {
              constante: 'TIPO_BUSQUEDA_CLIENTE',
            },
          });
          if (paramAccion === 'activar' && TIPO_BUSQUEDA_PROV_RECH.valor !== paramTipoBusqueda) {
            const notificarError2 = await Actions.callChain(context, {
              chain: 'notificar_error',
              params: {
                codigo: 'error_intento_activar_proveedor',
              },
            });

            proveedorOK = false;
          }

          if (paramAccion === 'desactivar' && TIPO_BUSQUEDA_PROV_RECH.valor === paramTipoBusqueda) {
            const notificarError3 = await Actions.callChain(context, {
              chain: 'notificar_error',
              params: {
                codigo: 'error_intento_desactivar_proveedor',
              },
            });
            proveedorOK = false;
          }

          if (paramAccion === 'permanente' && TIPO_BUSQUEDA_PROV_POTENCIAL.valor !== paramTipoBusqueda) {
            const notificarError4 = await Actions.callChain(context, {
              chain: 'notificar_error',
              params: {
                codigo: 'error_permanente_proveedor',
              },
            });

            proveedorOK = false;
          }

          if (paramAccion === 'cliente-proveedor' && TIPO_BUSQUEDA_CLIENTE.valor !== paramTipoBusqueda) {
            const notificarError5 = await Actions.callChain(context, {
              chain: 'notificar_error',
              params: {
                codigo: 'error_cliente_proveedor',
              },
            });

            proveedorOK = false;
          }

          //20251218 P160
          if (paramAccion === 'editar' && (TIPO_BUSQUEDA_PROV_RECH.valor === paramTipoBusqueda || TIPO_BUSQUEDA_PROV_POTENCIAL.valor === paramTipoBusqueda)) {
            /*
            const notificarError2 = await Actions.callChain(context, {
              chain: 'notificar_error',
              params: {
                codigo: 'error_intento_activar_proveedor',
              },
            });
            */
            proveedorOK = false;
          }

        }
      } else {
        proveedorOK = false;
      }

      return { proveedorOK: proveedorOK, wfActivo: wfActivo, wfNombre:wfNombre, wfInstancia:wfInstancia };

    }
  }

  return verificar_proveedor;
});