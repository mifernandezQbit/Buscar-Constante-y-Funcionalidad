define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
)  => {
  'use strict';

  class buscar_rol extends ActionChain {

    /**
     * Si se informa el ID, busca el código, si se informa el código busca el ID
     * @param {Object} context
     * @param {Object} params
     * @param {number} params.rolID ID del tipo de chat
     * @param {string} params.rolObjeto Código hard coded a buscar o recuperar
     */
    async run(context, { rolID = 0, rolObjeto='' }) {
      const { $application, $constants, $variables } = context;

 let rol = {
  rolID: rolID,
  rolObjeto : rolObjeto
 };
      // si se informa ID, buscar codigo
      if (rolID !==0) {
/*
        const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_Rol',
        });
        if (response.ok === true) {
        rol.rolObjeto = response.body.rolObjeto;
        } else {
        const notificarError = await Actions.callChain(context, {
        chain: 'notificar_error',
        params: {
        codigo: 'falta-configuracion-rol',
        },
        });

        }
*/
      } else {
        // busco  por cóidigo y devuelvo ID

        const response2 = await Actions.callRest(context, {
          endpoint: 'businessObjects/getall_Rol',
          uriParams: {
            limit: $variables.consMaxBORecords,
          },
        });

        if (response2.ok && response2.body.items.length >0) {
           rol = response2.body.items;
        } else {
          const notificarError2 = await Actions.callChain(context, {
            chain: 'notificar_error',
            params: {
              codigo: 'falta-configuracion-mensajes',
            },
          });
        }
        

      }

      return rol;
    }
  }

  return buscar_rol;
});
