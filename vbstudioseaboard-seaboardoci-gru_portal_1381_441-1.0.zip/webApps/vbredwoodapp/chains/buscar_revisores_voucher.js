define([
    'vb/action/actionChain',
    'vb/action/actions',
    'vb/action/actionUtils',
], (
    ActionChain,
    Actions,
    ActionUtils
) => {
    'use strict';

    class buscar_revisores_voucher extends ActionChain {

        /**
         * Busca lista de usuarios con el rol de solicitador (o el que se indique en constante) para ofrecer en el alta de facturas en un select.
         * @param {Object} context
         * @param {Object} params
         * @param {string} params.paramConstante
         * @return {object[]} 
         */
        async run(context, { paramConstante = 'SOLICITADOR_ID' }) {
            const { $application, $constants, $variables } = context;

            // salida
            let listaSolicitadores = [];
            let solicitadorID = "";
            const hoy = new Date();
            const year = hoy.getFullYear();
            const month = (hoy.getMonth() + 1).toString().padStart(2, '0'); // Month is 0-indexed, so add 1
            const day = hoy.getDate().toString().padStart(2, '0');
            const fechaHoy = parseInt(year + month + day);

            let stringUsuarios = "";

            //Usuario Verificador
            //la lista de usuarios de portal, que no sean proveedores,que estén activos y que tengan el rol de solicitador. 
            //El id del rol solicitador se indica en la constante SOLICITADOR_ID. 
            //Si no está configurada la constante o no hay usuarios con ese rol, NO permitir ingresar el comprobante. 
            //Del usuario que se seleccione, interesa tomar su número de AN8 registrado en la tabla usuario.
            const buscarConstanteSOLICITADOR_ID = await Actions.callChain(context, {
                chain: 'application:buscar_constante',
                params: {
                    constante: paramConstante //'SOLICITADOR_ID'
                },
            });
            if (buscarConstanteSOLICITADOR_ID.existe === true && buscarConstanteSOLICITADOR_ID.valor != null) {
                solicitadorID = buscarConstanteSOLICITADOR_ID.valor;


                //busco lista de usuarios
                //filtro por los que tienen ID solicitador igual a constante y además son usuarios activos y no proveedores
                const responseGetAllRolUsuario = await Actions.callRest(context, {
                  endpoint: 'businessObjects/getall_RolUsuario',
                  uriParams: {
                    //q: "rolID ='" + solicitadorID + "' and suscriptorID = '" + $application.variables.suscriptor.id + "'",
                    q: "rolID in (" + solicitadorID + ") and suscriptorID = '" + $application.variables.suscriptor.id + "'",
                    limit: 1000,
                  },
                });
                if (responseGetAllRolUsuario.ok && responseGetAllRolUsuario.body.items.length > 0) {

                    // si hubo resultados, completar con información de cada usuario

                    const results = await ActionUtils.forEach(responseGetAllRolUsuario.body.items, async (rolUsuario, index) => {
                        // si el rol no está obsoleto para ese usuario, buscar usuario
                        const vigente = await this.verificarVigencia(context, { hoy: fechaHoy, fechaDesde: rolUsuario.fechaDesde, fechaHasta: rolUsuario.fechaHasta });
                        if (vigente) {

                            if (stringUsuarios !== "") {
                                stringUsuarios = stringUsuarios + ",";
                            }

                            stringUsuarios = stringUsuarios + rolUsuario.usuarioID;

                        }
                    }, { mode: 'serial' });

                    // buscar usuarios
                    const response = await Actions.callRest(context, {
                      endpoint: 'businessObjects/getall_Usuario',
                      uriParams: {
                        q: "id in (" + stringUsuarios + ") and estaActivo = true and esProveedor=false",
                        limit: 1000,
                      },
                    });

                    if (response.ok) {


                        const results2 = await ActionUtils.forEach(response.body.items, async (usuario, index) => {
                            listaSolicitadores.push({
                                id: usuario.id,
                                numeroAn8: usuario.numeroAn8,
                                nombre: usuario.nombre,
                                email: usuario.email
                            });

                        }, { mode: 'serial' });

                    }
                }

            }
            return { solicitadorID: solicitadorID, listaSolicitadores: listaSolicitadores };

        }

        /**
         * @param {Object} context
         * @param {Object} params
         * @param {number} params.hoy fecha tipo DATE()
         * @param {string} params.fechaDesde 
         * @param {string} params.fechaHasta 
         */
        async verificarVigencia(context, { hoy, fechaDesde, fechaHasta }) {
            const { $application, $constants, $variables } = context;
            let vigente = true;

            // si se informa fecha desde evaluamos contra hoy
            if (fechaDesde !== undefined && fechaDesde !== null && fechaDesde !== "") {
  
                if (parseInt(fechaDesde.replaceAll("-", "")) > hoy) {
                    vigente = false;
                }
            }
            if (fechaHasta !== undefined && fechaHasta !== null && fechaHasta !== "") {
       
                if (parseInt(fechaHasta.replaceAll("-", "")) < hoy) {
                    vigente = false;
                }
            }
            return vigente;
        }
    }
    return buscar_revisores_voucher;
});
