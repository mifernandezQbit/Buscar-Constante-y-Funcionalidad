define([
    'vb/action/actionChain',
    'vb/action/actions',
    'vb/action/actionUtils',
], (
    ActionChain,
    Actions,
    ActionUtils
) => {
    'use strict';

    class actBuscarCodCatUnidadNegocio extends ActionChain {

        /**
         * Busca código de categoría en centro de costos y verifica que esté configurado.
         * @param {Object} context
         * @param {Object} params
         * @param {string} params.unidadNegocio
         * @param {boolean} params.wfFacturas
         */
        async run(context, { unidadNegocio, wfFacturas = true }) {
            const { $application, $constants, $variables } = context;

            // defino valor de código de categoría
            let rtrnUnidadNegocio = unidadNegocio;
            let codCatUnNegocio = "";
            let ok = true;
            // Si unidad de negocios está en blanco o undefiend, error
            if (unidadNegocio === undefined || unidadNegocio === "") {
                ok = false;
                const notificarErrorBco = await Actions.callChain(context, {
                    chain: 'application:notificar_error',
                    params: {
                        codigo: 'centro-costo-invalido',
                        modoVisualizacion: '',
                    },
                });
            } else {

                // asumimos que no se va a usar WF
                let nroCodCatUnNegocio = 0;

                // busco constante con nro de códigod e categoría a usar para workflow
                const buscarConstante = await Actions.callChain(context, {
                    chain: 'buscar_constante',
                    params: {
                        constante: 'WF_CC_MCU_AUTORIZANTE',
                    },
                });

                if (buscarConstante.existe === true) {
                    nroCodCatUnNegocio = parseInt(buscarConstante.valor);
                }

                if (nroCodCatUnNegocio !== undefined && nroCodCatUnNegocio !== 0) {
                  //MIF Inicio override seguridad activada y roles
                  let seguridadCC = $application.variables.seguridadCCActivada;
                  let rolesJDEcc= $application.variables.userRoles.rolesJDE;
                
                  if (seguridadCC &&  $application.variables.seguridadCCItemsDD.MCU !==undefined && $application.variables.seguridadCCItemsDD.MCU !=="Y") {
                    seguridadCC = false;
                    rolesJDEcc=[]
                  }
                   //MIF Fin override seguridad activada y roles
                    // busco unidad de negocio
                    const response = await Actions.callRest(context, {
                        endpoint: 'GatewayPortal/postQ71PO_BuscarUbicaciones',
                        body: {
                            "P0006_Version": "",
                            "token": $application.variables.token,
                            "company": $application.variables.selectedCompany.company,
                            "description": "",
                            "businessUnitType": "",
                            "businessUnit": unidadNegocio,
                            "rolesJDE" : rolesJDEcc,// MIF $application.variables.userRoles.rolesJDE,
                            "seguridadInclusiva" : $application.variables.seguridadCCInclusiva,
                            "seguridadCCActivada":seguridadCC,//MIF $application.variables.seguridadCCActivada
                        },
                    });

                    await Actions.callChain(context, {
                        chain: 'application:verificar_respuesta_jdeError',
                        params: {
                            error: !response.ok,
                            funcion: 'BuscarUbicaciones',
                            funcionalidad: "",
                            tokenExpirado: response.body.tokenExpirado !== undefined ? response.body.tokenExpirado : false,
                            transaccion: unidadNegocio,
                            status: response.status,
                        },
                    });

                    if ((response.ok && response.body.rowset.length === 0)) {
                        rtrnUnidadNegocio = "";
                        ok = false;
                    }
                    else {
                        codCatUnNegocio = response.body.rowset[0].categoryCode[nroCodCatUnNegocio];

                        if (codCatUnNegocio.trim() === "") {
                            // error, no esta configurado el CC
                            ok = false;
                            const notificarError = await Actions.callChain(context, {
                                chain: 'application:notificar_error',
                                params: {
                                    codigo: 'falta-configuracion-wf',
                                    modoVisualizacion: '',
                                },
                            });

                            rtrnUnidadNegocio = "";

                            await Actions.callChain(context, {
                                chain: 'guardar_log',
                                params: {
                                    accion: 'CONFIGURACION_WF',
                                    suscriptorId: $application.variables.suscriptor.id,
                                    numeroAn8: $application.variables.user.numeroAn8,
                                    proveedor: $application.variables.user.esProveedor,
                                    funcionalidad: '',
                                    pagina: $application.currentPage.id,
                                    roles: $application.variables.userRoles.userRolesSt,
                                    usuario: $application.variables.user.ociUser,
                                    observaciones: 'Falta código de categoría en centro de costos para grupo autorizante',
                                },
                            });
                        }
                        else {
                            // verificar si hay un grupo autorizante definido para ese código sino va a dar error el wf al iniciarse

                            // busco constante con nro de grupo autorizante
                            // MIF P250 - Separamos la constante con nro de autorizante dependiendo de si es LD o FActuras
                            const constante = wfFacturas ? 'WF_NRO_AUTORIZANTE' : 'WF_NRO_AUTORIZANTE_LD';
                            const buscarConstante2 = await Actions.callChain(context, {
                                chain: 'buscar_constante',
                                params: {
                                    constante: constante //'WF_NRO_AUTORIZANTE',
                                },
                            });

                            // si constante no existe, error de configuración faltante
                            if (!buscarConstante2.existe || buscarConstante2.valor.trim() === "" || buscarConstante2.valor.trim() === "0") {
                                // error, no esta configurado el CC
                                ok = false;
                                const notificarError2 = await Actions.callChain(context, {
                                    chain: 'application:notificar_error',
                                    params: {
                                        codigo: 'falta-configuracion-wf-autorizante',
                                        modoVisualizacion: '',
                                    },
                                });

                                rtrnUnidadNegocio = "";

                                await Actions.callChain(context, {
                                    chain: 'application:guardar_log',
                                    params: {
                                        accion: 'CONFIGURACION_WF',
                                        suscriptorId: $application.variables.suscriptor.id,
                                        numeroAn8: $application.variables.user.numeroAn8,
                                        proveedor: $application.variables.user.esProveedor,
                                        funcionalidad: '',
                                        pagina: $application.currentPage.id,
                                        roles: $application.variables.userRoles.userRolesSt,
                                        usuario: $application.variables.user.ociUser,
                                        observaciones: constante //'WF_NRO_AUTORIZANTE',
                                    },
                                });
                            } else {
                                // busco el grupo 

                                const response2 = await Actions.callRest(context, {
                                    endpoint: 'GatewayPortal2/postQ71PO_VerificarGrupoWorkflow',
                                    body: {
                                        nroPrincipal: buscarConstante2.valor.trim(),
                                        tpEstructura: codCatUnNegocio,
                                        'P0150_Version': '',
                                        token: $variables.token,
                                    },
                                });
                                await Actions.callChain(context, {
                                    chain: 'application:verificar_respuesta_jdeError',
                                    params: {
                                        error: !response2.ok,
                                        funcion: 'VerificarGrupoWorkflow',
                                        funcionalidad: "",
                                        tokenExpirado: response2.body.tokenExpirado !== undefined ? response2.body.tokenExpirado : false,
                                        transaccion: buscarConstante2.valor.trim() + "-" + codCatUnNegocio,
                                    status:response2.status,
                                    },
                                });

                                // Verifico error
                                if (response2.ok && (response2.body.rowset===null || response2.body.rowset.length === 0)) {
                                    ok = false;
                                    const notificarError = await Actions.callChain(context, {
                                        chain: 'application:notificar_error',
                                        params: {
                                            codigo: 'falta-configuracion-wf-grupo',
                                            modoVisualizacion: '',
                                        },
                                    });

                                    rtrnUnidadNegocio = "";

                                    await Actions.callChain(context, {
                                        chain: 'application:guardar_log',
                                        params: {
                                            accion: 'CONFIGURACION_WF',
                                            suscriptorId: $application.variables.suscriptor.id,
                                            numeroAn8: $application.variables.user.numeroAn8,
                                            proveedor: $application.variables.user.esProveedor,
                                            funcionalidad: '',
                                            pagina: $application.currentPage.id,
                                            roles: $application.variables.userRoles.userRolesSt,
                                            usuario: $application.variables.user.ociUser,
                                            observaciones: 'Falta asignar autorizantes al grupo' + buscarConstante2.valor.trim() + "-" + codCatUnNegocio
                                        },
                                    });
                                }
                            }
                        }
                    }

                }
            }

            return { codCatUnNegocio: codCatUnNegocio.trim(), unidadNegocio: rtrnUnidadNegocio, ok: ok };
        }
    }

    return actBuscarCodCatUnidadNegocio;
});