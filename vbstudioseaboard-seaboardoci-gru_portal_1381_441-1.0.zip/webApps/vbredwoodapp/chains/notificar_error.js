define([
	'vb/action/actionChain',
	'vb/action/actions',
	'vb/action/actionUtils',
], (
	ActionChain,
	Actions,
	ActionUtils
) => {
	'use strict';

	class notificar_error extends ActionChain {

		/**
		 * Busca un código de error determinado y si lo encuentra dispara una notificación que  podría ser de tipo Error, Warning o informativa
		 * @param {Object} context
		 * @param {Object} params
		 * @param {string} params.codigo 
		 * @param {string} params.modoVisualizacion Si el mensaje debe permanecer visible hasta que el usuario lo cierre usar 'persist' caso contrario si el mensaje debe desaparecer solo transcurrido un tiempo usar 'transient'. Por defecto si no se informa esta parámetro actúa dependiendo del tipo de mensaje que se haya configurado en la tabla diccionariomensajes.
		 * @param {string} params.titulo 
		 * @param {string} params.descripcion 
		 * @param {string} params.tipoNotificacion 
		 * @return {boolean} 
		 */
		async run(context, {
			codigo,
			modoVisualizacion,
			titulo,
			descripcion,
			tipoNotificacion
		}) {
			const {
				$application
			} = context;
			let existe = false;

/**
			const buscarConstanteCUSTOM_NOTIFICATION_DURATION = await Actions.callChain(context, {
				chain: 'application:buscar_constante',
				params: {
					constante: 'CUSTOM_NOTIFICATION_DURATION',
				},
			});
			if (buscarConstanteCUSTOM_NOTIFICATION_DURATION.existe === true) {
				$application.variables.consCUSTOM_NOTIFICATION_DURATION = buscarConstanteCUSTOM_NOTIFICATION_DURATION.valor;
			}
			const buscarConstanteCUSTOM_NOTIFICATION_POSITION = await Actions.callChain(context, {
				chain: 'application:buscar_constante',
				params: {
					constante: 'CUSTOM_NOTIFICATION_POSITION',
				},
			});
			if (buscarConstanteCUSTOM_NOTIFICATION_POSITION.existe === true) {
				$application.variables.consCUSTOM_NOTIFICATION_POSITION = buscarConstanteCUSTOM_NOTIFICATION_POSITION.valor;
			} */

			if (codigo !== undefined && codigo !== null) {
				const response = await Actions.callRest(context, {
					endpoint: 'businessObjects/getall_DiccionarioMensajes',
					uriParams: {
						q: "codigo='" + codigo + "'",
					},
				});

				if (response.ok === true && response.body.items.length > 0) {
					existe = true;
let mensaje= response.body.items[0].descripcion + (descripcion !== undefined && descripcion !== null  && descripcion !== "" ?  descripcion : "");
					//custom notification
					$application.variables.customNotificationList.push({
						id: Date.now().toString(),
						summary: response.body.items[0].resumen,
						message: mensaje,//response.body.items[0].descripcion,
						type: response.body.items[0].tipoNotificacion,
						transient: (modoVisualizacion !== undefined && modoVisualizacion !== "") ? (modoVisualizacion === "persist" ? false : true) : (response.body.items[0].tipoNotificacion === "error" ? false : true),
						duration: $application.variables.consCUSTOM_NOTIFICATION_DURATION > 0 ? $application.variables.consCUSTOM_NOTIFICATION_DURATION : 10000,
						timestamp: Date.now(),
						position: $application.variables.consCUSTOM_NOTIFICATION_POSITION !== "" ? $application.variables.consCUSTOM_NOTIFICATION_POSITION : 'right',
					});

				} else {
				//custom notification
				$application.variables.customNotificationList.push({
					id: Date.now().toString(),
					summary: 'Código de error inválido',
					message: 'El código de error que se quiso notificar no existe.',
					type: 'info',
					transient: true,
					duration: $application.variables.consCUSTOM_NOTIFICATION_DURATION > 0 ? $application.variables.consCUSTOM_NOTIFICATION_DURATION : 10000,
					timestamp: Date.now(),
					position: $application.variables.consCUSTOM_NOTIFICATION_POSITION !== "" ? $application.variables.consCUSTOM_NOTIFICATION_POSITION : 'right',
				});

			}
			
			} 


			//if (titulo !== undefined && descripcion !== undefined && tipoNotificacion !== undefined) {
			if (titulo !== undefined && tipoNotificacion !== undefined) {
				//custom notification
				$application.variables.customNotificationList.push({
					id: Date.now().toString(),
					summary: titulo,
					message: descripcion,
					type: tipoNotificacion,
					transient: (modoVisualizacion !== undefined && modoVisualizacion !== "") ? (modoVisualizacion === "persist" ? false : true) : (tipoNotificacion === "error" ? false : true),
					duration: $application.variables.consCUSTOM_NOTIFICATION_DURATION > 0 ? $application.variables.consCUSTOM_NOTIFICATION_DURATION : 10000,
					timestamp: Date.now(),
					position: $application.variables.consCUSTOM_NOTIFICATION_POSITION !== "" ? $application.variables.consCUSTOM_NOTIFICATION_POSITION : 'right',
				});

			}

			return 'existe';
		}
	}

	return notificar_error;
});