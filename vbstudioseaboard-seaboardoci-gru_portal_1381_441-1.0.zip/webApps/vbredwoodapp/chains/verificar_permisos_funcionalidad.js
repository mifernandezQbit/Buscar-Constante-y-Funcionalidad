define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class verificar_permisos_funcionalidad extends ActionChain {

    /**
     * Verfiica una funcionalidad dada si existe en la lista de permisos del usuario
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.funcionalidad funcionalidad que se quiere verificar
     * @return {boolean} 
     */
    async run(context, { funcionalidad }) {
      const { $application } = context;

      const callFunction = await this.verificarExistenciaFuncionalidad(context, { funcionalidad: funcionalidad, permisosFuncionalidad: $application.variables.userFunctionalityList });

      return callFunction;
    }

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.funcionalidad 
     * @param {postQ71PO_ObtenerPermisosFuncionalidad[]} params.permisosFuncionalidad
     * @return {boolean} 
     */
    async verificarExistenciaFuncionalidad(context, { funcionalidad, permisosFuncionalidad }) {
      const { $application } = context;
    let k = 'funcionalidad';
let objIndex = permisosFuncionalidad.findIndex(
    (elemento) => elemento[k] === funcionalidad);
if (objIndex ===-1) {
  return false;
} 
else {
  return true;
}
    }
  }
  return verificar_permisos_funcionalidad;
});
