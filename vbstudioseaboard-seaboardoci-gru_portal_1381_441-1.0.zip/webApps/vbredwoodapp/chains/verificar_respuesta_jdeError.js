define([
        'vb/action/actionChain',
        'vb/action/actions',
        'vb/action/actionUtils',
    ], (
        ActionChain,
        Actions,
        ActionUtils) => {
    'use strict';

    class verificar_respuesta_jdeError extends ActionChain {

        /**
         * verifica si el token de jde expiró luego de haber ejecutado un rest de jde. si expiró alertar y hacer logout
         * @param {Object} context
         * @param {Object} params
         * @param {boolean} params.tokenExpirado
         * @param {boolean} params.error
         * @param {string} params.funcion
         * @param {string} params.observaciones
         * @param {string} params.transaccion
         * @param {string} params.funcionalidad
         * @param {object} params.body
         * @param {number} params.status
         * @param {boolean} params.respuestaTooLarge
         */
        async run(context, {
            tokenExpirado = false,
            error,
            funcion,
            observaciones,
            transaccion,
            funcionalidad,
            body = {},
            status = 502,
            respuestaTooLarge = false
        }) {
            const {
                $application,
                $constants,
                $variables
            } = context;
            if (error) {
                // ver si el error es por publicación de nueva versión o por falla del servicio
                if (body.detail !== undefined && body.detail !== null) {
                    // están usando una versión que quedó obsoleta
					          alert("Esta versión está obsoleta, vuelva a ingresar al portal desde la URL de inicio");
                } else {
                    // llamada a jde terminó en error de servicio, en cuyo caso deja entrada en tabla log
                    await Actions.callChain(context, {
                        chain: 'guardar_log',
                        params: {
                            accion: status === 504 ? "TIMEOUT_JDE" : "ERROR_FUNCION",
                            funcionalidad: funcionalidad,
                            numeroAn8: $variables.user.numeroAn8,
                            observaciones: observaciones,
                            pagina: $application.currentPage.id,
                            proveedor: $variables.user.esProveedor,
                            roles: $variables.userRoles.userRolesSt,
                            suscriptorId: $variables.suscriptor.id,
                            transaccion: funcion + (transaccion != null && transaccion !== "" ? (" - " + transaccion) : ""),
                            usuario: $variables.user.ociUser,
                        },
                    });

                    const notificarError2 = await Actions.callChain(context, {
                        chain: 'notificar_error',
                        params: {
                            codigo: status === 504 ? 'actualizar-jde-timeout' : 'actualizar-jde-error',
                            modoVisualizacion: '',
                            descripcion: funcion //MIF status === 504 ? funcion : "",
                        },
                    });
                }
            }

            // verifica si el token expiró
            if (tokenExpirado !== undefined && tokenExpirado === true) {

                // verifica si llamada a jde terminó en error, en cuyo caso deja entrada en tabla log
                await Actions.callChain(context, {
                    chain: 'guardar_log',
                    params: {
                        accion: 'TOKEN_EXPIRADO',
                        funcionalidad: funcionalidad,
                        numeroAn8: $variables.user.numeroAn8,
                        observaciones: observaciones,
                        pagina: $application.currentPage.id,
                        proveedor: $variables.user.esProveedor,
                        roles: $variables.userRoles.userRolesSt,
                        suscriptorId: $variables.suscriptor.id,
                        transaccion: funcion + (transaccion != null && transaccion !== "" ? (" - " + transaccion) : ""),
                        usuario: $variables.user.ociUser,
                    },
                });
                const notificarError = await Actions.callChain(context, {
                    chain: 'notificar_error',
                    params: {
                        codigo: 'token-expirado',
                        modoVisualizacion: '',
                    },
                });

                // sale de OCI
                await Actions.logout(context, {
                    //logoutUrl: 'https://idcs-094168c8a49d4a168e053b857479c986.identity.oraclecloud.com/ui/v1/signin',
                }, {
                    id: 'logout'
                });
            } else {
                //MIF- si el token no está expirado verificamos si la respuesta está completa o era demasiado grande para la función y hay que consultar
                // aplicando más filtros.
                if (respuestaTooLarge) {
                    // verifica si llamada a jde terminó en error, en cuyo caso deja entrada en tabla log
                    await Actions.callChain(context, {
                        chain: 'guardar_log',
                        params: {
                            accion: 'RESPUESTA_TOO_LARGE',
                            funcionalidad: funcionalidad,
                            numeroAn8: $variables.user.numeroAn8,
                            observaciones: observaciones,
                            pagina: $application.currentPage.id,
                            proveedor: $variables.user.esProveedor,
                            roles: $variables.userRoles.userRolesSt,
                            suscriptorId: $variables.suscriptor.id,
                            transaccion: funcion + (transaccion != null && transaccion !== "" ? (" - " + transaccion) : ""),
                            usuario: $variables.user.ociUser,
                        },
                    });
                    const notificarError = await Actions.callChain(context, {
                        chain: 'notificar_error',
                        params: {
                            codigo: 'respuesta-demasiado-grande',
                            modoVisualizacion: '',
                        },
                    });
                }

            }
        }
    }

    return verificar_respuesta_jdeError;
});