define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'resources/js/jsPDF'
], (
  ActionChain,
  Actions,
  ActionUtils,
  jsPDFRes
) => {
  'use strict';

  class convertir_y_subir_pdf extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.mensaje 
     * @param {string} params.nombrePDF 
     * @param {inParamListaArchivos} params.attributosJDE 
     * @param {boolean} params.inParamAdjuntoPDF 
     */
    async run(context, { mensaje, nombrePDF, attributosJDE, inParamAdjuntoPDF }) {
      const { $application, $variables } = context;

      const doc = new jsPDFRes.jsPDF();
   // Agrego nombre de quien escribe el mensaje
   let mensajeTemp = $variables.user.nombre+ " (" + $variables.user.email+") escribió: \n" + mensaje;
        doc.text(mensajeTemp, 10, 10);
      let op  = doc.output("arraybuffer", nombrePDF);
      

      let binary = '';
      let bytes = new Uint8Array( op );
      let len = bytes.byteLength;
      for (let i = 0; i < len; i++) {
        binary += String.fromCharCode( bytes[ i ] );
      }
      let b64FilePDF = window.btoa( binary )

     

      const subirArchivos = await Actions.callChain(context, {
        chain: 'subir_archivos',
        params: {
          inParamListaArchivos: [
  {
          archivo: b64FilePDF,
          nombreArchivo: nombrePDF,
          tipoAdjunto: "application/pdf",
        },
],
          inParamRequestSubirAdjunto: attributosJDE,
          inParamAdjunto: inParamAdjuntoPDF,
        },
      });

      return subirArchivos;
     
      
    }
  }

  return convertir_y_subir_pdf;
});
