define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class erroresJDE extends ActionChain {

    /**
     * @param {Object} context
     */
    
    async run(context, { arrayError }) {
      const { $application, $constants, $variables } = context;

   
      $variables.arrayErrorEditado = arrayError;


      
      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_DiccionarioMensajes',
        uriParams: {
          q: " codigo = '" + $variables.arrayErrorEditado[0].code + "' and suscriptorID= '" + $application.variables.suscriptor.id + "'"
        },
      });
      if (response.ok) {
        if (response.body.count > 0) {
          $variables.arrayErrorEditado[0].title = response.body.items[0].resumen;
          $variables.arrayErrorEditado[0].desc = response.body.items[0].descripcion;
        }
      }
      
      return $variables.arrayErrorEditado;

    }
  }

  return erroresJDE;
});
