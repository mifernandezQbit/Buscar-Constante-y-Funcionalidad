define([
        'vb/action/actionChain',
        'vb/action/actions',
        'vb/action/actionUtils',
    ], (
        ActionChain,
        Actions,
        ActionUtils) => {
    'use strict';

    class buscar_workflow_nodo extends ActionChain {

        /**
         * Busca la configuración de un nodo de workflow determinada y retorna la información condigurada.
         * @param {Object} context
         * @param {Object} params
         * @param {string} params.workflow
         * @param {string} params.nodo
         * @return {workflowNodo} 
         */
        async run(context, { workflow, nodo }) {
            const {
                $application,
                $constants,
                $variables
            } = context;
            let respuesta = {
                workflow: workflow,
                nodo: nodo,
                modificaDatosGrales: false,
                modificaContactos: false,
                modificaImpuestos: false,
                modificaTesoreria: false,
                modificaTransportistas: false,
                modificaOFAC: false,
                modificaContabilidad: false
            };
            if (workflow != null && nodo != null) {
                const response = await Actions.callRest(context, {
                    endpoint: 'businessObjects/getall_WorkflowNodo',
                    uriParams: {
                        q: "workflow ='" + workflow + "' and suscriptorID = '" + $application.variables.suscriptor.id + "' and nodo = '" + nodo + "'",
                    },
                });

                if (response.ok === true && response.body.items.length > 0) {
                    // guardo rolid
                    respuesta.rolID = response.body.items[0].rolID;
                    // Buscar rol id
                    if (response.body.items[0].rolID !== null && response.body.items[0].rolID !== 0) {
                        const response2 = await Actions.callRest(context, {
                            endpoint: 'businessObjects/get_Rol',
                            uriParams: {
                                'Rol_Id': response.body.items[0].rolID,
                            },
                        });

                        if (response2.ok) {
                            // guardo los permisos de las secciones
                            respuesta.modificaDatosGrales =response2.body.modificaDatosGrales !==null ? response2.body.modificaDatosGrales: false;
                            respuesta.modificaContactos = response2.body.modificaContactos!==null ? response2.body.modificaContactos : false;
                            respuesta.modificaImpuestos = response2.body.modificaImpuestos !==null ? response2.body.modificaImpuestos : false;
                            respuesta.modificaTesoreria = response2.body.modificaTesoreria!==null ? response2.body.modificaTesoreria :false;
                            respuesta.modificaTransportistas = response2.body.modificaTransportistas!== null ? response2.body.modificaTransportistas : false;
                            respuesta.modificaOFAC = response2.body.modificaOFAC!==null ? response2.body.modificaOFAC : false;
                            respuesta.modificaContabilidad = response2.body.modificaContabilidad!== null ? response2.body.modificaContabilidad : false;
                        }
                    }
                }

            }

			return respuesta;
        }
    }

    return buscar_workflow_nodo;
});
