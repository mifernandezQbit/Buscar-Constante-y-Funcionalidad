define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class id_transaccion extends ActionChain {

    /**
     * Concatenar valores clave para armar el id de la transacción adecuada según se necesite para guardar en la tabla log.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.tipoTransaccion '0' proveedor
     *     '1' voucher
     *     '2' pago
     *     '3' orden de compra, licitacion
     *     '4' viaje
     *     '5' wf
     * @param {string} params.tipoDocumento 
     * @param {string} params.nroDocumento 
     * @param {string} params.ciaDocumento 
     * @param {string} params.sfxDocumento 
     * @param {string} params.nroLinea 
     * @param {string} params.nroViaje 
     * @param {string} params.depositoPlanif 
     * @param {string} params.wfProceso 
     * @param {string} params.wfIdActividad 
     * @param {string} params.nroProveedor 
     * @param {string} params.nroPago 
     * @param {string} params.tipoPago 
     * @param {string} params.instrumentoPago 
     */
    async run(context, { tipoTransaccion, tipoDocumento, nroDocumento, ciaDocumento, sfxDocumento, nroLinea, nroViaje, depositoPlanif, wfProceso, wfIdActividad, nroProveedor, nroPago, tipoPago, instrumentoPago }) {
      const { $application, $constants, $variables } = context;

let idTransaccion="";
if (tipoTransaccion !==undefined) {
// proveedor
      if (tipoTransaccion === '0' && nroProveedor !== undefined) {
idTransaccion = nroProveedor.toString().padStart(8,'0');
      }
// voucher
      if (tipoTransaccion === '1') {
        if (tipoDocumento!==undefined) { 
          idTransaccion = tipoDocumento ;
        }
        if (nroDocumento!==undefined) { 
          idTransaccion = idTransaccion + '|'+nroDocumento.toString().padStart(8,'0') ;
        }
          if (ciaDocumento!==undefined) { 
          idTransaccion =idTransaccion + '|'+ ciaDocumento.padStart(5,'0');
        }
 if (sfxDocumento!==undefined) { 
        idTransaccion = idTransaccion + '|'+ sfxDocumento.padStart(3,'0');
      }
      }
      // pago
            if (tipoTransaccion === '2') {
   if (nroPago!==undefined) { 
          idTransaccion = nroPago.toString().padStart(8,'0') ;
        }
        if (tipoPago!==undefined) { 
          idTransaccion = idTransaccion + '|'+tipoPago;
        }
          if (instrumentoPago!==undefined) { 
          idTransaccion =idTransaccion + '|'+ instrumentoPago;
        }
      }
      // orden o licitacion
              if (tipoTransaccion === '3') {
				      if (tipoDocumento!==undefined) { 
          idTransaccion = tipoDocumento ;
        }
        if (nroDocumento!==undefined) { 
          idTransaccion = idTransaccion + '|'+nroDocumento.toString().padStart(8,'0') ;
        }
          if (ciaDocumento!==undefined) { 
          idTransaccion =idTransaccion + '|'+ ciaDocumento.padStart(5,'0');
        }
 if (sfxDocumento!==undefined) { 
        idTransaccion = idTransaccion + '|'+ sfxDocumento.padStart(3,'0');
      }
	   if (nroLinea!==undefined) { 
        idTransaccion = idTransaccion + '|'+ nroLinea;
      }
      }
      // viaje
                if (tipoTransaccion === '4') {
					      if (nroProveedor!==undefined) { 
          idTransaccion = nroProveedor.toString().padStart(8,'0') ;
        }
        if (nroViaje!==undefined) { 
          idTransaccion = idTransaccion + '|'+nroViaje.toString().padStart(8,'0') ;
        }
          if (depositoPlanif!==undefined) { 
          idTransaccion =idTransaccion + '|'+ depositoPlanif.trim();
        }	
					
      }
      // workflow
                if (tipoTransaccion === '5') {
								      if (wfProceso!==undefined) { 
          idTransaccion = wfProceso ;
        }
        if (wfIdActividad!==undefined) { 
          idTransaccion = idTransaccion + '|'+wfIdActividad ;
        }
      }
      }

      return idTransaccion;
    }
  }

  return id_transaccion;
});