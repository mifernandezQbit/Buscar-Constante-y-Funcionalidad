define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class enviar_mail extends ActionChain {

    /**
     * Envia mail
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.notificationType 
     * @param {any} params.documentType 
     * @param {any} params.documentNbr 
     * @param {any} params.documentCompany 
     * @param {any} params.documentSfx 
     * @param {any} params.vinv 
     * @param {any} params.taxID 
     * @param {any} params.supplierNbr 
     * @param {any} params.supplierName 
     * @param {any} params.buyer 
     * @param {any} params.buyerName 
     * @param {any} params.mailTo 
     * @param {any} params.copyTo 
     * @param {any} params.body 
     * @param {any} params.subject 
     * @param {any} params.loadNumber 
     * @param {any} params.branchPlant 
     * @param {any} params.lineNumber 
     * @param {any} params.companyDesc 
     * @param {any} params.authorName 
     */
    async run(context, { notificationType, documentType, documentNbr, documentCompany, documentSfx, vinv, taxID, supplierNbr, supplierName, buyer, buyerName, mailTo, copyTo, body, subject, loadNumber, branchPlant, lineNumber, companyDesc, authorName }) {
      const { $application } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'GatewayPortal/postQ71PO_EnviarMail',
        body: {
          token: $application.variables.token,
          notificationType: notificationType,
          subject: subject,
          to: mailTo,
          copyTo: copyTo,
          documentType: documentType,
          documentNbr: documentNbr,
          documentCompany: documentCompany,
          documentSfx: documentSfx,
          buyer: buyer,
          loadNumber: loadNumber,
          branchPlant: branchPlant,
          lineNumber: lineNumber,
          body: body,
          companyDesc: companyDesc,
          supplierNumber: supplierNbr,
          supplierAlphaName: supplierName,
          authorName: authorName,
        },
      });
      await Actions.callChain(context, {
        chain: 'application:verificar_respuesta_jdeError',
        params: {
          error: !response.ok,
          funcion: 'EnviarMail',
          funcionalidad: '',
          tokenExpirado: response.body.tokenExpirado !== undefined ? response.body.tokenExpirado : false,
          status:response.status,
        },
      });

    }
  }

  return enviar_mail;
});
