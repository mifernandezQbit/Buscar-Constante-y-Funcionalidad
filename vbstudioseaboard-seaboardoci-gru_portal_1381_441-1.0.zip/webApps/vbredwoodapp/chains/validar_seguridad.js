define([
        'vb/action/actionChain',
        'vb/action/actions',
        'vb/action/actionUtils',
    ], (
        ActionChain,
        Actions,
        ActionUtils) => {
    'use strict';

    class validar_seguridad extends ActionChain {

        /**
         * Valida seguridad en JDE de acuerdo a la configuración que se haya realizado para la funcionalidadID en cuestión.
         * @param {Object} context
         * @param {Object} params
         * @param {string} params.funcionalidadID
         * @param {string} params.accionJDE
         * @param {string} params.valor valor a verificar si pasa la seguridad
         * @param {string} params.funcionalidad
         * @param {string} params.nroProveedor
         * @return {boolean}
         */
        async run(context, {
            funcionalidadID,
            accionJDE,
            valor,
            funcionalidad,
            nroProveedor
        }) {
            const { $application, $constants, $variables } = context;

            //MIF Inicio override seguridad activada y roles
            let seguridadCC = $application.variables.seguridadCCActivada;
            let rolesJDEcc = $application.variables.userRoles.rolesJDE;

            if (seguridadCC && $application.variables.seguridadCCItemsDD.MCU !== undefined && $application.variables.seguridadCCItemsDD.MCU !== "Y") {
                seguridadCC = false;
                rolesJDEcc = [];
            }
            //MIF Fin override seguridad activada y roles

            let seguridadOK = (!$variables.user.esProveedor && seguridadCC) ? false : true;

            // si seguridadOK es false quiere decir que hay que verificar la seguridad para determinar si está ok o no
            if (!seguridadOK) {
                let tablasError = "";
                let parFuncionalidadID = funcionalidadID;
                // Si no se informa id de funcionalidad, recuperarlo desde la funcionalidad
                if (funcionalidadID === undefined || funcionalidadID === "") {
                    const response3 = await Actions.callRest(context, {
                        endpoint: 'businessObjects/getall_Funcionalidad',
                        uriParams: {
                            limit: $variables.consMaxBORecords,
                            q: "funcionalidad ='" + funcionalidad + "' and suscriptorID= '" + $variables.suscriptor.id + "'",
                            onlyData: true,
                        },
                    });

                    if (response3.ok && response3.body.count > 0) {
                        parFuncionalidadID = response3.body.items[0].id;
                    }
                }

                if (parFuncionalidadID !== undefined && parFuncionalidadID !== "") {

                    // Verifico si pasa la seguridad
                    // buscamos configuración en portal para determinar que funcionalidad / tablas / acción se va a mirar la seguridad
                    const response = await Actions.callRest(context, {
                        endpoint: 'businessObjects/getall_SeguridadJde',
                        uriParams: {
                            limit: $variables.consMaxBORecords,
                            q: "funcionalidadID ='" + parFuncionalidadID + "' and suscriptorID= '" + $variables.suscriptor.id + "' and accionJDE = '" + accionJDE + "'",
                            onlyData: true,
                        },
                    });

                    if (response.ok) {

                        if (response.body.count > 0) {
                            // Si  hay configurada seguridad para esa combinación de funcionalidad + acciónJDE, hay que verificar si pasa la seguridad
                            // preparo lista de objetos a verificar
                            let seguridadJDE = [];

                            const results = await ActionUtils.forEach(response.body.items, async(item, index) => {
                                seguridadJDE.push({
                                    "nombreObjeto": item.nombreObjeto,
                                    "aliasDD": item.aliasDD,
                                    "accionJDE": item.accionObjeto,
                                    "unidadNegocio": valor
                                });
                            }, {
                                mode: 'serial'
                            });

                            const response2 = await Actions.callRest(context, {
                                endpoint: 'GatewayPortal3/postQ71PO_ValidarSeguridadCC',
                                body: {
                                    "rolesJDE": $variables.userRoles.rolesJDE,
                                    "seguridadJDE": seguridadJDE,
                                    "seguridadInclusiva": $variables.seguridadCCInclusiva,
                                    "seguridadCCActivada": $variables.seguridadCCActivada,
                                    "token": $variables.token
                                },
                            });

                            await Actions.callChain(context, {
                                chain: 'verificar_respuesta_jdeError',
                                params: {
                                    error: !response2.ok,
                                    funcion: 'ValidarSeguridadCC',
                                    funcionalidad: funcionalidad,
                                    tokenExpirado: response2.body.tokenExpirado,
                                    transaccion: funcionalidad + "-" + accionJDE + "-" + valor,
                                    status: response2.status,
                                },
                            });

                            if (response2.ok) {
                                if (!response2.body.errorJde) {
                                    seguridadOK = response2.body.data.seguridadOK;
                                    tablasError = response2.body.rowset
                                        .filter(item => !item.unidadNegocioOK)
                                        .map(item => "-" + item.nombreObjeto + " " + (item.accionJDE ?? ""))
                                        .join("");

                                } else {
                                    // Se produjo un error de base de datos al querer recuperar los datos, se indica error de servidor y se considera que la seguridad no está ok.
                                    const notificarError = await Actions.callChain(context, {
                                        chain: 'notificar_error',
                                        params: {
                                            codigo: 'codigo-error-no-indicado',
                                        },
                                    });
                                }
                            }
                        } else {
                            // Si no se configuró la tabla de seguridad para esta funcionalidad + acción
                            // notificar el error de falta de configuración

                            const notificarError2 = await Actions.callChain(context, {
                                chain: 'notificar_error',
                                params: {
                                    descripcion: "Falta definir, en la tabla SeguridadJDE del portal, configuración para que se pueda aplicar la seguridad por centro de costos ya que la misma se encuentra activada. Contacte a la mesa de ayuda y dele la siguiente información sobre la configuración faltante --> Funcionalidad " + funcionalidad + " - Acción JDE: " + accionJDE,
                                    titulo: 'Falta configuración de seguridad',
                                    tipoNotificacion: 'error',
                                },
                            });

                        }
                    } else {
                        // Se produjo un error de base de datos al querer recuperar los datos, se indica error de servidor y se considera que la seguridad no está ok.
                        const notificarError = await Actions.callChain(context, {
                            chain: 'notificar_error',
                            params: {
                                codigo: 'codigo-error-no-indicado',
                            },
                        });
                    }
                }

                // Si la seguridad no está ok por algún motivo, se indica mensaje al respecto
                if (!seguridadOK) {
                    if (nroProveedor !== undefined && nroProveedor !== "" && nroProveedor !== "0") {
                        await Actions.callChain(context, {
                            chain: 'notificar_error',
                            params: {
                                codigo: 'seguridad-sin-permiso',
                                descripcion: "Funcionalidad: " + funcionalidad + " - Accion: " + accionJDE + " - Valor:" + valor + " - Proveedor:" + nroProveedor + (tablasError !== "" ? " - Tablas: " + tablasError : ""),
                            },
                        });
                    } else {
                        await Actions.callChain(context, {
                            chain: 'notificar_error',
                            params: {
                                codigo: 'seguridad-sin-permiso',
                                descripcion: "Funcionalidad: " + funcionalidad + " - Accion: " + accionJDE + " - Valor:" + valor + (tablasError !== "" ? " - Tablas: " + tablasError : ""),
                            },
                        });
                    }
                }
            }
if (!$application.variables.user.esProveedor && seguridadCC) {
            await Actions.callChain(context, {
              chain: 'application:guardar_log',
              params: {
                accion: 'VALIDAR_SEGURIDAD_MCU',
                suscriptorId: $application.variables.suscriptor.id,
                numeroAn8: $application.variables.user.numeroAn8,
                proveedor: $application.variables.user.esProveedor,
                pagina: $application.currentPage.id,
                roles: $application.variables.userRoles.userRolesSt,
                usuario: $application.variables.user.ociUser,
                observaciones: "Resultado verificación seguridad: " + seguridadOK ? "CON PERMISO" : "SIN PERMISO",
                funcionalidad: $application.currentPage.id,
                transaccion:  funcionalidad + " - " +  accionJDE+  " - "+nroProveedor+" - "+valor + " - ",
              },
            });
            }
            return seguridadOK;
        }
    }
    return validar_seguridad;
});
