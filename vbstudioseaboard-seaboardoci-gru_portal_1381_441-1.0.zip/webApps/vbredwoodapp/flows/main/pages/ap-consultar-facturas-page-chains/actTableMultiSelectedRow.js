define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojkeyset',
], (
  ActionChain,
  Actions,
  ActionUtils,
  KeySet
) => {
  'use strict';

  class actTableMultiSelectedRow extends ActionChain {

    async run(context, { keys, selected }) {
      const { $page, $flow, $application } = context;

      if (!keys || keys.length <= 1) {
        return;
      }

      const lastKey = keys[keys.length - 1];

      // Solo la variable — VB propaga el cambio al componente vía two-way binding
      $page.variables.vouchersSelectedKeys = {
        row: new KeySet.KeySetImpl([lastKey]),
        column: new KeySet.KeySetImpl([])
      };
    }
  }

  return actTableMultiSelectedRow;
});
