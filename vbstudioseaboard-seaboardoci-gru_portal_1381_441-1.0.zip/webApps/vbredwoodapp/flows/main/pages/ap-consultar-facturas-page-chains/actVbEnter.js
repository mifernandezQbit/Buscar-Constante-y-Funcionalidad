define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actVbEnter extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $titulo, $variables } = context;

      $page.variables.permisoConsultarFacturas = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: "CONSULTAR_FACTURAS",
        },
      });

      $page.variables.permisoConsultarPagos = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: 'CONSULTAR_PAGOS',
        },
      });

      $page.variables.permisoChatFacturas = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: 'CHAT_FACTURA',
        },
      });
      if ($page.variables.permisoConsultarFacturas.existe === false) {
        //entra si NO tienen permisos a "CONSULTAR_FACTURAS"
        // Guardar Log de Acceso Restrigido y Notificación Visual

        const guardarLog = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'INTENTO_INGRESO_NH',
            funcionalidad: 'CONSULTAR_FACTURAS',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
          },
        });

        await Actions.navigateToPage(context, {
          page: 'acceso-no-autorizado',
        });

        // prevenir la navegación
        event.preventDefault();

      } else {

        const guardarLog4 = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'INGRESA',
            funcionalidad: 'CONSULTAR_FACTURAS',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            proveedor: $application.variables.user.esProveedor,
            suscriptorId: $application.variables.user.suscriptorID,
            usuario: $application.variables.user.ociUser,
            roles: $application.variables.userRoles.userRolesSt,
          },
        });

        //inicio valor mensaje de table sin datos, sin busqueda aún
        $page.variables.tblNoDataVouchers = " ";

        // cargar los 4 parametros de entrada en requestQ71PO_BuscarVouchers
        // cargar el titulo del page que viene como parametro de entrada
        // si viene Estado Pago y Es Proveedor, llama al EndPoint ConsultarVoucher automaticamente
        // cargar token en variable request
        //cargar el combo de Tipos de Documentos desde UDC ADP

        $page.variables.requestQ71PO_BuscarVouchers.token = $application.variables.token;

        //resumir por default true
        $page.variables.requestQ71PO_BuscarVouchers.resumir = true;

        $page.variables.requestQ71PO_BuscarVouchers.estadoPago = $page.variables.paramEstadoPago;

        $page.variables.requestQ71PO_BuscarVouchers.cia = $application.variables.user.ciaDefault;

        const buscarConstanteFechaDesde = await Actions.callChain(context, {
          chain: 'application:buscar_constante',
          params: {
            constante: 'FECHA_DESDE',
          },
        });

        if (buscarConstanteFechaDesde.existe) {

          const formatDateString = await $application.functions.formatDateString(buscarConstanteFechaDesde.valor,  "yyyy-MM-dd");

          $page.variables.requestQ71PO_BuscarVouchers.fechaDesde = buscarConstanteFechaDesde.valor;
           $page.variables.auxFechaDesde = formatDateString;
        }

        if (!$application.variables.user.ciaDefault || $application.variables.user.ciaDefault === "") {

          const buscarConstanteCia = await Actions.callChain(context, {
            chain: 'application:buscar_constante',
            params: {
              constante: 'DEFAULT_CO'
            },
          });

          if (buscarConstanteCia.count !== 0) {
            $application.variables.selectedCompany.company = buscarConstanteCia.valor;
            $page.variables.requestQ71PO_BuscarVouchers.cia = buscarConstanteCia.valor;
          }
        }

        if ($application.variables.user.esProveedor === true) {

          $page.variables.requestQ71PO_BuscarVouchers.nroProveedor = $application.variables.user.numeroAn8;
        }

        //busco versionJDE P4312 que vino por parametro de la page
        //si no lo intento levantar de la constante de la BO P4313_Version

        if (($page.variables.paramVersionJDE !== "") && ($page.variables.paramVersionJDE !== "undefined") && ($page.variables.paramVersionJDE !== null)) {

          $page.variables.requestQ71PO_BuscarVouchers.P0411_Version = $page.variables.paramVersionJDE;

        } else {

          const buscarConstanteP0411_Version = await Actions.callChain(context, {
            chain: 'application:buscar_constante',
            params: {
              constante: 'P0411_Version',
            },
          });

          if (buscarConstanteP0411_Version.existe === true) {
            $page.variables.requestQ71PO_BuscarVouchers.P0411_Version = buscarConstanteP0411_Version.valor;
          } 
        }

               const buscarConstanteP0411_VersionMatch = await Actions.callChain(context, {
            chain: 'application:buscar_constante',
            params: {
              constante: 'P0411_VersionMatch',
            },
          });

          if (buscarConstanteP0411_VersionMatch.existe === true) {
            $page.variables.paramVersionJDEmatching = buscarConstanteP0411_VersionMatch.valor;
          };

        //obtener valor constante UDC Description02 para poder filtrar tipos de comprobante
        const buscarConstanteUDC_D02 = await Actions.callChain(context, {
          chain: 'application:buscar_constante',
          params: {
            constante: $page.variables.paramUDC_D02,
          },
        });
        if (buscarConstanteUDC_D02.count !== 0) {
          $page.variables.UDC_D02 = buscarConstanteUDC_D02.valor;
        } else {
          $page.variables.UDC_D02 = "";
        }

        // llamar endpoint gateway buscar valores udc con parametros 00 DV y "*PORTAL*"
        const responseBuscarValoresUDC00DVSEABOARD = await Actions.callRest(context, {
          endpoint: 'GatewayPortal/postQ71PO_BuscarValoresUDC',
          body: {
            "token": $application.variables.token,
            "P0004A_Version": "",
            "udcToSearch": [
              {
                "productCode": "00",
                "userDefinedCode": "DV",
                "description1": "",
                "description2": "*" + $page.variables.UDC_D02 + "*",
                "specialHandling": ""
              },{
                "productCode": "76",
                "userDefinedCode": "AF",
                "description1": "",
                "description2": "",
                "specialHandling": ""
              }
            ]
          },
        });

        await Actions.callChain(context, {
          chain: 'application:verificar_respuesta_jdeError',
          params: {
            error: !responseBuscarValoresUDC00DVSEABOARD.ok,
            funcion: 'BuscarValoresUDC',
            funcionalidad: 'CONSULTAR_FACTURAS',
            tokenExpirado: responseBuscarValoresUDC00DVSEABOARD.body.tokenExpirado !== undefined ? responseBuscarValoresUDC00DVSEABOARD.body.tokenExpirado : false,
            status: responseBuscarValoresUDC00DVSEABOARD.status,
          },
        });

        if (responseBuscarValoresUDC00DVSEABOARD.body.success === true) {

          $page.variables.rowset00DVSEABOARD = responseBuscarValoresUDC00DVSEABOARD.body.rowset[0].codesList;
          $page.variables.rowset00DVSEABOARDTipoDoc = responseBuscarValoresUDC00DVSEABOARD.body.rowset[1].codesList;

          // Agregar un objeto vacío
          $page.variables.rowset00DVSEABOARD.unshift({
            "code": "",
            "description01": "",
            "description02": "",
            "specialHandling": "",
            "hardCoded": ""
          });
          $page.variables.rowset00DVSEABOARDTipoDoc.unshift({
            "code": "",
            "description01": "",
            "description02": "",
            "specialHandling": "",
            "hardCoded": ""
          });
          
        }

        // llamar al endpoint automaticamente si EstadoPago vino con dato y es Proveedor

        if ($page.variables.requestQ71PO_BuscarVouchers.estadoPago !== undefined && $page.variables.requestQ71PO_BuscarVouchers.estadoPago !== "" && $application.variables.user.esProveedor === true) {


          $variables.buscando = true;
 //MIF Inicio override seguridad activada y roles
                  let seguridadCC = $application.variables.seguridadCCActivada;
                  let rolesJDEcc= $application.variables.userRoles.rolesJDE;
                
                  if (seguridadCC &&  $application.variables.seguridadCCItemsDD.MCU !==undefined && $application.variables.seguridadCCItemsDD.MCU !=="Y") {
                    seguridadCC = false;
                    rolesJDEcc=[];

                  }
                   //MIF Fin override seguridad activada y roles
          const response = await Actions.callRest(context, {
            endpoint: 'GatewayPortal/postQ71PO_BuscarVouchers',
            body: {
              "token": $page.variables.requestQ71PO_BuscarVouchers.token,
              "nroProveedor": $page.variables.requestQ71PO_BuscarVouchers.nroProveedor,
              "fechaDesde": buscarConstanteFechaDesde.valor,
              "tipoDocumento": $page.variables.requestQ71PO_BuscarVouchers.tipoDocumento,
              "estadoPago": $page.variables.requestQ71PO_BuscarVouchers.estadoPago,
              "nroFactura": $page.variables.requestQ71PO_BuscarVouchers.nroFactura,
              "cia": $page.variables.requestQ71PO_BuscarVouchers.cia,
              "ordenCompra": $page.variables.requestQ71PO_BuscarVouchers.ordenCompra,
              "tipoOCompra": $page.variables.requestQ71PO_BuscarVouchers.tipoOCompra,
              "resumir": $page.variables.requestQ71PO_BuscarVouchers.resumir,
              "P0411_Version": $page.variables.requestQ71PO_BuscarVouchers.P0411_Version,
              "rolesJDE":rolesJDEcc,
              "seguridadInclusiva":$application.variables.seguridadCCInclusiva,
               "seguridadCCActivada":seguridadCC,
            },
          });

       $variables.buscando = false;

          await Actions.callChain(context, {
            chain: 'application:verificar_respuesta_jdeError',
            params: {
              error: !response.ok,
              funcion: 'BuscarVouchers',
              funcionalidad: 'CONSULTAR_FACTURAS',
              tokenExpirado: response.body.tokenExpirado !== undefined ? response.body.tokenExpirado : false,
              status:response.status,
            },
          });

          if (response.ok && response.body.success === true) {

            $page.variables.rowsetVouchers = response.body.rowset;

          } else {
if (response.ok){
            //log sobre fragmento erroresJDE
            $page.variables.erroresJDE = response.errorsList;
}
          }
        }

      }

    }
  }

  return actVbEnter;
});
