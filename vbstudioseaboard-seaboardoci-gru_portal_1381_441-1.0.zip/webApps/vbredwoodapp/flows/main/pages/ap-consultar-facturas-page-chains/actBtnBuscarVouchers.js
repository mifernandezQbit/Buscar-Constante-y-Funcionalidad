define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnConsultarVouchers extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $variables } = context;

      if ($page.variables.requestQ71PO_BuscarVouchers.nroProveedor === undefined || $page.variables.requestQ71PO_BuscarVouchers.nroProveedor === "") {
        const notificarError = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            modoVisualizacion: '',
            codigo: 'nro-proveedor-obligatorio',
          },
        });

      } else {
        $variables.buscando = true;
        
        $page.variables.tblNoDataVouchers = $page.variables.diccionarioMensajes['04-aguarde-consultando-datos-es']; //"Cargando, por favor aguarde..."; 

        //reseteo Vouchers encontrados si ya se hizo otra búsqueda en esta instancia de uso
        $page.variables.rowsetVouchers = [];


        // seteo los fields que vienen de fragmentos y que no puedo actualizarlos sobre la variable request a través de un action chains
        //...
        $page.variables.requestQ71PO_BuscarVouchers.cia = $application.variables.selectedCompany.company;

        if ($application.variables.user.esProveedor === true) {
          $page.variables.requestQ71PO_BuscarVouchers.nroProveedor = $application.variables.user.numeroAn8;
        } else {
          $page.variables.requestQ71PO_BuscarVouchers.nroProveedor = $variables.requestQ71PO_BuscarVouchers.nroProveedor;
        }

        //agrego * * para que pueda hacer busquedas parciales de nro de factura y nro orden de compra
        if ($page.variables.requestQ71PO_BuscarVouchers.nroFactura !== undefined && $page.variables.requestQ71PO_BuscarVouchers.nroFactura !== "") {

          $page.variables.requestQ71PO_BuscarVouchers.nroFactura = '*' + $page.variables.requestQ71PO_BuscarVouchers.nroFactura.replace(/^\*+|\*+$/g, '') + '*';
         
        }

        $page.variables.requestQ71PO_BuscarVouchers.fechaDesde = $page.functions.formatDateString($page.variables.auxFechaDesde, $application.variables.preferenciasUsuarioJde.simpleDateFormat);
        // INICIO LÓGICA SEGURIDAD MCU: Se evnían datos para verificar seguridad por centro de costos si está activa
         //MIF Inicio override seguridad activada y roles
        let seguridadCC = $application.variables.seguridadCCActivada;
        let rolesJDEcc= $application.variables.userRoles.rolesJDE;
      
        if (seguridadCC &&  $application.variables.seguridadCCItemsDD.MCU !==undefined && $application.variables.seguridadCCItemsDD.MCU !=="Y") {
          seguridadCC = false;
          rolesJDEcc=[];
        }
          //MIF Fin override seguridad activada y roles
        
        $page.variables.requestQ71PO_BuscarVouchers.rolesJDE =rolesJDEcc,
        $page.variables.requestQ71PO_BuscarVouchers.seguridadInclusiva = $application.variables.seguridadCCInclusiva;
        $page.variables.requestQ71PO_BuscarVouchers.seguridadCCActivada =seguridadCC
        // FIN LÓGICA SEGURIDAD MCU


        if ($page.variables.requestQ71PO_BuscarVouchers.cia !== undefined && $page.variables.requestQ71PO_BuscarVouchers.cia !== "") {

     // guardo entrada reflejando evento buscar
             await Actions.callChain(context, {
              chain: 'application:guardar_log',
              params: {
                accion: 'BUSCAR',
                funcionalidad: 'CONSULTAR_FACTURAS',
                numeroAn8: $application.variables.user.numeroAn8,
                pagina: $flow.currentPage,
                suscriptorId: $application.variables.suscriptor.id,
                usuario: $application.variables.user.ociUser,
                proveedor: $application.variables.user.esProveedor,
                roles: $application.variables.userRoles.userRolesSt,
                transaccion: $page.variables.requestQ71PO_BuscarVouchers.nroProveedor + "-" +$page.variables.requestQ71PO_BuscarVouchers.nroFactura + 
                "-" + $page.variables.requestQ71PO_BuscarVouchers.fechaDesde ,
                observaciones:"",
              },
            });


          const response = await Actions.callRest(context, {
            endpoint: 'GatewayPortal/postQ71PO_BuscarVouchers',
            body: $page.variables.requestQ71PO_BuscarVouchers,
          });
          
          await Actions.callChain(context, {
            chain: 'application:verificar_respuesta_jdeError',
            params: {
              error: !response.ok,
              funcion: 'BuscarVouchers',
              funcionalidad: 'CONSULTAR_FACTURAS',
              tokenExpirado: response.body.tokenExpirado !== undefined ? response.body.tokenExpirado : false,
              status: response.status,
            },
          });


          if (response.body.success === true) {

            $page.variables.rowsetVouchers = (response.body.rowset || []).map(r => ({
              ...r,
              // Normaliza SIEMPRE a ISO yyyy-MM-dd para ordenar perfecto
              _fechaFacturaRaw: $application.functions.toIsoDate(r.fechaFactura, $application.variables.preferenciasUsuarioJde.simpleDateFormat)
            }));

            if (!$page.variables.rowsetVouchers.item) {
              $page.variables.mensajeSinDatos = "No se encontraron datos para mostrar.";
            }

          } else {

if (response.ok){
            //log sobre fragmento erroresJDE
            const erroresJDE = await Actions.callChain(context, {
              chain: 'application:erroresJDE',
              params: {
                arrayError: response.errorsList
              },
            });
            if (erroresJDE.length >= 1) {
              $page.variables.erroresJDE = erroresJDE;
            }

            const guardarLog3 = await Actions.callChain(context, {
              chain: 'application:guardar_log',
              params: {
                accion: 'FALLA_FUNCION',
                funcionalidad: 'CONSULTAR_FACTURAS',
                numeroAn8: $application.variables.user.numeroAn8,
                pagina: $flow.currentPage,
                suscriptorId: $application.variables.suscriptor.id,
                usuario: $application.variables.user.ociUser,
                proveedor: $application.variables.user.esProveedor,
                roles: $application.variables.userRoles.userRolesSt,
              },
            });
          }
          }
        } else {
          if ($page.variables.requestQ71PO_BuscarVouchers.cia === undefined || $page.variables.requestQ71PO_BuscarVouchers.cia === "") {
            const notificarError2 = await Actions.callChain(context, {
              chain: 'application:notificar_error',
              params: {
                codigo: 'dato-obligatorio',
                modoVisualizacion: '',
              },
            });
          }
          if ($page.variables.requestQ71PO_BuscarVouchers.estadoPago === undefined || $page.variables.requestQ71PO_BuscarVouchers.estadoPago === "") {

            const notificarError3 = await Actions.callChain(context, {
              chain: 'application:notificar_error',
              params: {
                codigo: 'dato-obligatorio',
                modoVisualizacion: '',
              },
            });
          }
        }
        $variables.buscando = false;
      }
    }
  }

  return actBtnConsultarVouchers;
});

