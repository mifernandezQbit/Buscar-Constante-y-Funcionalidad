define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actDateFechaDesde extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $event } = context;

      $page.variables.requestQ71PO_BuscarVouchers.fechaDesde = value;
    }
  }

  return actDateFechaDesde;
});
