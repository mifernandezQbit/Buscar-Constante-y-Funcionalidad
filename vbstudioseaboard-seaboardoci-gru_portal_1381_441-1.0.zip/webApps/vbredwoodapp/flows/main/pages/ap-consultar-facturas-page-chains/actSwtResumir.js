define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actSwtResumir extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {boolean} params.value 
     * @return {boolean} 
     */
    async run(context, { value = false }) {
      const { $page, $flow, $application, $event } = context;

      if (value === true) {

        $page.variables.requestQ71PO_BuscarVouchers.resumir = true;

      } else {
        $page.variables.requestQ71PO_BuscarVouchers.resumir = false;

      }
    }
  }

  return actSwtResumir;
});

