define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actVerDetalleClic extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if ($page.variables.selectedRowTblVouchers.nroDocumento !== undefined) {
        const guardarLog2 = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            funcionalidad: 'CONSULTAR_FACTURAS',
            accion: 'VER_FACTURA',
            pagina: $flow.currentPage,
            proveedor: $application.variables.user.esProveedor,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            numeroAn8: $application.variables.user.numeroAn8,
            roles: $application.variables.userRoles.userRolesSt,
            transaccion: [[$page.variables.selectedRowTblVouchers.tipoDocumento]] + '-' + [[$page.variables.selectedRowTblVouchers.nroDocumento.toString().padStart(8,'0')]] + '-' + [[$page.variables.selectedRowTblVouchers.ciaDocumento]] + '-' + [[$page.variables.selectedRowTblVouchers.itemPago]],
          },
        });

        if ($page.variables.selectedRowTblVouchers.creadoDesde.trim() !== 'M') {
          const toShellConsultarComprobante = await Actions.navigateToPage(context, {
            page: '/shell/main/ap-cru-comprobantes-directo',
            params: {
              paramTipoObjetoChat: $page.variables.permisoConsultarFacturas.tipoObjetoChat,
              paramTitulo: 'Ver Comprobante',
              paramVersionJDE: $page.variables.paramVersionJDE,
              paramFuncionalidadMenu: 'INGRESAR_FACTURA_DIRECTA',
              paramModoCRU: 'R',
              paramMatching: $page.variables.selectedRowTblVouchers.creadoDesde,
              paramCiaDocumento: $page.variables.selectedRowTblVouchers.ciaDocumento,
              paramTipoDocumento: $page.variables.selectedRowTblVouchers.tipoDocumento,
              paramNroDocumento: $page.variables.selectedRowTblVouchers.nroDocumento,
              paramNroProveedor: $application.variables.user.esProveedor ? $application.variables.user.numeroAn8 : $page.variables.selectedRowTblVouchers.nroProveedor,
              paramUsoPermitido: true,
            },
          });

          const editarDescripcionUDC = await $application.functions.editarDescripcionUDC();

        }
        else {

          const toShell = await Actions.navigateToPage(context, {
            page: '/shell/main/ap-cru-comprobantes-matching',
            params: {
              paramTipoObjetoChat: $page.variables.permisoConsultarFacturas.tipoObjetoChat,
              paramTitulo: 'Ver Comprobante',
              paramVersionJDE: $page.variables.paramVersionJDEmatching,
              paramFuncionalidadMenu: ($page.variables.selectedRowTblVouchers.tipoDocumento === 'FL') ? 'INGRESAR_FACTURA_MATCH_FL' : 'INGRESAR_FACTURA_MATCH_OC',
              paramModoCRU: 'R',
              paramMatching: $page.variables.selectedRowTblVouchers.creadoDesde.trim(),
              paramCiaDocumento: $page.variables.selectedRowTblVouchers.ciaDocumento,
              paramTipoDocumento: $page.variables.selectedRowTblVouchers.tipoDocumento,
              paramNroDocumento: $page.variables.selectedRowTblVouchers.nroDocumento,
              paramNroProveedor: $application.variables.user.esProveedor ? $application.variables.user.numeroAn8 : $page.variables.selectedRowTblVouchers.nroProveedor,
              paramUsoPermitido: true,
            },
          });
        }

      }
      else {
        const notificarError = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            codigo: 'seleccionar-registro',
            modoVisualizacion: '',
          },
        });
      }


    }
  }

  return actVerDetalleClic;
});
