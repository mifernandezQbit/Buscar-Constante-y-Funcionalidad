define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actSelectedRowTblVouchers extends ActionChain {

    /**
     * TableSelectedChangeChain
     * @param {Object} context
     * @param {Object} params
     * @param {any[]} params.keys 
     * @param {any} params.selected 
     */
    async run(context, { keys, selected }) {
      const { $page, $flow, $application } = context;

      // ---- resetear Voucher seleccionado
      $page.variables.selectedRowTblVouchers = null;

      // verificar que no existan dos o más vouchers seleccionados

      if (keys[1] !== undefined) {

        const claveMensaje = [['04-solo-un-registro-seleccionado-accion-']] + [[$page.variables.language]];

        const notificarError = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            descripcion: $page.variables.diccionarioMensajes[claveMensaje],
            titulo: 'Atención!',
            modoVisualizacion: 'transient',
            tipoNotificacion: 'warning',
          },
        });
      } else {
        if (keys[0] !== undefined) {
          // setear voucher seleccionado
          $page.variables.selectedRowTblVouchers = $page.variables.rowsetVouchers[keys[0]];

        }
      }
      $page.variables.selectedRowTblVouchers = selected;
    }
  }

  return actSelectedRowTblVouchers;
});
