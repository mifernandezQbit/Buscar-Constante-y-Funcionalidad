define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actSelectValueItemSelTipoComprobanteLegal extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application } = context;

      // set tipoDocumento con el code del combo de Tipos de Comprobantes Legales
      $page.variables.requestQ71PO_BuscarVouchers.filtroTipoDocumentoLegal = data.code; //key;
    }
  }

  return actSelectValueItemSelTipoComprobanteLegal;
});
