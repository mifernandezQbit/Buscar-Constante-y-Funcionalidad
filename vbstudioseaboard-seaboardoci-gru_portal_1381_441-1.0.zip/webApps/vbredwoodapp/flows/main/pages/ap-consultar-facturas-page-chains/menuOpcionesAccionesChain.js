define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class menuOpcionesAccionesChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.menuId 
     */
    async run(context, { menuId }) {
      const { $page, $flow, $application } = context;

      //verificar si hay un voucher seleccionado y que contenga nroFactura
      if ($page.variables.selectedRowTblVouchers.nroFactura !== undefined) {
        switch (menuId) {
          case 'VER_PAGOS':

            //verificar que el voucher seleccionado tenga estado de pago en P
            if ($page.variables.selectedRowTblVouchers.estadoPago === 'P') {

              const guardarLog = await Actions.callChain(context, {
                chain: 'application:guardar_log',
                params: {
                  funcionalidad: 'CONSULTAR_FACTURAS',
                  accion: 'VER_PAGOS',
                  pagina: $flow.currentPage,
                  proveedor: $application.variables.user.esProveedor,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  numeroAn8: $application.variables.user.numeroAn8,
                  transaccion: [[$page.variables.selectedRowTblVouchers.tipoDocumento]] + '-' + [[$page.variables.selectedRowTblVouchers.nroDocumento.toString().padStart(8,'0')]] + '-' + [[$page.variables.selectedRowTblVouchers.ciaDocumento]] + '-' + [[$page.variables.selectedRowTblVouchers.itemPago]],
                  roles: $application.variables.userRoles.userRolesSt,
                },
              });

              const response = await Actions.callRest(context, {
                endpoint: 'businessObjects/getall_TipoChat',
                uriParams: {
                  q: "suscriptorID = "  + $application.variables.suscriptor.id + " and tipoObjetoChat = 'PG'",
                },
              });

              const toApConsultarPagos = await Actions.navigateToPage(context, {
                page: 'ap-consultar-pagos',
                params: {
                  parDocumentCompany: $page.variables.selectedRowTblVouchers.ciaDocumento,
                  parDocumentNumber: $page.variables.selectedRowTblVouchers.nroDocumento,
                  parDocumentSfx: $page.variables.selectedRowTblVouchers.itemPago,
                  parDocumentType: $page.variables.selectedRowTblVouchers.tipoDocumento,
                  parEstadoPago: $page.variables.selectedRowTblVouchers.estadoPago,
                  parSupplierNbr: $page.variables.selectedRowTblVouchers.nroProveedor,
                  parVersionJDE: $page.variables.paramVersionJDE,
                  parInvoiceNumber: $page.variables.selectedRowTblVouchers.nroFactura,
                  parTitulo: 'Pagos del comprobante',
                  parTipoObjetoChat: response.body.items[0].id,
                },
              });

            } else {
              const notificarError = await Actions.callChain(context, {
                chain: 'application:notificar_error',
                params: {
                  codigo: 'seleccionar-factura',
                  modoVisualizacion: '',
                },
              });
            }
            break;
    
          case 'VER_MENSAJES':
            $application.variables.modoMensajes = 'C';
            const callFunction = await this.generarRandom(context);
            $page.variables.mostrarDrawerMensajes = callFunction;

            const guardarLog3 = await Actions.callChain(context, {
              chain: 'application:guardar_log',
              params: {
                funcionalidad: 'CONSULTAR_FACTURAS',
                accion: 'VER_MENSAJES',
                pagina: $flow.currentPage,
                proveedor: $application.variables.user.esProveedor,
                suscriptorId: $application.variables.suscriptor.id,
                usuario: $application.variables.user.ociUser,
                numeroAn8: $application.variables.user.numeroAn8,
                transaccion: [[$page.variables.selectedRowTblVouchers.tipoDocumento]] + '-' + [[$page.variables.selectedRowTblVouchers.nroDocumento.toString().padStart(8,'0')]] + '-' + [[$page.variables.selectedRowTblVouchers.ciaDocumento]] + '-' + [[$page.variables.selectedRowTblVouchers.itemPago]],
                roles: $application.variables.userRoles.userRolesSt,
              },
            });

            break;
        }
      } else {
        const claveMensaje = [['04-solo-un-registro-seleccionado-accion-']] + [[$page.variables.language]];
        const notificarError2 = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            titulo: 'Atención!',
            descripcion: $page.variables.diccionarioMensajes[claveMensaje],
            modoVisualizacion: 'transient',
            tipoNotificacion: 'warning',
          },
        });
      }

    }

    /**
    * @param {Object} context
    */
    async generarRandom(context) {
      const { $page, $flow, $application } = context;
      let random = Math.random(1, 10);
      return random;
    }


  }

  return menuOpcionesAccionesChain;
});
