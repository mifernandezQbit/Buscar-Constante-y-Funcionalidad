define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class artSearchButton extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.buscarPagosArray',
  ],
      });
      var transformFechaDesde = "";
      if ($page.variables.fechaDesde === undefined  || $page.variables.fechaDesde === "" || $page.variables.fechaDesde === null ){
          transformFechaDesde = "";
      }else{
          transformFechaDesde = await this.transformDate(context, { fecha: $page.variables.fechaDesde });
      }
      
     if ($application.variables.user.esProveedor === true) {

        // Buscar pagos con el numeroAn8 del usuario si es proveedor

        $page.variables.parSupplierNbr = $application.variables.user.numeroAn8;
      } else
      {
      $page.variables.parSupplierNbr = $page.variables.nroProveedor;
      }



      if ($variables.parSupplierNbr !== undefined && $variables.parSupplierNbr !== 0) {

      $page.variables.buscarPagosRequest = {
 "token": $application.variables.token,
 "modo": "",
 "nroProveedor":$page.variables.parSupplierNbr,
 "nroDocumento": "",
 "tipoDocumento": "",
 "ciaDocumento": "",
 "sfxDocumento": "",
 "P0411_Version": $page.variables.P0411MVersion,
 "nroPago": $page.variables.nroPago,
 "fechaPagoDesde": transformFechaDesde,
 "instrumentoPago": $page.variables.selectedInstPago.code,
 "P0413M_Version": $page.variables.parVersionJDE,
 "resumir": "1"
};   
      $application.variables.buscando = true;

// agrego guardado en tabla log para registrar la acción elegida
  const guardarLog2 = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
              funcionalidad: 'CONSULTAR_PAGOS',
              accion: 'BUSCAR',
              pagina: $flow.currentPage,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
              transaccion: $page.variables.parSupplierNbr + (transformFechaDesde!== undefined && transformFechaDesde!=="" ? "-" + transformFechaDesde:"") + ($page.variables.nroPago !==undefined && $page.variables.nroPago!=="" ? "-" + $page.variables.nroPago : "") + ($page.variables.selectedInstPago.code!==undefined && $page.variables.selectedInstPago.code!== "" ? "-" + $page.variables.selectedInstPago.code:""),
            },
        });

        // busca pagos
      const responseBuscarPagos = await Actions.callRest(context, {
        endpoint: 'GatewayPortal/postQ71PO_BuscarPagos',
        body: $page.variables.buscarPagosRequest,
      });

      // ---- TODO: Add your code here ---- //

        await Actions.callChain(context, {
          chain: 'application:verificar_respuesta_jdeError',
          params: {
            error: !responseBuscarPagos.ok,
            funcion: 'BuscarPagos',
            funcionalidad: 'CONSULTAR_PAGOS',
            tokenExpirado: responseBuscarPagos.body.tokenExpirado !==undefined ? responseBuscarPagos.body.tokenExpirado:false ,
          },
        });
      
      // Si la consulta a Buscar Pagos devuelve datos se muestra la tabla
     $application.variables.buscando = false;

      const callFunction = await this.mostrarTabla(context, { panelTablaId: 'buscarPagos', responseArray: responseBuscarPagos.body.rowset });

      //const transformFechaArray = await responseBuscarPagos.body.rowset;

const transformFechaArray = (responseBuscarPagos.body.rowset || []).map(r => ({  
...r,
 _importePago:r.importePago * -1}));

      $page.variables.buscarPagosArray = transformFechaArray;
    /** MIF quitamos el guardado si hubo error de servidor porque de eso se encarga el verificar respuesta jde error.
          if (!responseBuscarPagos.ok) {
      
        const guardarLog = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
              funcionalidad: 'CONSULTAR_PAGOS',
              accion: 'FALLA_FUNCION',
              pagina: $flow.currentPage,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
            },
        });
      } else {
        /**
        const guardarLog2 = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
              funcionalidad: 'CONSULTAR_PAGOS',
              accion: 'SUCCESS_FUNCION',
              pagina: $flow.currentPage,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
            },
        }); 
      }*/
 
    }
    else {
        const notificarError = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            codigo: 'nro-proveedor-obligatorio',
            modoVisualizacion: '',
          },
        });
        }
    }

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.panelTablaId 
     * @param {any} params.responseArray 
     */
    async mostrarTabla(context, { panelTablaId, responseArray }) {
      const { $page, $flow, $application } = context;
      let elemento = document.getElementById(panelTablaId);
      let responseLong = responseArray.length;
           if(responseLong > 0){
           elemento.hidden = false;
           }
    
    }

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object[]} params.array 
     * @return {object[]} 
     */
    /** 
    async transformFechaArray(context, { array }) {
      const { $page, $flow, $application } = context;
       let long = array.length;
       for (let index = 0; index < long; index++) {
      let item = array[index];
      let partesFechaPago = item.fechaPago.split('-'); 
      array[index].fechaPago = `${partesFechaPago[2]}-${partesFechaPago[1]}-${partesFechaPago[0]}`;
      if(item.fechaAnulacion !== null){
      let partesFechaAnul = item.fechaAnulacion.split('-');
      array[index].fechaAnulacion = item.fechaAnulacion//`${partesFechaAnul[2]}-${partesFechaAnul[1]}-${partesFechaAnul[0]}`;
      }
    }
    return array;
      
    }*/

    /**
     * @param {Object} context
     */
   async transformDate(context, { fecha }) {
      const { $page, $flow, $application } = context;
      const partes = fecha.split('-'); 
      const nuevaFechaDesde = `${partes[2]}/${partes[1]}/${partes[0]}`;
      

      return nuevaFechaDesde;
    
    }
  }

  return artSearchButton;
});
