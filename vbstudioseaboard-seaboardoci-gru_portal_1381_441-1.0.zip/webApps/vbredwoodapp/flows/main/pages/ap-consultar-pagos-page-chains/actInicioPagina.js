define([
    'vb/action/actionChain',
    'vb/action/actions',
    'vb/action/actionUtils',
], (
    ActionChain,
    Actions,
    ActionUtils
) => {
    'use strict';

    class actInicioPagina extends ActionChain {

        /**
         * @param {Object} context
         */
        async run(context) {
            const {
                $page,
                $flow,
                $application,
                $functions
            } = context;

            $application.variables.buscando = true;

            const buscarConstanteUDC_D02 = await Actions.callChain(context, {
                chain: 'application:buscar_constante',
                params: {
                    constante: 'UDC_D02',
                },
            });

            const responseBuscarValoresUDC = await Actions.callRest(context, {
                endpoint: 'GatewayPortal/postQ71PO_BuscarValoresUDC',
                body: {
                    token: $application.variables.token,
                    'P0004A_Version': '',
                    udcToSearch: [{
                        productCode: '00',
                        userDefinedCode: 'PY',
                        description1: '',
                        description2: '*' + buscarConstanteUDC_D02.valor + '*',
                        specialHandling: '',
                    }, ],
                },
            });


            await Actions.callChain(context, {
                chain: 'application:verificar_respuesta_jdeError',
                params: {
                    error: !responseBuscarValoresUDC.ok,
                    funcion: 'BuscarValoresUDC',
                    funcionalidad: 'CONSULTAR_PAGOS',
                    tokenExpirado: responseBuscarValoresUDC.body.tokenExpirado,
                       status:responseBuscarValoresUDC.status,
                },
            });

            $page.variables.instrumentoPago.data = responseBuscarValoresUDC.body.rowset !== undefined && responseBuscarValoresUDC.body.rowset.length > 0 ? responseBuscarValoresUDC.body.rowset[0].codesList : [];

            const verificarPermisosChatPago = await Actions.callChain(context, {
                chain: 'application:verificar_permisos_funcionalidad_obj',
                params: {
                    funcionalidad: 'CHAT_PAGO',
                },
            });

            if (verificarPermisosChatPago.existe) {
                $page.variables.permisoChatPago = true;
            };

            const verificarPermisosPagos = await Actions.callChain(context, {
                chain: 'application:verificar_permisos_funcionalidad_obj',
                params: {
                    funcionalidad: 'CONSULTAR_PAGOS',
                },
            });


            $page.variables.permisoFuncionalidad = verificarPermisosPagos.existe;

            if (!verificarPermisosPagos.existe) {
                // ---- Guardar Log de Acceso Restringido ---- //

                const guardarLog = await Actions.callChain(context, {
                    chain: 'application:guardar_log',
                    params: {
                        accion: 'INTENTO_INGRESO_NH',
                        funcionalidad: 'CONSULTAR_PAGOS',
                        numeroAn8: $application.variables.user.numeroAn8,
                        pagina: $flow.currentPage,
                        suscriptorId: $application.variables.suscriptor.id,
                        usuario: $application.variables.user.ociUser,
                        proveedor: $application.variables.user.esProveedor,
                        roles: $application.variables.userRoles.userRolesSt,
                    },
                });

                //AGREGAR ACCION PARA INTERRUMPIR LA NAVEGACION
                await Actions.navigateToPage(context, {
                    page: 'acceso-no-autorizado',
                });


            } else {
                // Guardad Log INGRESA
                const guardarLog2 = await Actions.callChain(context, {
                    chain: 'application:guardar_log',
                    params: {
                        accion: 'INGRESA',
                        funcionalidad: 'CONSULTAR_PAGOS',
                        pagina: $flow.currentPage,
                        proveedor: $application.variables.user.esProveedor,
                        suscriptorId: $application.variables.user.suscriptorID,
                        usuario: $application.variables.user.ociUser,
                        numeroAn8: $application.variables.user.numeroAn8,
                        roles: $application.variables.userRoles.userRolesSt,
                    },
                });

            }
            const resultP0411MVersion = await Actions.callChain(context, {
                chain: 'application:buscar_constante',
                params: {
                    constante: 'P0411_Version',
                },
            });
            $page.variables.P0411MVersion = resultP0411MVersion.valor

            // Buscar valor de constante FECHA_DESDE y guardar su valor

            const resultFechaDesde = await Actions.callChain(context, {
                chain: 'application:buscar_constante',
                params: {
                    constante: 'FECHA_DESDE',
                },
            });

            const transformFechaDesde2 = await $functions.transformFechaDesde(resultFechaDesde.valor);

            $page.variables.fechaDesde = transformFechaDesde2;

            if ($page.variables.parModoNavegacion === false) {

                // Si existe valor para la variable parDocumentSfx, agregarle un guión y un espacio delante para que quede bien en el input text Nro. de transacción.
                const callFunctionTransformSfx = await this.transformSfx(context, {
                    documentSfx: $page.variables.parDocumentSfx
                });
                $page.variables.docSfx = callFunctionTransformSfx;
                // Buscar datos con la función  Q71PO_BuscarPagos - tipo de búsqueda = ‘1’
                const responseBuscarPago = await Actions.callRest(context, {
                    endpoint: 'GatewayPortal/postQ71PO_BuscarPagos',
                    body: {
                        token: $application.variables.token,
                        modo: '1',
                        nroProveedor: $page.variables.parSupplierNbr,
                        nroDocumento: $page.variables.parDocumentNumber,
                        tipoDocumento: $page.variables.parDocumentType,
                        ciaDocumento: $page.variables.parDocumentCompany,
                        sfxDocumento: $page.variables.parDocumentSfx,
                        'P0411_Version': $page.variables.P0411MVersion,
                        nroPago: '',
                        fechaPagoDesde: '',
                        instrumentoPago: '',
                        'P0413M_Version': $page.variables.parVersionJDE,
                        resumir: '1',
                    },
                });

                await Actions.callChain(context, {
                    chain: 'application:verificar_respuesta_jdeError',
                    params: {
                        error: !responseBuscarPago.ok,
                        funcion: 'BuscarPagos',
                        funcionalidad: 'CONSULTAR_PAGOS',
                        tokenExpirado: responseBuscarPago.body.tokenExpirado,
                          status:responseBuscarPago.status,
                    },
                });

                //const transformFechaPago = await this.transformFechaPago(context, { array: responseBuscarPago.body.rowset });

                // $page.variables.buscarPagosArray = transformFechaPago;
                $page.variables.buscarPagosArray = (responseBuscarPago.body.rowset || []).map(r => ({
                    ...r,
                    _importePago: r.importePago * -1
                }));

                $application.variables.buscando = false;

                await this.mostrarTabla(context, {
                    tablaId: 'buscarPagos'
                });
            } else {

                if ($application.variables.user.esProveedor) {
                    await Actions.callChain(context, {
                        chain: 'artSearchButton',
                    });
                }
                $application.variables.buscando = false;

                const callFunction = await this.mostrarTabla(context, {
                    tablaId: 'buscarPagos'
                });
            }

        }



        /**
         * @param {Object} context
         * @param {Object} params
         * @param {string} params.documentSfx 
         */
        async transformSfx(context, {
            documentSfx
        }) {
            const {
                $page,
                $flow,
                $application
            } = context;

            let transformDocumentSfx = " - " + documentSfx;

            return transformDocumentSfx;

        }

        /**
         * @param {Object} context
         * @param {Object} params
         * @param {string} params.tablaId 
         */
        async mostrarTabla(context, {
            tablaId
        }) {
            const {
                $page,
                $flow,
                $application
            } = context;
            let elemento = document.getElementById(tablaId);
            elemento.hidden = false;


        }

        /**
         * @param {Object} context
         * @param {Object} params
         * @param {string} params.fechaDesde 
         */
        /** 
   async transformDate(context, { fecha }) {
      const { $page, $flow, $application } = context;
      var nuevaFechaDesde ="";
      if (fecha !== undefined && fecha !== null && fecha !== ""){ 
        const partes = fecha.split('-'); 
        nuevaFechaDesde = `${partes[2]}/${partes[1]}/${partes[0]}`;
      }

      return nuevaFechaDesde;
    
    }*/

        /**
         * @param {Object} context
         * @param {Object} params
         * @param {string} params.fechaPago 
         */
        async transformFechaPago(context, {
            array
        }) {
            const {
                $page,
                $flow,
                $application
            } = context;
            let transformed = [];
            let long = array.length;

            for (let index = 0; index < long; index++) {
                let item = array[index];
                let partes = item.fechaPago.split('-');
                array[index].fechaPago = item.fechaPago; //`${partes[2]}-${partes[1]}-${partes[0]}`;

            }

            return array;

        }
    }

    return actInicioPagina;
});