define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actSupplierNbrListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:string,value:string}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application } = context;

      $page.variables.buscarPagosRequest.nroProveedor = event.value;
    }
  }

  return actSupplierNbrListener;
});
