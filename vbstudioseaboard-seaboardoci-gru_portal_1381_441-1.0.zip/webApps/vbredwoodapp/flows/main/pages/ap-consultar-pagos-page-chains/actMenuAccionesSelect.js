define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actMenuAccionesSelect extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.menuId 
     */
    async run(context, { menuId }) {
      const { $page, $flow, $application, $event, $variables } = context;

      if ($page.variables.selectedRow.nroPago === undefined) {
        const notificarError = await Actions.callChain(context, {
            chain: 'application:notificar_error',
            params: {
              codigo: 'seleccionar-pago',
              modoVisualizacion: '',
            },
        });
      } else {
     

        if (menuId === 'Mensajes') {
          const guardarLog = await Actions.callChain(context, {
            chain: 'application:guardar_log',
             params: {
             accion: 'VER_MENSAJE',
          suscriptorId: $application.variables.suscriptor.id,
          numeroAn8: $application.variables.user.numeroAn8,
          proveedor: $application.variables.user.esProveedor,
          funcionalidad: "CONSULTAR_PAGOS",
          pagina: $application.currentPage.id,
          roles: $application.variables.userRoles.userRolesSt,
          usuario: $application.variables.user.ociUser,
          transaccion: ($application.variables.user.esProveedor ?$application.variables.user.numeroAn8.toString().padStart(8, '0') : $variables.nroProveedor.padStart(8, '0')) + "-" +  $page.variables.selectedRow.nroPago.toString().padStart(8, '0')+ "-" + $page.variables.selectedRow.tipoPago + "-" + $page.variables.selectedRow.InstrumentoPago,     },
          });

          // reseteo el condicional que despliega o no el drawer de mensajes
          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.mostrarDrawerMensajes',
  ],
          });

          // activa el despliegue del drawer de mensajes
          const generarRandomMensajes = await this.generarRandom(context);

          $page.variables.mostrarDrawerMensajes = generarRandomMensajes;
        }

        if (menuId === 'Descargar OP') {
          $page.variables.descargandoOP = true;
           const guardarLog2 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
                  funcionalidad: 'CONSULTAR_PAGOS',
                  accion: 'DESCARGAR_ORDEN_PAGO',
                  pagina: $flow.currentPage,
                  proveedor: $application.variables.user.esProveedor,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  numeroAn8: $application.variables.user.numeroAn8,
                  transaccion: ($application.variables.user.esProveedor ?$application.variables.user.numeroAn8.toString().padStart(8, '0') : $variables.nroProveedor.padStart(8, '0')) + "-" +  $page.variables.selectedRow.nroPago.toString().padStart(8, '0')+ "-" + $page.variables.selectedRow.tipoPago + "-" + $page.variables.selectedRow.InstrumentoPago,
                  roles: $application.variables.userRoles.userRolesSt,
                },
          });
          await Actions.callChain(context, {
            chain: 'application:descargar_archivo',
            params: {
              tpDocumento: $page.variables.selectedRow.tipoPago,
              nroBeneficiario: $application.variables.user.esProveedor ?$application.variables.user.numeroAn8.toString() : $variables.nroProveedor.toString(),
              nroProveedor: $application.variables.user.esProveedor ?$application.variables.user.numeroAn8.toString() : $variables.nroProveedor.toString(),
              instrumentoPago: $page.variables.selectedRow.InstrumentoPago,
              nroDocumento: $page.variables.selectedRow.nroPago.toString(),
              flagTipoOrden: 'P',
            },
          });
   $page.variables.descargandoOP = false;
         
        }
      }

    }

    /**
     * @param {Object} context
     */
    async generarRandom(context) {
      const { $page, $flow, $application } = context;
     let random = Math.random(1,10);
     return random;
    }

 

    

  
  }

  return actMenuAccionesSelect;
});
