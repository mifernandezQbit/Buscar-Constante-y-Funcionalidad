define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actVerDetalle extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if ($page.variables.selectedRow.nroPago === undefined) {
        const notificarError = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            codigo: 'seleccionar-pago',
            modoVisualizacion: '',
          },
        });
      } else {
        // ---- Se verifica permiso de funcionalidad ---- //
        const verificarPermisosDetallePago = await Actions.callChain(context, {
          chain: 'application:verificar_permisos_funcionalidad_obj',
          params: {
            funcionalidad: 'CONSULTAR_DETALLE_PAGO',
          },
        });
        if (verificarPermisosDetallePago.existe === true) {
          await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              accion: 'INGRESA',
              funcionalidad: 'CONSULTAR_DETALLE_PAGO',
              numeroAn8: $application.variables.user.numeroAn8,
              pagina: $flow.currentPage,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              proveedor: $application.variables.user.esProveedor,
              roles: $application.variables.userRoles.userRolesSt,
               transaccion: ($application.variables.user.esProveedor ?$application.variables.user.numeroAn8.toString().padStart(8, '0') : $variables.nroProveedor.padStart(8, '0')) + "-" +  $page.variables.selectedRow.nroPago.toString().padStart(8, '0')+ "-" + $page.variables.selectedRow.tipoPago + "-" + $page.variables.selectedRow.InstrumentoPago,
            },
          });
          await Actions.resetVariables(context, {
            variables: [
              '$page.variables.mostrarDrawerDetalle',
            ],
          });
          $page.variables.mostrarDrawerDetalle = true;
          const responseDetallePago = await Actions.callRest(context, {
            endpoint: 'GatewayPortal/postQ71PO_BuscarDetallePago',
            body: {
              token: $application.variables.token,
              nroProveedor: $application.variables.user.esProveedor ? $application.variables.user.numeroAn8 : $variables.parSupplierNbr,
              nroPago: $page.variables.selectedRow.nroPago,
              cuentaPago: $page.variables.selectedRow.nroCuenta,
              instrumentoPago: $page.variables.selectedRow.instrumentoPago,
              tipoPago: $page.variables.selectedRow.tipoPago,
              'udc_dl02': '',
              'udc_sy': '00',
              'udc_rt': 'DV',
            },
          });

          await Actions.callChain(context, {
            chain: 'application:verificar_respuesta_jdeError',
            params: {
              error: !responseDetallePago.ok,
              funcion: 'BuscarDetallePago',
              funcionalidad: 'CONSULTAR_DETALLE_PAGO',
              tokenExpirado: responseDetallePago.body.tokenExpirado !== undefined ? responseDetallePago.body.tokenExpirado : false,
                status:responseDetallePago.status,
            },
          });

          for (let index = 0; index < responseDetallePago.body.rowset.length; index++) {
            const fechaVtoAux = responseDetallePago.body.rowset[index].fechaVto;
            responseDetallePago.body.rowset[index].fechaVto = $application.functions.formatDateString(fechaVtoAux, $application.variables.preferenciasUsuarioJde.simpleDateFormat);

          }

          const transformDateInArray = await responseDetallePago.body.rowset //await $page.functions.transformDateInArray(responseDetallePago.body.rowset);
          //20251219 Busca el primer nroDocumento donde tipoDocJde sea "$Q" y luego recorre array y le asigna el nroDocumento de primer ocurrencia si es $Q y si no el del mismo item
          //$page.variables.detallePagoArray = transformDateInArray;

          let primerNroDocumentoQ = null;
          let primerSfxQ=null;
          for (let i = 0; i < transformDateInArray.length; i++) {
            if (transformDateInArray[i].tipoDocJde === "$Q") {
              primerNroDocumentoQ = transformDateInArray[i].nroDocumento;
              primerSfxQ=transformDateInArray[i].sfxPago;
              break;
            }
          }
          $page.variables.detallePagoArray = transformDateInArray.map(function (item) {
            return {
              ...item,
              nroDocumentoDownload: item.tipoDocJde === "$Q" ? primerNroDocumentoQ : item.nroDocumento,
              sfxDownload: item.tipoDocJde === "$Q" ? primerSfxQ : item.sfxPago
            };
          });

        } else {
          await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              accion: 'INTENTO_INGRESO_NH',
              funcionalidad: 'CONSULTAR_PAGOS',
              numeroAn8: $application.variables.user.numeroAn8,
              pagina: $flow.currentPage,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              proveedor: $application.variables.user.esProveedor,
              roles: $application.variables.userRoles.userRolesSt,
             transaccion: ($application.variables.user.esProveedor ?$application.variables.user.numeroAn8.toString().padStart(8, '0') : $variables.nroProveedor.padStart(8, '0')) + "-" +  $page.variables.selectedRow.nroPago.toString().padStart(8, '0')+ "-" + $page.variables.selectedRow.tipoPago + "-" + $page.variables.selectedRow.InstrumentoPago,
               },
          });
        }

      }
    }
  }

  return actVerDetalle;

});
