define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actDescargarRetencionClick extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application } = context;
$page.variables.descargandoRet = true;
     // guardar en tabla log la intención de descarga
        const guardarLog2 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
                  funcionalidad: 'CONSULTAR_DETALLE_PAGO',
                  accion: 'DESCARGAR_RETENCION',
                  pagina: $flow.currentPage,
                  proveedor: $application.variables.user.esProveedor,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  numeroAn8: $application.variables.user.numeroAn8,
                  observaciones: current.data.nroProveedor.toString().padStart(8, '0') + "-" +  $page.variables.selectedRow.nroPago.toString().padStart(8,'0')+ "-" + $page.variables.selectedRow.tipoPago + "-" + $page.variables.selectedRow.InstrumentoPago,
                  transaccion: current.data.nroProveedor.toString().padStart(8, '0') + "-" + current.data.tipoDocJde+"-"+current.data.nroDocumentoDownload.toString().padStart(8, '0') +"-"+current.data.compania.padStart(5, '0')  +"-"+current.data.sfxDownload.padStart(3, '0'), 
                  roles: $application.variables.userRoles.userRolesSt,
                },
          });
// descargar archivo
      await Actions.callChain(context, {
        chain: 'application:descargar_archivo',
        params: {
          ciaDocumento: current.data.compania,
          flagTipoOrden: 'R',
          nroDocumento: current.data.nroDocumentoDownload.toString(), 
          nroProveedor: current.data.nroProveedor.toString(),
          tpDocumento: current.data.tipoDocJde,
          ordenSufijo:  current.data.sfxDownload,
        },
      });
$page.variables.descargandoRet = false;

    }
  }

  return actDescargarRetencionClick;
});
