define([], () => {
  'use strict';

  class PageModule {

    // Método para convertir la fecha de "YYYY-MM-DD" a "DD/MM/YYYY"
    formatDateDDMMYYYY(dateString) {
      if (dateString) {
        let dateArray = dateString.split("-");
        if (dateArray.length === 3) {
          // Formatear a "DD/MM/YYYY"
          return dateArray[2] + '/' + dateArray[1] + '/' + dateArray[0];
        }
      }
      return dateString; // Retorna el valor original si no hay conversión
    }

    // Método para convertir la fecha por ejemplo de "YYYY-MM-DD" a "DD/MM/YYYY"
    formatDateString(dateString, simpleDateFormat) {
      if (!dateString || !simpleDateFormat) return dateString; // Validación inicial

      // Detectar el delimitador y dividir la fecha
      const delimiter = dateString.includes('-') ? '-' : '/';
      const dateArray = dateString.split(delimiter);

      // Asegurarse de que la fecha tenga tres partes
      if (dateArray.length !== 3) return dateString;

      // Identificar año, mes y día de forma genérica
      const [year, month, day] = delimiter === '-' ? dateArray : dateArray.reverse();

      // Manejar diferentes formatos
      switch (simpleDateFormat) {
        case 'dd/MM/yy':
          return `${day}/${month}/${year.slice(-2)}`;
        case 'dd/MM/yyyy':
          return `${day}/${month}/${year}`;
        case 'MM-dd-yyyy':
          return `${month}-${day}-${year}`;
        case 'yyyy/MM/dd':
          return `${year}/${month}/${day}`;
        case 'yyyy-MM-dd':
          return `${year}-${month}-${day}`;
        default:
          return dateString; // Retorna el valor original si el formato no está soportado
      }
    }

  }
  
  return PageModule;
});
