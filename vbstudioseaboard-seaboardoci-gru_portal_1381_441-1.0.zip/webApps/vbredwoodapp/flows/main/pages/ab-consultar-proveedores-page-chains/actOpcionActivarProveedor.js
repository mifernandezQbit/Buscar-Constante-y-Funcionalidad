define([
        'vb/action/actionChain',
        'vb/action/actions',
        'vb/action/actionUtils',
    ], (
        ActionChain,
        Actions,
        ActionUtils) => {
    'use strict';

    class actOpcionActivarProveedor extends ActionChain {

        /**
         * @param {Object} context
         */
        async run(context) {
            const {
                $page,
                $flow,
                $application,
                $constants,
                $variables
            } = context;

            $variables.buscando = true;

            const proveedorOK = await Actions.callChain(context, {
                chain: 'application:verificar_proveedor',
                params: {
                    paramAccion: 'activar',
                    paramNroProveedor: $page.variables.rowSelected.proveedor,
                    paramTipoBusqueda: $page.variables.rowSelected.tipoBusqueda,
                },
            });

            if ($page.variables.varRetenerOrden === "") {

                const notificarError = await Actions.callChain(context, {
                    chain: 'application:notificar_error',
                    params: {
                        codigo: 'falta-configuracion',
                        descripcion: "Constante RETENER_ORDEN no definida",
                    },
                });
            }

            if (proveedorOK.proveedorOK === true && $page.variables.varRetenerOrden !== "") {

                let buscarDatosProveedor = await Actions.callRest(context, {
                    endpoint: 'GatewayPortal2/postQ71PO_BuscarDatosProveedor',
                    body: {
                        token: $application.variables.token,
                        tipoProceso: '1',
                        nroProveedor: $page.variables.rowSelected.proveedor,
                        'P01012_Version': $page.variables.p01012_Version,
                        esTransportista: '',
                        'P4906_Version': '',
                        'PQ71102A_Version': '',
                        'PQ711012_Version': '',
                        'P0101Z1_Version': '',
                        'P0401Z1_Version': '',
                        'P0111Z1_Version': '',
                        procesado: '',
                        company: '',
                    },
                });
                await Actions.callChain(context, {
                    chain: 'application:verificar_respuesta_jdeError',
                    params: {
                        error: !buscarDatosProveedor.ok,
                        funcion: 'BuscarDatosProveedor',
                        funcionalidad: $variables.funcionalidad,
                        tokenExpirado: buscarDatosProveedor.body.tokenExpirado,
                        status: buscarDatosProveedor.status,
                    },
                });

                if (buscarDatosProveedor.ok && !buscarDatosProveedor.body.errorJDE) {
                    $variables.proveedorRollback.estadoRetenido = buscarDatosProveedor.body.data.retenerPago;
                    $variables.proveedorRollback.idFiscal = buscarDatosProveedor.body.data.idFiscal;
                    $variables.proveedorRollback.tipoPersona = buscarDatosProveedor.body.data.personaOCia;
                    $variables.proveedorRollback.pais = buscarDatosProveedor.body.data.pais;
                    $variables.proveedorRollback.tipoDocumentoLegal = buscarDatosProveedor.body.data.tipoDocumentoLegal;
                    $variables.proveedorRollback.unidadNegocio = buscarDatosProveedor.body.data.unidadNegocio;
                    $variables.proveedorRollback.tipoBusqueda = $page.variables.rowSelected.tipoBusqueda;
                    $variables.unidadNegocio = buscarDatosProveedor.body.data.unidadNegocio;
                    $variables.actualizarFilaContacto = "";
                    $variables.actualizarFilaMAIL = "";
                    $variables.mjsEmail = "";
                    // busco mail a usar
                 
                    Object.entries(buscarDatosProveedor.body.data.contactos).map(([key, value]) => {

                        Object.entries(value.emails).map(([keyEmails, valueEmails]) => {
                            if (valueEmails.categoriaEmail === $variables.consTipoMailPpal) {
                                $variables.actualizarFilaContacto = value.nroLinea;
                                $variables.actualizarFilaMAIL = valueEmails.nroLinea;
                                $variables.mjsEmail = valueEmails.email;
                            }
                        });
                    });

                    const ARCA_CONSTANCIA_INSCRIPCION = await Actions.callChain(context, {
                        chain: 'application:buscar_constante',
                        params: {
                            constante: 'ARCA_CONSTANCIA_INSCRIPCION',
                        },
                    });

                    if ( ARCA_CONSTANCIA_INSCRIPCION.existe === true && ARCA_CONSTANCIA_INSCRIPCION.valor === "1") {
                        const tipoDocumentoVerificables = $variables.tipoDocumentoArray.filter(item => item.specialHandling === "1");
                        const tipoDocumentoEncontrado = tipoDocumentoVerificables.find(item => item.code === $variables.proveedorRollback.tipoDocumentoLegal);
                        const paisVerificable = $variables.paisesArray.filter(item => item.specialHandling === "032");
                        const paisVerificado = paisVerificable.find(item => item.code === $variables.proveedorRollback.pais);

                        if (tipoDocumentoEncontrado && paisVerificado) {

                            const proveedorAprobadoArca = await Actions.callChain(context, {
                                chain: 'actVerificarArca',
                            });

                            if (proveedorAprobadoArca === true) {

                                const popUpActivarOpen = await Actions.callComponentMethod(context, {
                                    selector: '#popUpActivar',
                                    method: 'open',
                                });

                            }
                        } else 
                        {
                            const popUpActivarOpen2 = await Actions.callComponentMethod(context, {
                            selector: '#popUpActivar',
                            method: 'open',
                        });
                        }

                    } else {

                        const popUpActivarOpen2 = await Actions.callComponentMethod(context, {
                            selector: '#popUpActivar',
                            method: 'open',
                        });

                    }

                } else {
                    // Notificar error al recuperar datos proveedor
  
                      const notificarError2 = await Actions.callChain(context, {
            chain: 'application:notificar_error',
            params: {
              codigo: 'error-jde-recupero-datos',
            },
          });
                }
            }

            $variables.buscando = false;

        }
    }

    return actOpcionActivarProveedor;
});