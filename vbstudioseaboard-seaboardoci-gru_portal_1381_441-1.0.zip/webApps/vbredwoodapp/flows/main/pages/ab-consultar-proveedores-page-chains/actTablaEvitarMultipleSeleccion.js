define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actTablaEvitarMultipleSeleccion extends ActionChain {

    /**
     * Devuelve error si el usuario selecciona mas de una opcion a la vez
     * @param {Object} context
     * @param {Object} params
     * @param {any[]} params.keys 
     * @param {any} params.selected 
     */
    async run(context, { keys, selected }) {
      const { $page, $flow, $application } = context;

      if (keys[1] !== undefined) {

        const notificarError = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            codigo: 'seleccion-registro-unico',
            modoVisualizacion: '',
          },
        });
      }

      if (keys.length === 0) {
        $page.variables.seleccionoProveedor = false;
      } else {
        $page.variables.seleccionoProveedor = true;
      }

    }
  }

  return actTablaEvitarMultipleSeleccion;
});
