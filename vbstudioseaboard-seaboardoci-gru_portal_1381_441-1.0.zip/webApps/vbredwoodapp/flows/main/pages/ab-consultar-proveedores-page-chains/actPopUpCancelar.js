define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actPopUpCancelar extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.origen 
     */
    async run(context, { origen }) {
      const { $page, $flow, $application } = context;

await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              accion: 'CANCELA',
              suscriptorId: $application.variables.suscriptor.id,
              numeroAn8: $application.variables.user.numeroAn8,
              proveedor: $application.variables.user.esProveedor,
              funcionalidad: $page.variables.funcionalidadSeleccionada,
              pagina: $application.currentPage.id,
              roles: $application.variables.userRoles.userRolesSt,
              usuario: $application.variables.user.ociUser,
              transaccion:  $page.variables.rowSelected.proveedor,
            },
          });

      switch (origen) {
        case 'convertir-permanente':
          const popUpConvertirPermanenteClose = await Actions.callComponentMethod(context, {
            selector: '#popUpConvertirPermanente',
            method: 'close',
          });
          break;
          case 'desactivar':
          const popUpDesactivarClose = await Actions.callComponentMethod(context, {
            selector: '#popUpDesactivar',
            method: 'close',
          });
          break;
          case 'activar':
          const popUpActivarClose = await Actions.callComponentMethod(context, {
            selector: '#popUpActivar',
            method: 'close',
          });
          break;
        case 'cteProv':
          const popUpCteProvClose = await Actions.callComponentMethod(context, {
            selector: '#popUpCteProv',
            method: 'close',
          });
          break;
        default:
          break;
      }

      const popUpClose = await Actions.callComponentMethod(context, {
        selector: '#popUp',
        method: 'close',
      });
    }
  }

  return actPopUpCancelar;
});
