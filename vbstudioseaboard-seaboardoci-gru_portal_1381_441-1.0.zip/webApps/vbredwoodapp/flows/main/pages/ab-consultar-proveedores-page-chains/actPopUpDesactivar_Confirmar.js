define([
        'vb/action/actionChain',
        'vb/action/actions',
        'vb/action/actionUtils',
    ], (
        ActionChain,
        Actions,
        ActionUtils) => {
    'use strict';

    class actPopUpDesactivar_Confirmar extends ActionChain {

        /**
         * @param {Object} context
         */
        async run(context) {
            const { $page, $flow, $application, $variables } = context;

            $variables.buscando = true;
            $variables.actualizarFilaContacto = "";
            $variables.actualizarFilaMAIL = "";
			
			//MIF verificar seguridad

      const seguridadOK = await Actions.callChain(context, {
        chain: 'application:validar_seguridad',
        params: {
          accionJDE: 'C',
          funcionalidad: 'MODIFICAR_PROVEEDOR',
          nroProveedor: $variables.rowSelected.proveedor,
          valor: $variables.rowSelected.unidadNegocio,
        },
      });
			
			if (seguridadOK) {

            const TIPO_BUSQUEDA_PROV_RECH = await Actions.callChain(context, {
                chain: 'application:buscar_constante',
                params: {
                    constante: 'TIPO_BUSQUEDA_PROV_RECH',
                },
            });

            const guardarLog = await Actions.callChain(context, {
                chain: 'application:guardar_log',
                params: {
                    accion: 'CONFIRMA',
                    funcionalidad: $page.variables.funcionalidadSeleccionada,
                    numeroAn8: $application.variables.user.numeroAn8,
                    pagina: $flow.currentPage,
                    proveedor: $application.variables.user.esProveedor,
                    roles: $application.variables.userRoles.userRolesSt,
                    suscriptorId: $application.variables.suscriptor.id,
                    transaccion: $variables.rowSelected.proveedor.toString().padStart(8, '0'),
                    usuario: $application.variables.user.ociUser,
                },
            });

            const actualizarEstado = await Actions.callRest(context, {
                endpoint: 'GatewayPortal/postQ71PO_ActualizarEstadoProveedor',
                body: {
                    token: $application.variables.token,
                    nroProveedor: $page.variables.rowSelected.proveedor,
                    tipoBusqueda: TIPO_BUSQUEDA_PROV_RECH.valor,
                    'P01012_Version': $page.variables.p01012_Version,
                    retenerPago: 'Y',
                    'P04012_Version': $page.variables.p04012_Version,
                    retenerOrden: $page.variables.varRetenerOrden
                },
            });
            await Actions.callChain(context, {
                chain: 'application:verificar_respuesta_jdeError',
                params: {
                    error: !actualizarEstado.ok,
                    funcion: 'ActualizarEstadoProveedor',
                    funcionalidad: $variables.funcionalidad,
                    tokenExpirado: actualizarEstado.body.tokenExpirado,
                    status: actualizarEstado.status,
                },
            });

            const ADJUNTOS_VISIBLES_PORTAL_CC = await Actions.callChain(context, {
                chain: 'application:buscar_constante',
                params: {
                    constante: 'ADJUNTOS_VISIBLES_PORTAL_CC',
                },
            });

            const ADJUNTOS_VISIBLES_PORTAL_COD = await Actions.callChain(context, {
                chain: 'application:buscar_constante',
                params: {
                    constante: 'ADJUNTOS_VISIBLES_PORTAL_COD',
                },
            });

            $page.variables.inParamListaArchivos.incluirMetadatos = true;

            $page.variables.inParamListaArchivos.metadatos.codigosCategoria[ADJUNTOS_VISIBLES_PORTAL_CC.valor] = ADJUNTOS_VISIBLES_PORTAL_COD.valor;

            $page.variables.inParamListaArchivos.metadatos.mokey = $page.variables.rowSelected.proveedor;

            $page.variables.inParamListaArchivos.numeroProveedor = $page.variables.rowSelected.proveedor;

            $page.variables.inParamListaArchivos.tipoObjeto = 'ABGT';

            $page.variables.inParamListaArchivos.token = $application.variables.token;

            if ($page.variables.mjsDesactivar !== undefined && $page.variables.mjsDesactivar !== "") {
                await Actions.callChain(context, {
                    chain: 'application:convertir_y_subir_pdf',
                    params: {
                        inParamAdjuntoPDF: true,
                        mensaje: $page.variables.mjsDesactivar,
                        nombrePDF: 'motivoDesactivarProveedor.pdf',
                        attributosJDE: $page.variables.inParamListaArchivos,
                    },
                });

            }

            /** MIF P002 Desactivamos todos los usuarios del proveedor  */
            let payload = {
                "usuarios": [],
                "suscriptorID": $application.variables.suscriptor.id,
                "ociUserPrincipal": "",
                "nombrePrincipal": "",
                "mailPrincipal": "",
                "nroProveedor": $page.variables.rowSelected.proveedor,
                "modoUso": "4",
                "listaRolesSt": "",
                "ciaDefault": "",
                "fechaDesde": "",
                "fechaHasta": "",
                "esProveedor": "",
                "activo": "",
                "aprobado": "",
                "activarUsuarioOCI": "0"
            };

            const response3 = await Actions.callRest(context, {
                endpoint: 'GatewayPortal2/postQ71PO_GestionarUsuarioPortal',
                body: payload,
            });

            await Actions.callChain(context, {
                chain: 'application:verificar_respuesta_jdeError',
                params: {
                    error: !response3.ok,
                    funcion: 'GestionarUsuarioPortal',
                    funcionalidad: $variables.funcionalidad,
                    transaccion: $page.variables.rowSelected.proveedor,
                    status: response3.status,
                    observaciones: 'DESACTIVAR_PROVEEDOR',
                },
            });

            // FIn Desactivar usuarios del proveedor

            await Actions.callChain(context, {
                chain: 'application:guardar_log',
                params: {
                    accion: 'DESACTIVAR_PROVEEDOR_OK',
                    funcionalidad: $page.variables.funcionalidadSeleccionada,
                    numeroAn8: $application.variables.user.numeroAn8,
                    pagina: $flow.currentPage,
                    proveedor: $application.variables.user.esProveedor,
                    roles: $application.variables.userRoles.userRolesSt,
                    suscriptorId: $application.variables.suscriptor.id,
                    usuario: $application.variables.user.ociUser,
                    transaccion: $page.variables.rowSelected.proveedor.toString().padStart(8, '0'),
                    observaciones: ""
                },
            });

            await Actions.callChain(context, {
                chain: 'actTablaBuscar',
            });

            const popUpDesactivarClose = await Actions.callComponentMethod(context, {
                selector: '#popUpDesactivar',
                method: 'close',
            });
			
			} 
            $variables.buscando = false;
        }
    }

    return actPopUpDesactivar_Confirmar;
});