define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actOpcionDesactivarProveedor extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $vriables, $variables } = context;

      $variables.buscando = true;    
      const proveedorOK = await Actions.callChain(context, {
        chain: 'application:verificar_proveedor',
        params: {
          paramNroProveedor: $page.variables.rowSelected.proveedor,
          paramTipoBusqueda: $page.variables.rowSelected.tipoBusqueda,
          paramAccion: 'desactivar',
        },
      });

 if ($page.variables.varRetenerOrden==="") {

          const notificarError = await Actions.callChain(context, {
            chain: 'application:notificar_error',
            params: {
              codigo: 'falta-configuracion',
              descripcion: "Constante RETENER_ORDEN no definida",
            },
          });
        }

      if (!proveedorOK.proveedorOK || $page.variables.varRetenerOrden ==="") {
    
        const notificarError = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            codigo: 'error_intento_desactivar_proveedor',
          },
        });
      } else {

        const popUpDesactivarOpen = await Actions.callComponentMethod(context, {
          selector: '#popUpDesactivar',
          method: 'open',
        });

      }

      $variables.buscando = false;
 
    }
  }

  return actOpcionDesactivarProveedor;
});
