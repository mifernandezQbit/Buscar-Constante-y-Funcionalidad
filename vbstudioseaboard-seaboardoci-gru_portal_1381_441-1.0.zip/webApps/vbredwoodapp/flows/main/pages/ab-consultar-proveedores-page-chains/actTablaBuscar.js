define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actTablaBuscar extends ActionChain {

    /**
     * Se ejecuta al hacer click en el icono de la lupa para buscar datos para la tabla
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $variables } = context;

      $variables.buscando = true;

      if ($variables.tipoProveedorSeleccionado === undefined) {
        const notificarError3 = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            codigo: 'tipo-busqueda-obligatorio',
            modoVisualizacion: '',
          },
        });
      }

      if (($page.variables.razonSocial === undefined || $page.variables.razonSocial === "") && 
      ($page.variables.cuitBD === undefined || $page.variables.cuitBD === "") && 
      ($page.variables.nroProveedor === undefined || $page.variables.nroProveedor==="")) {
        const notificarError = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            codigo: 'dato-obligatorio',
            modoVisualizacion: '',
          },
        });
      } else {

//MIF agrego condicional para que no busque si no hay tipo de búsqueda seleccionado
if ($variables.tipoProveedorSeleccionado !== undefined) {


          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.libroDireccionesArray',
  ],
          });
  
        const CC_TIPO_PROVEEDOR = await Actions.callChain(context, {
          chain: 'application:buscar_constante',
          params: {
            constante: 'CC_TIPO_PROVEEDOR',
          },
        });

          const guardarLog = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              accion: 'BUSCAR',
              funcionalidad: $page.variables.funcionalidad,
              numeroAn8: $application.variables.user.numeroAn8,
              pagina: $application.currentPage.id,
              proveedor: $application.variables.user.esProveedor,
              roles: $application.variables.userRoles.userRolesSt,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              transaccion: $page.variables.tipoProveedorSeleccionado.code +($page.variables.razonSocial !==undefined && $page.variables.razonSocial!=="" ? " - " + $page.variables.razonSocial :"")  + ($page.variables.cuitBD !==undefined && $page.variables.cuitBD!=="" ? " - " + $page.variables.cuitBD :"") + ($page.variables.nroProveedor !==undefined && $page.variables.nroProveedor!=="" ? " - " + $page.variables.nroProveedor :""),
            },
          });
        if ($page.variables.listaProveedoresArray.length !== 0) {
                  //MIF Inicio override seguridad activada y roles
                  let seguridadCC = $application.variables.seguridadCCActivada;
                  let rolesJDEcc= $application.variables.userRoles.rolesJDE;
                
                  if (seguridadCC &&  $application.variables.seguridadCCItemsDD.MCU !==undefined && $application.variables.seguridadCCItemsDD.MCU !=="Y") {
                    seguridadCC = false;
                    rolesJDEcc=[];
                  }
                   //MIF Fin override seguridad activada y roles
 
          let libroDirecciones = await Actions.callRest(context, {
            endpoint: 'GatewayPortal/postQ71PO_BuscarLibroDirecciones',
            body: {
              token: $application.variables.token,
              tipoBusqueda: $page.variables.tipoProveedorSeleccionado.code,
              P01012_Version: $page.variables.param_P01012Version,
              razonSocial:$page.variables.razonSocial!== undefined ? "*" + $page.variables.razonSocial+ "*":"" ,
              idFiscal: $page.variables.cuitBD,
              listaTipoProveedores: $page.variables.listaProveedoresArray,
              ccTipoProveedor: CC_TIPO_PROVEEDOR.valor,
              nroDireccion: $page.variables.nroProveedor,
              rolesJDE : rolesJDEcc,
              seguridadInclusiva : $application.variables.seguridadCCInclusiva,
              seguridadCCActivada:seguridadCC
            },
          });

          await Actions.callChain(context, {
            chain: 'application:verificar_respuesta_jdeError',
            params: {
              error: !libroDirecciones.ok,
              funcion: 'BuscarLibroDirecciones',
              funcionalidad: $variables.funcionalidad,
              tokenExpirado: libroDirecciones.body.tokenExpirado,
               status:libroDirecciones.status,
            },
          });

          //MIF si hubo resultados asigna valor, sino no
          if (libroDirecciones.body.rowset!==undefined) {
          $page.variables.libroDireccionesArray = libroDirecciones.body.rowset ? libroDirecciones.body.rowset : [] ;
                 }

        } else {
          const notificarError2 = await Actions.callChain(context, {
            chain: 'application:notificar_error',
            params: {
              codigo: 'falta-configuracion',
            },
          });
        }
      }
    }

      $variables.buscando = false;
    }
  }

  return actTablaBuscar;
});
