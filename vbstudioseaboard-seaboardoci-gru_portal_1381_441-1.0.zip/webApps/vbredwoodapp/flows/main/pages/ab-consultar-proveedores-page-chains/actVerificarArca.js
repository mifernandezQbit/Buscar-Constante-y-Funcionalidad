define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actVerificarArca extends ActionChain {

    /**
     * @param {Object} context
     * @return {boolean} 
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;


      const responsepostQ71PO_GetPersonaV2 = await Actions.callRest(context, {
        endpoint: 'GatewayPortal2/postQ71PO_GetPersonaV2',
        body: {
          token: $application.variables.token,
          CompanyKey: $application.variables.selectedCompany.company,
          cuit: $application.variables.selectedCompany.cuit,
          idPersona: $variables.proveedorRollback.idFiscal,
        },
      });

      await Actions.callChain(context, {
        chain: 'application:verificar_respuesta_jdeError',
        params: {
          error: !responsepostQ71PO_GetPersonaV2.ok,
          funcion: 'GetPersonaV2',
          funcionalidad: '',
          tokenExpirado: responsepostQ71PO_GetPersonaV2.body.tokenExpirado,
          transaccion: '',
           status:responsepostQ71PO_GetPersonaV2.status,
        },
      });

      const guardarLog = await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'CONSULTA_PERSONA_ARCA',
          funcionalidad: $page.variables.funcionalidad,
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          observaciones: $variables.proveedorRollback.idFiscal,
          transaccion:  $page.variables.rowSelected.proveedor.toString().padStart(8,'0'),
        },
      });

      if (responsepostQ71PO_GetPersonaV2.body.errorJde === false) {
        if (responsepostQ71PO_GetPersonaV2.body.errorCodeArca === "0") {
          $variables.personaArca = responsepostQ71PO_GetPersonaV2.body.data;
          return true;
        } else {
          const notificarError2 = await Actions.callChain(context, {
            chain: 'application:notificar_error',
            params: {
              titulo: 'ID no es válido',
              descripcion: '',
              tipoNotificacion: 'info',
              modoVisualizacion: 'persist',
            },
          });
          return false;
        }
      } else {
        const notificarError2 = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            titulo: 'Error en ARCA',
            descripcion: '',
            tipoNotificacion: 'error',
            modoVisualizacion: 'persist',
          },
        });

        const guardarLog2 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              accion: 'CONSULTA_PERSONA_ARCA_ERROR',
              funcionalidad: $page.variables.funcionalidad,
              numeroAn8: $application.variables.user.numeroAn8,
              pagina: $flow.currentPage,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              proveedor: $application.variables.user.esProveedor,
              roles: $application.variables.userRoles.userRolesSt,
              observaciones: $variables.proveedorRollback.idFiscal,
          transaccion:  $page.variables.rowSelected.proveedor.toString().padStart(8,'0'),
            },
          });
        return false;
      }

    }
  }

  return actVerificarArca;
});