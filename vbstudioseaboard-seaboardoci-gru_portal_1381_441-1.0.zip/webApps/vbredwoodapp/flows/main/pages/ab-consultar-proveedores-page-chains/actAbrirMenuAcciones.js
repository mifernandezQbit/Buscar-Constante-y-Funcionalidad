define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actAbrirMenuAcciones extends ActionChain {

    /**
     * Se ejecuta una validacion para arrojar error si el usuario no selecciono una opcion de la tabla
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      if ($page.variables.seleccionoProveedor === false) 
      {
        const notificarError = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            codigo: 'seleccionar-registro',
          },
        });
      }
    }
  }

  return actAbrirMenuAcciones;
});
