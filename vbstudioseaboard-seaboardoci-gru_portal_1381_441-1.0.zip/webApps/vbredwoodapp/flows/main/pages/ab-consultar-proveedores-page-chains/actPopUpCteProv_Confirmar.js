define([
        'vb/action/actionChain',
        'vb/action/actions',
        'vb/action/actionUtils',
    ], (
        ActionChain,
        Actions,
        ActionUtils) => {
    'use strict';

    class actPopUpCteProv_Confirmar extends ActionChain {

        /**
         * @param {Object} context
         */
        async run(context) {
            const { $page, $flow, $application, $constants, $variables } = context;

            $variables.buscando = true;

            let errorMail = false;
            let errorSeguridad = false; //MIF

            if ($page.variables.mjsEmail === null || $page.variables.mjsEmail === "") {
                const notificarError = await Actions.callChain(context, {
                    chain: 'application:notificar_error',
                    params: {
                        codigo: 'falta-mail',
                        modoVisualizacion: '',
                    },
                });
                errorMail = true;
            }

            // MIF si no hay error, valido si tiene permiso para la seguridad por CC
            if (!errorMail && $application.variables.seguridadCCActivada) {
                // Verificar seguridad.

                const seguridadOk = await Actions.callChain(context, {
                  chain: 'application:validar_seguridad',
                  params: {
                    accionJDE: 'C',
                    funcionalidad: 'MODIFICAR_PROVEEDOR',
                    nroProveedor: $variables.rowSelected.proveedor,
                    valor: $variables.unidadNegocio,
                  },
                });

                errorSeguridad = !seguridadOk;
            }

            // MIF si hubo error de mail o seguridad no sigo procesando
            let error = errorMail || errorSeguridad;

            if (!error) {
                // Valido que el centro de costos tenga el código de categoría que se usa en WF configurado si se usa WF
                const actBuscarCodCatUnidadNegocio = await Actions.callChain(context, {
                    chain: 'application:actBuscarCodCatUnidadNegocio',
                    params: {
                        unidadNegocio: $variables.unidadNegocio,
                        wfFacturas: false,
                    },
                });

                if (actBuscarCodCatUnidadNegocio.ok === true) {
                    // guardo log confirma
                    await Actions.callChain(context, {
                        chain: 'application:guardar_log',
                        params: {
                            accion: 'CONFIRMA',
                            suscriptorId: $application.variables.suscriptor.id,
                            numeroAn8: $application.variables.user.numeroAn8,
                            proveedor: $application.variables.user.esProveedor,
                            funcionalidad: $page.variables.funcionalidadSeleccionada,
                            pagina: $application.currentPage.id,
                            roles: $application.variables.userRoles.userRolesSt,
                            usuario: $application.variables.user.ociUser,
                            transaccion: $page.variables.rowSelected.proveedor.toString().padStart(8, '0'),
                        },
                    });

                    // guardo grupo de unidad de negocio para workflow
                    $variables.codCatUnNegocio = actBuscarCodCatUnidadNegocio.codCatUnNegocio;
// MIF P417 - Condición de pago por defecto

          const buscarConstante = await Actions.callChain(context, {
            chain: 'application:buscar_constante',
            params: {
              constante: 'CONDICION_PAGO_DEFAULT',
            },
          });

                    const actualizarProv = await Actions.callRest(context, {
                        endpoint: 'GatewayPortal/postQ71PO_ActualizarEstadoProveedor',
                        body: {
                            "token": $application.variables.token,
                            "nroProveedor": $page.variables.rowSelected.proveedor,
                            'P01012_Version': $page.variables.p01012_Version,
                            "retenerPago": 'Y',
                            'P04012_Version': $page.variables.p04012_Version,
                            "unidadNegocio": $variables.unidadNegocio,
                            "crearF0401": "1",
                            "retenerOrden": $page.variables.varRetenerOrden,
                            "condicionPago": buscarConstante.valor //P417
                        },
                    });
                    await Actions.callChain(context, {
                        chain: 'application:verificar_respuesta_jdeError',
                        params: {
                            error: !actualizarProv.ok,
                            funcion: 'ActualizarEstadoProveedor',
                            funcionalidad: $variables.funcionalidad,
                            tokenExpirado: actualizarProv.body.tokenExpirado,
                            status: actualizarProv.status,

                        },
                    });

                    // si no hubo error avanzo con el proceso
                    if (actualizarProv.ok && !actualizarProv.body.errorJde) {

                        // MIf se agrega actualización de proveedor para actualizar el email y unidad de negocios ingresada
                        const response2 = await Actions.callRest(context, {
                            endpoint: 'GatewayPortal2/postQ71PO_ActualizarProveedor',
                            body: {
                                token: $application.variables.token,
                                nroProveedor: $page.variables.rowSelected.proveedor,
                                actualizarLD: "1",
                                actualizarEDI: "",
                                actualizarContactos: "",
                                actualizarMails: "1",
                                actualizarTelefonos: "",
                                unidadNegocio: $variables.unidadNegocio,
                                altaMaestroLD: "1",
                                emails: [{
                                        nroLinea: $variables.actualizarFilaContacto,
                                        tipoCorreo: "E",
                                        actualizarFila: $variables.actualizarFilaMAIL,
                                        categoriaEmail: $variables.consTipoMailPpal,
                                        email: $variables.mjsEmail,
                                        indicadorMensajes: "1"
                                    }
                                ],
                                'P01012_Version': $page.variables.p01012_Version,
                            },
                        });

                        await Actions.callChain(context, {
                            chain: 'application:verificar_respuesta_jdeError',
                            params: {
                                error: !response2.ok,
                                funcion: 'ActualizarProveedor-Mails',
                                funcionalidad: $variables.funcionalidad,
                                tokenExpirado: response2.body.tokenExpirado,
                                status: response2.status,
                            },
                        });

                        // Si no hay error procedo con adjunto e inicia WF
                        if (response2.ok && !response2.body.errorJde) {

                            // si se ingresó un motivo , adjuntarlo al registro del libro de direcciones en pdf
                            // Sube adjunto
                            if ($variables.mjsCteProveedor != null && $variables.mjsCteProveedor !== "") {
                                const ADJUNTOS_VISIBLES_PORTAL_CC = await Actions.callChain(context, {
                                    chain: 'application:buscar_constante',
                                    params: {
                                        constante: 'ADJUNTOS_VISIBLES_PORTAL_CC',
                                    },
                                });

                                const ADJUNTOS_VISIBLES_PORTAL_COD = await Actions.callChain(context, {
                                    chain: 'application:buscar_constante',
                                    params: {
                                        constante: 'ADJUNTOS_VISIBLES_PORTAL_COD',
                                    },
                                });

                                $page.variables.inParamListaArchivos.incluirMetadatos = true;

                                $page.variables.inParamListaArchivos.metadatos.codigosCategoria[ADJUNTOS_VISIBLES_PORTAL_CC.valor] = ADJUNTOS_VISIBLES_PORTAL_COD.valor;

                                $page.variables.inParamListaArchivos.metadatos.mokey = $page.variables.rowSelected.proveedor;

                                $page.variables.inParamListaArchivos.numeroProveedor = $page.variables.rowSelected.proveedor;

                                $page.variables.inParamListaArchivos.tipoObjeto = 'ABGT';

                                $page.variables.inParamListaArchivos.token = $application.variables.token;

                                await Actions.callChain(context, {
                                    chain: 'application:convertir_y_subir_pdf',
                                    params: {
                                        inParamAdjuntoPDF: true,
                                        mensaje: $page.variables.mjsCteProveedor,
                                        nombrePDF: 'motivoClienteProveedor.pdf',
                                        attributosJDE: $page.variables.inParamListaArchivos,
                                    },
                                });
                            }

                            // si inicia WF
                            const wfIniciado = await Actions.callChain(context, {
                              chain: 'application:iniciar_wf',
                              params: {
                                accionJDE: 'C',
                                accionWF: 'A',
                                actDatosContabilidad: false,
                                actDatosContactos: false,
                                actDatosGenerales: false,
                                actDatosImpuestos: false,
                                actDatosOfac: false,
                                actDatosTesoreria: false,
                                actDatosTransportista: false,
                                modulo: '01',
                                funcionalidadPortal: $page.variables.funcionalidadSeleccionada,
                                usuarioOriginadorTR: $application.variables.user.numeroAn8,
                                usuarioOriginadorWF: $application.variables.user.numeroAn8,
                                usuarioSolicitante: $application.variables.user.numeroAn8,
                                nroProveedor: $page.variables.rowSelected.proveedor,
                                cdCatMaestro: $variables.codCatUnNegocio,
                                tipoBusqueda: $page.variables.tipoBusqueda.code,
                                mailProveedor: $variables.mjsEmail,
                                flag05: '1',
                              },
                            });
                            const guardarLog = await Actions.callChain(context, {
                                chain: 'application:guardar_log',
                                params: {
                                    accion: 'HABILITAR_CTE_PROV_OK',
                                    funcionalidad: $page.variables.funcionalidadSeleccionada,
                                    numeroAn8: $application.variables.user.numeroAn8,
                                    pagina: $flow.currentPage,
                                    proveedor: $application.variables.user.esProveedor,
                                    roles: $application.variables.userRoles.userRolesSt,
                                    suscriptorId: $application.variables.suscriptor.id,
                                    transaccion: $variables.rowSelected.proveedor,
                                    usuario: $application.variables.user.ociUser,
                                },
                            });

                            $variables.unidadNegocio = "";
                            $variables.proveedorRollback = {};
                            $variables.mjsCteProveedor = "";
                            $variables.codCatUnNegocio = "";
                            $variables.tipoBusqueda = "";

                            //cierro diálogo
                            const popUpCteProvClose2 = await Actions.callComponentMethod(context, {
                                selector: '#popUpCteProv',
                                method: 'close',
                            });

                            await Actions.callChain(context, {
                                chain: 'actTablaBuscar',
                            });
                        } else {
                            // guardo log confirma
                            await Actions.callChain(context, {
                                chain: 'application:guardar_log',
                                params: {
                                    accion: 'HABILITAR_CTE_PROV_ERROR',
                                    suscriptorId: $application.variables.suscriptor.id,
                                    numeroAn8: $application.variables.user.numeroAn8,
                                    proveedor: $application.variables.user.esProveedor,
                                    funcionalidad: $page.variables.funcionalidadSeleccionada,
                                    pagina: $application.currentPage.id,
                                    roles: $application.variables.userRoles.userRolesSt,
                                    usuario: $application.variables.user.ociUser,
                                    transaccion: $page.variables.rowSelected.proveedor.toString().padStart(8, '0'),
                                    observaciones: "ActualizarProveedor"
                                },
                            });
                            // error al actualizar correo del proveedor
                            const notificarError2 = await Actions.callChain(context, {
                                chain: 'application:notificar_error',
                                params: {
                                    codigo: 'actualizar-mail-error',
                                    descripcion: ' Workflow NO iniciado',
                                },
                            });

                        }
                    } else {
                        // guardo log confirma
                        await Actions.callChain(context, {
                            chain: 'application:guardar_log',
                            params: {
                                accion: 'HABILITAR_CTE_PROV_ERROR',
                                suscriptorId: $application.variables.suscriptor.id,
                                numeroAn8: $application.variables.user.numeroAn8,
                                proveedor: $application.variables.user.esProveedor,
                                funcionalidad: $page.variables.funcionalidadSeleccionada,
                                pagina: $application.currentPage.id,
                                roles: $application.variables.userRoles.userRolesSt,
                                usuario: $application.variables.user.ociUser,
                                transaccion: $page.variables.rowSelected.proveedor.toString().padStart(8, '0'),
                                observaciones: "ActualizarEstadoProveedor"
                            },
                        });
                        // Error al retener proveedor
                        const notificarError3 = await Actions.callChain(context, {
                            chain: 'application:notificar_error',
                            params: {
                                codigo: 'proveedor-actualizar-error',
                                descripcion: ' Workflow NO iniciado',
                            },
                        });
                    }
                }
            }

            $variables.buscando = false;

        }
    }

    return actPopUpCteProv_Confirmar;
});