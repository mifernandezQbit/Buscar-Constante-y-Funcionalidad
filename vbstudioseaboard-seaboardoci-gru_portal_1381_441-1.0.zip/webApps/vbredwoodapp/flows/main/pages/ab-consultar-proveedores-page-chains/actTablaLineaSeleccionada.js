define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actTablaLineaSeleccionada extends ActionChain {

    /**
     * First Selected Row
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.rowKey 
     * @param {any} params.rowData 
     */
    async run(context, { rowKey, rowData }) {
      const { $page, $flow, $application, $variables } = context;

      $variables.rowSelected = rowData;
    }
  }

  return actTablaLineaSeleccionada;
});
