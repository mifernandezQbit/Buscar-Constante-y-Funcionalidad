define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actInicio extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $variables } = context;

      $variables.buscando = true;

      const permisosFuncionalidad = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: 'CONSULTAR_PROVEEDORES',
        },
      });
      if (permisosFuncionalidad.existe === false) {

        const guardarLog = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'INTENTO_INGRESO_NH',
            suscriptorId: $application.variables.suscriptor.id,
            numeroAn8: $application.variables.user.numeroAn8,
            proveedor: $application.variables.user.esProveedor,
            funcionalidad: 'CONSULTAR_PROVEEDORES',
            pagina: $application.currentPage.id,
            roles: $application.variables.userRoles.userRolesSt,
            usuario: $application.variables.user.ociUser,
          },
        });

        const toAccesoNoAutorizado = await Actions.navigateToPage(context, {
          page: 'acceso-no-autorizado',
        });

      // hay que ver respuesta para ver si la condicion esta correcta y ver de donde se consulta si usuario es "P"
      } else {
        const buscarConstante = await Actions.callChain(context, {
          chain: 'application:buscar_constante',
          params: {
            constante: 'WF_CC_MCU_AUTORIZANTE',
          },
        });

        if (buscarConstante.existe === true) {
          $variables.nroCodCatUnNegocio = buscarConstante.valor;
        }

         if ($application.variables.user.esProveedor === true) {
          const guardarLog2 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              accion: 'INTENTO_INGRESO_NH',
              funcionalidad: $page.variables.funcionalidad,
              numeroAn8: $application.variables.user.numeroAn8,
              pagina: $application.currentPage.id,
              proveedor: $application.variables.user.esProveedor,
              roles: $application.variables.userRoles.userRolesSt,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
            },
          });

          const notificarError2 = await Actions.callChain(context, {
            chain: 'application:notificar_error',
            params: {
              codigo: 'verificar-permisos-proveedor',
            },
          });
        } else {
          const guardarLog3 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              accion: 'INGRESA',
              funcionalidad: $page.variables.funcionalidad,
              numeroAn8: $application.variables.user.numeroAn8,
              pagina: $application.currentPage.id,
              proveedor: $application.variables.user.esProveedor,
              roles: $application.variables.userRoles.userRolesSt,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
            },
          });

          const permisosFuncionalidad1 = await Actions.callChain(context, {
            chain: 'application:verificar_permisos_funcionalidad_obj',
            params: {
              funcionalidad: 'CREAR_PROVEEDOR',
            },
          });

          if (permisosFuncionalidad1.existe === false) {
            $page.variables.mostrarCrearProveedor = false;
          } else {
            $page.variables.mostrarCrearProveedor = true;
          }

          const CC_TIPO_PROVEEDOR = await Actions.callChain(context, {
            chain: 'application:buscar_constante',
            params: {
              constante: 'CC_TIPO_PROVEEDOR',
            },
          });

          if (CC_TIPO_PROVEEDOR.existe === true) {

            const UDC_D02 = await Actions.callChain(context, {
              chain: 'application:buscar_constante',
              params: {
                constante: 'UDC_D02',
              },
            });

            if (UDC_D02.existe === true) {

              $page.variables.constUDCD02 = "*" + UDC_D02.valor + "*";
            } else {
              $page.variables.constUDCD02 = UDC_D02.valor;
            }

// recupero versión de consulta de provedores y libro direcciones
const P01012_Version = await Actions.callChain(context, {
                    chain: 'application:buscar_constante',
                    params: {
                        constante: 'P01012_Version',
                    },
                });

                  if (P01012_Version.existe === true && P01012_Version.valor !== undefined && P01012_Version.valor !== "") {
              $page.variables.p01012_Version = P01012_Version.valor;
            } else {
              $page.variables.p01012_Version = "";
            }

            const P04012_Version = await Actions.callChain(context, {
                    chain: 'application:buscar_constante',
                    params: {
                        constante: 'P04012_Version',
                    },
                });

                  if (P04012_Version.existe === true && P04012_Version.valor !== undefined && P04012_Version.valor !== "") {
              $page.variables.p04012_Version = P04012_Version.valor;
            } else {
              $page.variables.p04012_Version = "";
            }

            // recupero constante para saber el código para retener orden en proveedores que van a WF
            
            const RETENER_ORDEN = await Actions.callChain(context, {
              chain: 'application:buscar_constante',
              params: {
                constante: 'RETENER_ORDEN',
              },
            });

            if (RETENER_ORDEN.existe === true && RETENER_ORDEN.valor !== undefined && RETENER_ORDEN.valor !== "") {
              $page.variables.varRetenerOrden = RETENER_ORDEN.valor;
            } else {
              $page.variables.varRetenerOrden = "";
            }

            // recupero constante para saber que tipo de mail se usa como principal para portal
            const tipoEmailPrincipal = await Actions.callChain(context, {
                      chain: 'application:buscar_constante',
                      params: {
                        constante: 'TIPO_MAIL_PRINCIPAL',
                      },
                    });
            
             if (tipoEmailPrincipal.existe === true && tipoEmailPrincipal.valor !== undefined && tipoEmailPrincipal.valor !== "") {
              $page.variables.consTipoMailPpal = tipoEmailPrincipal.valor;
            } else {
              $page.variables.consTipoMailPpal = "";
            }

            // busca udc
            const response = await Actions.callRest(context, {
              endpoint: 'GatewayPortal/postQ71PO_BuscarValoresUDC',
              body: {
                token: $application.variables.token,
                'P0004A_Version': '',
                udcToSearch: [
                  {
                    productCode: '01',
                    userDefinedCode: 'ST',
                    description1: '',
                    description2: $page.variables.constUDCD02,
                    specialHandling: '',
                  },
                  {
                    productCode: '01',
                    userDefinedCode: CC_TIPO_PROVEEDOR.valor,
                    description1: '',
                    description2: '',
                    specialHandling: ''
                  },
                  {//Tipo Documento
                    productCode: '76A',
                    userDefinedCode: 'A0',
                    description1: '',
                    description2: '',
                    specialHandling: ''
                  },
                  {//Paises
                    productCode: '00',
                    userDefinedCode: 'CN',
                    description1: '',
                    description2: '',
                    specialHandling: ''
                  }
                ],
              },
            });

            await Actions.callChain(context, {
              chain: 'application:verificar_respuesta_jdeError',
              params: {
                error: !response.ok,
                funcion: 'BuscarValoresUDC',
                funcionalidad: $variables.funcionalidad,
                tokenExpirado: response.body.tokenExpirado,
                status:response.status,
              },
            });

            $page.variables.tipoProveedorArray = response.body.rowset[0].codesList;
            $page.variables.listaProveedoresArray = response.body.rowset[1].codesList;
            $page.variables.tipoDocumentoArray = response.body.rowset[2].codesList;
            $page.variables.paisesArray = response.body.rowset[3].codesList;

          } else {

            const notificarError3 = await Actions.callChain(context, {
              chain: 'application:notificar_error',
              params: {
                codigo: 'falta-configuracion',
              },
            });
          }
         }
      }

      $variables.buscando = false;
    }
  }

  return actInicio;
});
