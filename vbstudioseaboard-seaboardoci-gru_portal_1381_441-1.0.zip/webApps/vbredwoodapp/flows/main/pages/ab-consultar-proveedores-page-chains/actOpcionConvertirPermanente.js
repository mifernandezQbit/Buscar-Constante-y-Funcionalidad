define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actOpcionConvertirPermanente extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $variables } = context;
    $variables.buscando = true;
      const verificarProveedor = await Actions.callChain(context, {
        chain: 'application:verificar_proveedor',
        params: {
          paramAccion: 'permanente',
          paramNroProveedor: $page.variables.rowSelected.proveedor,
          paramTipoBusqueda: $page.variables.rowSelected.tipoBusqueda,
        },
      });

        if ($page.variables.varRetenerOrden==="") {

          const notificarError = await Actions.callChain(context, {
            chain: 'application:notificar_error',
            params: {
              codigo: 'falta-configuracion',
              descripcion: "Constante RETENER_ORDEN no definida",
            },
          });
        }

      if (verificarProveedor.proveedorOK === true && $page.variables.varRetenerOrden !=="") {

                let estadoRetenido = await Actions.callRest(context, {
          endpoint: 'GatewayPortal2/postQ71PO_BuscarDatosProveedor',
          body: {
            token: $application.variables.token,
            tipoProceso: '1',
            nroProveedor: $page.variables.rowSelected.proveedor,
            'P01012_Version': $page.variables.p01012_Version,
            esTransportista: '',
            'P4906_Version': '',
            'PQ71102A_Version': '',
            'PQ711012_Version': '',
            'P0101Z1_Version': '',
            'P0401Z1_Version': '',
            'P0111Z1_Version': '',
            procesado: '',
            company: '',
          },
        });
                    await Actions.callChain(context, {
              chain: 'application:verificar_respuesta_jdeError',
              params: {
                error: !estadoRetenido.ok,
                funcion: 'BuscarDatosProveedor',
                funcionalidad: $page.variables.funcionalidad,
                tokenExpirado: estadoRetenido.body.tokenExpirado,
                 status:estadoRetenido.status,
              },
            });

if (estadoRetenido.ok && !estadoRetenido.body.errorJde) {
  //MIF inicializo email
         $variables.actualizarFilaContacto ="";
                    $variables.actualizarFilaMAIL = "";
                    $variables.mjsEmail = "";
                    
        $page.variables.proveedorRollback.tipoBusqueda = $page.variables.rowSelected.tipoBusqueda;
        $page.variables.proveedorRollback.estadoRetenido = estadoRetenido.body.data.retenerPago;
        $page.variables.proveedorRollback.unidadNegocio = estadoRetenido.body.data.unidadNegocio;
                $page.variables.unidadNegocio = estadoRetenido.body.data.unidadNegocio;

// recupero mail del proveedor
              Object.entries(estadoRetenido.body.data.contactos).map(([key, value]) => {

                Object.entries(value.emails).map(([keyEmails, valueEmails]) => {
                  if (valueEmails.categoriaEmail ===$variables.consTipoMailPpal) {
                    $variables.actualizarFilaContacto = value.nroLinea;
                    $variables.actualizarFilaMAIL = valueEmails.nroLinea;
                    $variables.mjsEmail = valueEmails.email;
                  }
                });
              });
              
        const popUpConvertirPermanenteOpen = await Actions.callComponentMethod(context, {
          selector: '#popUpConvertirPermanente',
          method: 'open',
        });

        } else {

          const notificarError2 = await Actions.callChain(context, {
            chain: 'application:notificar_error',
            params: {
              codigo: 'error-jde-recupero-datos',
            },
          });
          
        }


      }

      $variables.buscando = false;  }
  }

  return actOpcionConvertirPermanente;
});
