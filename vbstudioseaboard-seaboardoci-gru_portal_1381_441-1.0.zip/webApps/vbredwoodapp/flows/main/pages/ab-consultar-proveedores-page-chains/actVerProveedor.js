define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actVerProveedor extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if ($variables.rowSelected.proveedor === undefined) {

        const notificarError = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            codigo: 'seleccionar-registro',
          },
        });
        
      }
else {
  await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              accion: 'VER_PROVEEDOR',
              suscriptorId: $application.variables.suscriptor.id,
              numeroAn8: $application.variables.user.numeroAn8,
              proveedor: $application.variables.user.esProveedor,
              funcionalidad: 'CONSULTAR_PROVEEDORES',
              pagina: $application.currentPage.id,
              roles: $application.variables.userRoles.userRolesSt,
              usuario: $application.variables.user.ociUser,
               transaccion:  $page.variables.rowSelected.proveedor.toString().padStart(8,'0'),
            },
          });
      const toAbConsultarProveedor = await Actions.navigateToPage(context, {
        page: 'ab-consultar-proveedor',
        params: {
          nroProveedor: $variables.rowSelected.proveedor,
          paramTipoChatIDMenu: $variables.paramTipoObjetoChat,
          paramTipoBusqueda: $variables.rowSelected.tipoBusqueda,
          paramUnidadNegocio: $variables.rowSelected.unidadNegocio,
        },
      });
}
    }
  }

  return actVerProveedor;
});
