define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actMenuPermisos extends ActionChain {

    /**
     * Habilita (o no) las opciones del menu al iniciar la pagina, segun los permisos del usuario
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const permisoMensaje = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: 'CHAT_PROVEEDOR',
        },
      });

      $page.variables.opcionesPermisos.opcMensaje = permisoMensaje.existe;

      const permisoEditar = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: 'CREAR_PROVEEDOR',
        },
      });

      $page.variables.opcionesPermisos.opcEditar = permisoEditar.existe;

      const permisoPermanente = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: 'CONVERTIR_PROVEEDOR_PERMANENTE',
        },
      });

      $page.variables.opcionesPermisos.opcPermanente = permisoPermanente.existe;

      const permisoDesactivar = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: 'DESACTIVAR_PROVEEDOR',
        },
      });

      $page.variables.opcionesPermisos.opcDesactivar = permisoDesactivar.existe;

      const permisoActivar = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: 'ACTIVAR_PROVEEDOR',
        },
      });

      $page.variables.opcionesPermisos.opcActivar = permisoActivar.existe;

      const permisoCteProv = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: 'HABILITAR_CLIENTE_PROVEEDOR',
        },
      });

      $page.variables.opcionesPermisos.opcCteProv = permisoCteProv.existe;
    }
  }

  return actMenuPermisos;
});
