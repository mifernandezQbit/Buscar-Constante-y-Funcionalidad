define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBotonCrearProveedor extends ActionChain {

    /**
     * Se ejecuta al hacer click en boton Nuevo
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $variables } = context;

      const Log = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              accion: 'CREAR_PROVEEDOR',
              funcionalidad: $page.variables.funcionalidad,
              numeroAn8: $application.variables.user.numeroAn8,
              pagina: $application.currentPage.id,
              proveedor: $application.variables.user.esProveedor,
              roles: $application.variables.userRoles.userRolesSt,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
            },
          });

      const toAbAltaProveedor = await Actions.navigateToPage(context, {
        page: 'ab-alta-proveedor',
          params: {
          parFuncionalidad: 'CREAR_PROVEEDOR',
          parVersionJde: $variables.param_P01012Version,
        },
      });

      // A1 - Usuario da de alta nuevo proveedor
     

    }
  }

  return actBotonCrearProveedor;
});
