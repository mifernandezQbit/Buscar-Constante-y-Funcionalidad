define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actOpcionMenuSeleccionada extends ActionChain {

    /**
     * Se ejecuta al seleccionar una opcion del menu
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.menuId 
     */
    async run(context, { menuId }) {
      const { $page, $flow, $application, $variables } = context;
      $variables.funcionalidadSeleccionada = menuId;

      switch (menuId) {
        case 'CHAT_PROVEEDOR':

          const guardarLog = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              accion: 'VER_MENSAJES',
              suscriptorId: $application.variables.suscriptor.id,
              numeroAn8: $application.variables.user.numeroAn8,
              proveedor: $application.variables.user.esProveedor,
              funcionalidad: $page.variables.funcionalidadSeleccionada,
              pagina: $application.currentPage.id,
              roles: $application.variables.userRoles.userRolesSt,
              usuario: $application.variables.user.ociUser,
              transaccion:  $page.variables.rowSelected.proveedor.toString().padStart(8,'0'),
            },
          });

          const numeroRandom = await this.mostrarDrawerRandom(context);

          $page.variables.mostrarDrawer_mensaje = numeroRandom;
          break;
        case 'CONVERTIR_PROVEEDOR_PERMANENTE':

 await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              accion: 'CONVERTIR_PROVEEDOR_PERMANENTE',
              suscriptorId: $application.variables.suscriptor.id,
              numeroAn8: $application.variables.user.numeroAn8,
              proveedor: $application.variables.user.esProveedor,
              funcionalidad: $page.variables.funcionalidadSeleccionada,
              pagina: $application.currentPage.id,
              roles: $application.variables.userRoles.userRolesSt,
              usuario: $application.variables.user.ociUser,
               transaccion:  $page.variables.rowSelected.proveedor.toString().padStart(8,'0'),
            },
          });

          await Actions.callChain(context, {
            chain: 'actOpcionConvertirPermanente',
          });
          break;
        case 'DESACTIVAR_PROVEEDOR':
 await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              accion: 'DESACTIVAR_PROVEEDOR',
              suscriptorId: $application.variables.suscriptor.id,
              numeroAn8: $application.variables.user.numeroAn8,
              proveedor: $application.variables.user.esProveedor,
              funcionalidad: $page.variables.funcionalidadSeleccionada,
              pagina: $application.currentPage.id,
              roles: $application.variables.userRoles.userRolesSt,
              usuario: $application.variables.user.ociUser,
               transaccion:  $page.variables.rowSelected.proveedor.toString().padStart(8,'0'),
            },
          });

          await Actions.callChain(context, {
            chain: 'actOpcionDesactivarProveedor',
          });
          break;
        case 'ACTIVAR_PROVEEDOR':

await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              accion: 'ACTIVAR_PROVEEDOR',
              suscriptorId: $application.variables.suscriptor.id,
              numeroAn8: $application.variables.user.numeroAn8,
              proveedor: $application.variables.user.esProveedor,
              funcionalidad: $page.variables.funcionalidadSeleccionada,
              pagina: $application.currentPage.id,
              roles: $application.variables.userRoles.userRolesSt,
              usuario: $application.variables.user.ociUser,
               transaccion:  $page.variables.rowSelected.proveedor.toString().padStart(8,'0'),
            },
          });

          await Actions.callChain(context, {
            chain: 'actOpcionActivarProveedor',
          });
          break;
        case 'HABILITAR_CTE_PROV':

await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              accion: 'HABILITAR_CTE_PROV',
              suscriptorId: $application.variables.suscriptor.id,
              numeroAn8: $application.variables.user.numeroAn8,
              proveedor: $application.variables.user.esProveedor,
              funcionalidad: $page.variables.funcionalidadSeleccionada,
              pagina: $application.currentPage.id,
              roles: $application.variables.userRoles.userRolesSt,
              usuario: $application.variables.user.ociUser,
               transaccion:  $page.variables.rowSelected.proveedor.toString().padStart(8,'0'),
            },
          });

          await Actions.callChain(context, {
            chain: 'actOpcionCteProv',
          });
          break;
                case 'CREAR_PROVEEDOR':

          await Actions.callChain(context, {
            chain: 'actBotonCrearProveedor',
          });
          break;
        default:
          break;
      }
    }

    /**
     * @param {Object} context
     */
    async mostrarDrawerRandom(context) {
      const { $page, $flow, $application } = context;
      let random = Math.random(1,10);
      return random;
    }
  }

  return actOpcionMenuSeleccionada;
});
