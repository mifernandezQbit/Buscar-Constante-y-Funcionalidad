define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actOpcionCteProv extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

    $variables.buscando = true;
      const proveedorOK = await Actions.callChain(context, {
        chain: 'application:verificar_proveedor',
        params: {
          paramNroProveedor: $page.variables.rowSelected.proveedor,
          paramTipoBusqueda: $page.variables.rowSelected.tipoBusqueda,
          paramAccion: 'cliente-proveedor',
          inactivo: true,
        },
      });

 if ($page.variables.varRetenerOrden==="") {

          const notificarError = await Actions.callChain(context, {
            chain: 'application:notificar_error',
            params: {
              codigo: 'falta-configuracion',
              descripcion: "Constante RETENER_ORDEN no definida",
            },
          });
        }

      if (proveedorOK.proveedorOK === true && $page.variables.varRetenerOrden !=="") {   

        let estadoRetenido = await Actions.callRest(context, {
          endpoint: 'GatewayPortal2/postQ71PO_BuscarDatosProveedor',
          body: {
            token: $application.variables.token,
            tipoProceso: '1',
            nroProveedor: $page.variables.rowSelected.proveedor,
            'P01012_Version': $page.variables.p01012_Version,
            esTransportista: '',
            'P4906_Version': '',
            'PQ71102A_Version': '',
            'PQ711012_Version': '',
            'P0101Z1_Version': '',
            'P0401Z1_Version': '',
            'P0111Z1_Version': '',
            procesado: '',
            company: '',
          },
        });

            await Actions.callChain(context, {
              chain: 'application:verificar_respuesta_jdeError',
              params: {
                error: !estadoRetenido.ok,
                funcion: 'BuscarDatosProveedor',
                funcionalidad: $variables.funcionalidad,
                tokenExpirado: estadoRetenido.body.tokenExpirado,
                status: estadoRetenido.status,
              },
            });

            if (estadoRetenido.ok) {
              if (!estadoRetenido.body.errorJde) {
   $variables.proveedorRollback.estadoRetenido = estadoRetenido.body.data.retenerPago;

        $variables.proveedorRollback.tipoBusqueda = $page.variables.rowSelected.tipoBusqueda;
         $page.variables.proveedorRollback.unidadNegocio = estadoRetenido.body.data.unidadNegocio;
                 $variables.unidadNegocio =estadoRetenido.body.data.unidadNegocio;
/** MIF Recupero email para crearle usuario portal */
   $variables.actualizarFilaContacto = "";
                    $variables.actualizarFilaMAIL = "";
                    $variables.mjsEmail = "";
              Object.entries(estadoRetenido.body.data.contactos).map(([key, value]) => {

                Object.entries(value.emails).map(([keyEmails, valueEmails]) => {
                  if (valueEmails.categoriaEmail === $variables.consTipoMailPpal) {
                    $variables.actualizarFilaContacto = value.nroLinea;
                    $variables.actualizarFilaMAIL = valueEmails.nroLinea;
                    $variables.mjsEmail = valueEmails.email;
                  }
                });
              });
        const popUpCteProvOpen = await Actions.callComponentMethod(context, {
          selector: '#popUpCteProv',
          method: 'open',
        });
              
              } else {

            const notificarError2 = await Actions.callChain(context, {
              chain: 'application:notificar_error',
              params: {
                codigo: 'error-usuario-obtener-datos-proveedor',
                descripcion: " Página: " + $application.currentPage.id + ". Acción: Convertir cliente en proveedor",
              },
            });

              }
            }
     
      }

      $variables.buscando = false;
    }
  }

  return actOpcionCteProv;
});
