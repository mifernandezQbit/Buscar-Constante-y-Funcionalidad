define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actSelectTipoProveedor extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.previousValue
     * @param {any} params.value
     * @param {string} params.updatedFrom
     * @param {any} params.key
     * @param {any} params.data
     * @param {any} params.metadata
     * @param {any} params.valueItem
     */
    async run(context, { event, previousValue, value, updatedFrom, key, data, metadata, valueItem }) {
    
      const { $page, $flow, $application, $constants, $variables } = context;
  console.log('>>> MN ENTRA: actSelectTipoProveedor', {
    deposito: $variables.parametrosCabecera.deposito,
    idFiscal: $variables.parametrosCabecera.idFiscal,
    pais: $variables.parametrosCabecera.pais,
    tipoBusqueda: $variables.parametrosCabecera.tipoBusqueda,
    tipoDocumento: $variables.parametrosCabecera.tipoDocumento,
    tipoProveedor: $variables.parametrosCabecera.tipoProveedor,
    tipoSocietario: $variables.parametrosCabecera.tipoSocietario,
    razonSocial: $variables.razonSocial,
    showBadgeProveedorExtranjero: $variables.showBadgeProveedorExtranjero
});
      if (data !== undefined && data !== null) {
        $page.variables.flagTipoProveedorSel = true;
      } else { $page.variables.flagTipoProveedorSel = false;}
    }
  }

  return actSelectTipoProveedor;
});
