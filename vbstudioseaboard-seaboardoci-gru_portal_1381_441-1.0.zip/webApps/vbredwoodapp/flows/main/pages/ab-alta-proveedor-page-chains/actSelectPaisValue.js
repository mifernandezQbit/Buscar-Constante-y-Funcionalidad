define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actSelectPaisValue extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {

      const { $page, $flow, $application, $variables, $fragment } = context;
       console.log('>>> MN ENTRA: actSelectPaisValue', {
    deposito: $variables.parametrosCabecera.deposito,
    idFiscal: $variables.parametrosCabecera.idFiscal,
    pais: $variables.parametrosCabecera.pais,
    tipoBusqueda: $variables.parametrosCabecera.tipoBusqueda,
    tipoDocumento: $variables.parametrosCabecera.tipoDocumento,
    tipoProveedor: $variables.parametrosCabecera.tipoProveedor,
    tipoSocietario: $variables.parametrosCabecera.tipoSocietario,
    razonSocial: $variables.razonSocial,
    showBadgeProveedorExtranjero: $variables.showBadgeProveedorExtranjero
});  
      $variables.showBadgeProveedorExtranjero = false;
         $variables.flagPaisSel=false;

if (data!==undefined && data !== null  && data !== "") {
  $variables.flagPaisSel=true;
        if (data.specialHandling !== undefined && data.specialHandling !== null && data.specialHandling !== '032') {

        $variables.showBadgeProveedorExtranjero = true;
      }

      await Actions.callChain(context, {
        chain: 'actSelectTipoSocietarioValue',
      });

      await Actions.callChain(context, {
        chain: 'actSelectTipoDocumentoValue',
      });
} 

    }
  }

  return actSelectPaisValue;
});
