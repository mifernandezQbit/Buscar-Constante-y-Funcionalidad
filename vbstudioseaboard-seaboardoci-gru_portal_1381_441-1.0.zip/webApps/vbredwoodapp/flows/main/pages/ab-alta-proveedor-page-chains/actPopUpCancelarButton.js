define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actPopUpCancelarButton extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {

      const { $page, $flow, $application } = context;
      console.log('>>> MN ENTRA: actPopUpCancelarButton', {
    deposito: $page.variables.parametrosCabecera.deposito,
    idFiscal: $page.variables.parametrosCabecera.idFiscal,
    pais: $page.variables.parametrosCabecera.pais,
    tipoBusqueda: $page.variables.parametrosCabecera.tipoBusqueda,
    tipoDocumento: $page.variables.parametrosCabecera.tipoDocumento,
    tipoProveedor: $page.variables.parametrosCabecera.tipoProveedor,
    tipoSocietario: $page.variables.parametrosCabecera.tipoSocietario,
    razonSocial: $page.variables.razonSocial,
    showBadgeProveedorExtranjero: $page.variables.showBadgeProveedorExtranjero
});
      const guardarLog = await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'VERIFICAR_CANCELA',
          suscriptorId: $application.variables.suscriptor.id,
          numeroAn8: $application.variables.user.numeroAn8,
          proveedor: $application.variables.user.esProveedor,
          pagina: $application.currentPage.id,
          roles: $application.variables.userRoles.userRolesSt,
          usuario: $application.variables.user.ociUser,
          funcionalidad: $page.variables.parFuncionalidad,
          transaccion: $page.variables.parametrosCabecera.pais.data.code+ "-" + $page.variables.parametrosCabecera.idFiscal + "-" + $page.variables.razonSocial,
        },
      });

      const popUpAltaClose = await Actions.callComponentMethod(context, {
        selector: '#popUpAlta',
        method: 'close',
      });
    }
  }

  return actPopUpCancelarButton;
});
