define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actProveedorCreadoListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:boolean,value:boolean}} params.event
     */
    async run(context, { event }) {

      const { $page, $flow, $application, $constants, $variables } = context;
      console.log('>>> MN ENTRA: actProveedorCreadoListener', {
    deposito: $variables.parametrosCabecera.deposito,
    idFiscal: $variables.parametrosCabecera.idFiscal,
    pais: $variables.parametrosCabecera.pais,
    tipoBusqueda: $variables.parametrosCabecera.tipoBusqueda,
    tipoDocumento: $variables.parametrosCabecera.tipoDocumento,
    tipoProveedor: $variables.parametrosCabecera.tipoProveedor,
    tipoSocietario: $variables.parametrosCabecera.tipoSocietario,
    razonSocial: $variables.razonSocial,
    showBadgeProveedorExtranjero: $variables.showBadgeProveedorExtranjero
});
      if (event.value === true) { 
        const responseTipoChat = await Actions.callRest(context, {
          endpoint: 'businessObjects/getall_TipoChat',
          uriParams: {
            q: "suscriptorID='" + $application.variables.suscriptor.id + "' and tipoObjetoChat='PR'",
          },
        });

        const toAbConsultarProveedores = await Actions.navigateToPage(context, {
          page: 'ab-consultar-proveedores',
          params: {
            funcionalidad: 'CONSULTAR_PROVEEDORES',
            paramTipoObjetoChat: 'responseTipoChat.body.items[0].id',
          },
        });
      }
    }
  }

  return actProveedorCreadoListener;
});
