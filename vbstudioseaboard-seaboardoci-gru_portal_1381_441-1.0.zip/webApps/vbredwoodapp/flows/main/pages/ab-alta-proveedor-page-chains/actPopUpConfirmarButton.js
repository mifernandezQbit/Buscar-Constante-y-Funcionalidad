define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actPopUpConfirmarButton extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {

      const { $page, $flow, $application, $variables } = context;
      console.log('>>> MN ENTRA: actPopUpConfirmarButton', {
    deposito: $variables.parametrosCabecera.deposito,
    idFiscal: $variables.parametrosCabecera.idFiscal,
    pais: $variables.parametrosCabecera.pais,
    tipoBusqueda: $variables.parametrosCabecera.tipoBusqueda,
    tipoDocumento: $variables.parametrosCabecera.tipoDocumento,
    tipoProveedor: $variables.parametrosCabecera.tipoProveedor,
    tipoSocietario: $variables.parametrosCabecera.tipoSocietario,
    razonSocial: $variables.razonSocial,
    showBadgeProveedorExtranjero: $variables.showBadgeProveedorExtranjero
});
    const guardarLog = await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'VERIFICAR_CONFIRMA',
          suscriptorId: $application.variables.suscriptor.id,
          numeroAn8: $application.variables.user.numeroAn8,
          proveedor: $application.variables.user.esProveedor,
          pagina: $application.currentPage.id,
          roles: $application.variables.userRoles.userRolesSt,
          usuario: $application.variables.user.ociUser,
          funcionalidad: $variables.parFuncionalidad,
          transaccion: $variables.parametrosCabecera.pais.data.code+ "-" + $variables.parametrosCabecera.idFiscal + "-" + $variables.razonSocial,
        },
      });

      if ($page.variables.motivoAltaProveedor === undefined) {
        $page.variables.motivoAltaProveedor = "";
      }
      const popUpAltaClose = await Actions.callComponentMethod(context, {
        selector: '#popUpAlta',
        method: 'close',
      });

      const callFunction = await this.ocultarDatos(context);

      $page.variables.mostrarFragmentoDatosProveedor = true;
     

    }

    /**
     * @param {Object} context
     */
    async ocultarDatos(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
    
    let elem = document.getElementById("panelDatos");
    elem.hidden = true;


    }
  }

  return actPopUpConfirmarButton;
});
