define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actSelectTipoSocietarioValue extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
    
      const { $page, $flow, $application, $constants, $variables } = context;
      console.log('>>> MN ENTRA: actSelectTipoSocietarioValue', {
    deposito: $variables.parametrosCabecera.deposito,
    idFiscal: $variables.parametrosCabecera.idFiscal,
    pais: $variables.parametrosCabecera.pais,
    tipoBusqueda: $variables.parametrosCabecera.tipoBusqueda,
    tipoDocumento: $variables.parametrosCabecera.tipoDocumento,
    tipoProveedor: $variables.parametrosCabecera.tipoProveedor,
    tipoSocietario: $variables.parametrosCabecera.tipoSocietario,
    razonSocial: $variables.razonSocial,
    showBadgeProveedorExtranjero: $variables.showBadgeProveedorExtranjero
});
       $variables.flagTipoPersonaSel=false;

     if (data!==undefined && data !== null  && data !== "") {
  $variables.flagTipoPersonaSel=true;
     
     // if ($variables.parametrosCabecera.pais.data.specialHandling!==undefined && $variables.parametrosCabecera.pais.data.specialHandling !== null && $variables.parametrosCabecera.pais.data.specialHandling.substring(0,3) !== '032') {
  if ($variables.parametrosCabecera.pais.data.specialHandling!==undefined && $variables.parametrosCabecera.pais.data.specialHandling !== null && $variables.showBadgeProveedorExtranjero) {
        // Une los códigos de país y tipo societario y busca el Cuit y el Special Handling en el listado de Valores de UDC que indica si el proveedor el Cooperante o No cooperante
        const callFunctionBuscarCooperanteNoCooperante = await this.buscarCooperanteNoCooperante(context, { paisSpecialHandlingCode: $variables.parametrosCabecera.pais.data.specialHandling, tipoSocietarioCode: $variables.parametrosCabecera.tipoSocietario.data.code, udcResponseCooperanteNoCoperante: $variables.udcResponseCooperanteNoCooperante });

        $variables.cuitExtranjero = callFunctionBuscarCooperanteNoCooperante;

        if (callFunctionBuscarCooperanteNoCooperante.specialHandling === 'No encontrado') {
          const notificarError = await Actions.callChain(context, {
            chain: 'application:notificar_error',
            params: {
              codigo: 'cuit-no-configurado',
              modoVisualizacion: 'transient',
            },
          });
        }
      }

      await Actions.callChain(context, {
        chain: 'actSelectTipoDocumentoValue',
      });
} 

    }

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.paisSpecialHandlingCode 
     * @param {string} params.tipoSocietarioCode 
     * @param {postQ71PO_BuscarValoresUDCItemResponse[]} params.udcResponseCooperanteNoCoperante 
     */
    async buscarCooperanteNoCooperante(context, { paisSpecialHandlingCode, tipoSocietarioCode, udcResponseCooperanteNoCoperante }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const codigoABuscar = paisSpecialHandlingCode + tipoSocietarioCode;
      const resultado = udcResponseCooperanteNoCoperante.find(item => item.code === codigoABuscar);
      if (resultado){
        return {
          description01: resultado.description01,
          specialHandling: resultado.specialHandling
        };
      } else {
        return {
          description01: null,
          hardCoded: "No encontrado"
        };
      
      }
      }
    }
  

  return actSelectTipoSocietarioValue;
});
