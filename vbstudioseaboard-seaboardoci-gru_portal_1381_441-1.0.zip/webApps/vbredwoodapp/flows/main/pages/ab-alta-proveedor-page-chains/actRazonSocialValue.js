define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actRazonSocialValue extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.previousValue
     * @param {any} params.value
     * @param {string} params.updatedFrom
     */
    async run(context, { event, previousValue, value, updatedFrom }) {

      const { $page, $flow, $application, $constants, $variables } = context;
 
       console.log('>>> MN ENTRA: actRazonSocialValue', {
    deposito: $variables.parametrosCabecera.deposito,
    idFiscal: $variables.parametrosCabecera.idFiscal,
    pais: $variables.parametrosCabecera.pais,
    tipoBusqueda: $variables.parametrosCabecera.tipoBusqueda,
    tipoDocumento: $variables.parametrosCabecera.tipoDocumento,
    tipoProveedor: $variables.parametrosCabecera.tipoProveedor,
    tipoSocietario: $variables.parametrosCabecera.tipoSocietario,
    razonSocial: $variables.razonSocial,
    showBadgeProveedorExtranjero: $variables.showBadgeProveedorExtranjero
});
     if ($page.variables.razonSocial  !== undefined && $page.variables.razonSocial !== null && $page.variables.razonSocial !=="") {
        $page.variables.flagRazonSocialSel=true;
        $variables.razonSocialErrorMostrado = false;
      } else {
           $page.variables.flagRazonSocialSel=false;
      }
    }
  }

  return actRazonSocialValue;
});
