define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actInicioPagina extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {

      const { $page, $flow, $application, $variables } = context;
      console.log('>>> MN ENTRA: actInicioPagina', {
    deposito: $variables.parametrosCabecera.deposito,
    idFiscal: $variables.parametrosCabecera.idFiscal,
    pais: $variables.parametrosCabecera.pais,
    tipoBusqueda: $variables.parametrosCabecera.tipoBusqueda,
    tipoDocumento: $variables.parametrosCabecera.tipoDocumento,
    tipoProveedor: $variables.parametrosCabecera.tipoProveedor,
    tipoSocietario: $variables.parametrosCabecera.tipoSocietario,
    razonSocial: $variables.razonSocial,
    showBadgeProveedorExtranjero: $variables.showBadgeProveedorExtranjero
});
      const verificarPermisosFuncionalidadCREAR_PROVEEDOR = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: $page.variables.parFuncionalidad,
        },
      });

      if (verificarPermisosFuncionalidadCREAR_PROVEEDOR.existe === false) {
        const guardarLog = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'INTENTO_INGRESO_NH',
            funcionalidad: $page.variables.parFuncionalidad,
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
          },
        });

        const notificarError = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            codigo: 'verificar-permisos-proveedor',
            modoVisualizacion: 'transient',
          },
        });

        const toAccesoNoAutorizado = await Actions.navigateToPage(context, {
          page: 'acceso-no-autorizado',
        });
      } else {

        const guardarLog2 = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'INGRESA',
            funcionalidad: $page.variables.parFuncionalidad,
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
          },
        });

        const buscarConstanteCC_TIPO_PROVEEDOR = await Actions.callChain(context, {
          chain: 'application:buscar_constante',
          params: {
            constante: 'CC_TIPO_PROVEEDOR',
          },
        });

        let buscarConstanteUDC_D02 = await Actions.callChain(context, {
          chain: 'application:buscar_constante',
          params: {
            constante: 'UDC_D02',
          },
        });

        if (!buscarConstanteCC_TIPO_PROVEEDOR.existe || !buscarConstanteUDC_D02.existe) {
          const guardarLog3 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              accion: 'INICIO',
              funcionalidad: $application.variables.funcionalidad,
              numeroAn8: $application.variables.user.numeroAn8,
              observaciones: 'Constante CC_TIPO_PROVEEDOR o UDC_D_02 no existen',
              proveedor: $application.variables.user.esProveedor,
              pagina: $application.currentPage.id,
              roles: $application.variables.userRoles.userRolesSt,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
            },
          });

          const notificarError2 = await Actions.callChain(context, {
            chain: 'application:notificar_error',
            params: {
              codigo: 'falta-configuracion',
            },
          });

          const toDefaultPage = await Actions.navigateToPage(context, {
            page: 'fnd-ver-home-de-usuario',
          });

        } else {
          $page.variables.consUDC_D02 = buscarConstanteUDC_D02.valor;

          const buscarConstanteCC_OFAC = await Actions.callChain(context, {
            chain: 'application:buscar_constante',
            params: {
              constante: 'CC_OFAC',
            },
          });

          const cuitDuplicado = await Actions.callChain(context, {
            chain: 'application:buscar_constante',
            params: {
              constante: 'CUIT_DUPLICADO_PERMITIDO',
            },
          });
          // si no está configurado asumimos x defecto que el portal lo permite y entonces rige lo que está definido en jde
          if (cuitDuplicado.existe) {
            $page.variables.cuitDuplicadoPermitido = cuitDuplicado.valor !== undefined && cuitDuplicado.valor !== "" ? cuitDuplicado.valor : '1';
          }

          const buscarConstanteWF_CC_MCU_AUTORIZANTE = await Actions.callChain(context, {
            chain: 'application:buscar_constante',
            params: {
              constante: 'WF_CC_MCU_AUTORIZANTE',
            },
          });

          const responseBuscarValoresUDC = await Actions.callRest(context, {
            endpoint: 'GatewayPortal/postQ71PO_BuscarValoresUDC',
            body: {
              token: $application.variables.token,
              'P0004A_Version': '',
              udcToSearch: [
                {
                  productCode: '00',
                  userDefinedCode: 'CN',
                  description1: '',
                  description2: '',
                  specialHandling: '',
                },
                {
                  productCode: '01',
                  userDefinedCode: buscarConstanteCC_OFAC.valor,
                  description1: '',
                  description2: '',
                  specialHandling: '',
                },
                {
                  productCode: '01',
                  userDefinedCode: buscarConstanteCC_TIPO_PROVEEDOR.valor,
                  description1: '',
                  description2: '',
                  specialHandling: '',
                },
                {
                  productCode: '01',
                  userDefinedCode: 'ST',
                  description1: '',
                  description2: '*' + buscarConstanteUDC_D02.valor + '*',
                  specialHandling: '',
                },
                {
                  productCode: '76A',
                  userDefinedCode: 'A0',
                  description1: '',
                  description2: '',
                  specialHandling: '',
                },
                {
                  productCode: 'H00',
                  userDefinedCode: 'TA',
                  description1: '',
                  description2: '',
                  specialHandling: '',
                },

                // Cooperante/No Cooperante
                {
                  productCode: 'Q71',
                  userDefinedCode: 'ZP',
                  description1: '',
                  description2: '',
                  specialHandling: '',
                },
              ],
            },
          });

          await Actions.callChain(context, {
            chain: 'application:verificar_respuesta_jdeError',
            params: {
              error: !responseBuscarValoresUDC.ok,
              funcion: 'buscarValoresUDC',
              funcionalidad: $page.variables.parFuncionalidad,
              tokenExpirado: responseBuscarValoresUDC.body.tokenExpirado,
              status: responseBuscarValoresUDC.status,
            },
          });

          $page.variables.pais.data = responseBuscarValoresUDC.body.rowset[0].codesList;
          $page.variables.tipoDocumento.data = responseBuscarValoresUDC.body.rowset[4].codesList;
          $page.variables.controlOFAC.data = responseBuscarValoresUDC.body.rowset[1].codesList;
          $page.variables.tipoProveedor.data = responseBuscarValoresUDC.body.rowset[2].codesList;
          $page.variables.tipoBusqueda.data = responseBuscarValoresUDC.body.rowset[3].codesList;
          $page.variables.tipoSocietario.data = responseBuscarValoresUDC.body.rowset[5].codesList;
          $page.variables.udcResponseCooperanteNoCooperante = responseBuscarValoresUDC.body.rowset[6].codesList;

          // Autocompleta el valor de OFAC

          const buscarConstanteLD_PROV_LOCAL_OFAC = await Actions.callChain(context, {
            chain: 'application:buscar_constante',
            params: {
              constante: 'LD_PROV_LOCAL_OFAC',
            },
          });

          const callFunctionCreateOFACValue = await this.createOFACvalue(context, { ofacData: $variables.controlOFAC.data, code: buscarConstanteLD_PROV_LOCAL_OFAC.valor });
          $page.variables.controlOFACValue = {
            data: {
              code: callFunctionCreateOFACValue.code,
              description01: callFunctionCreateOFACValue.description01,
              description02: callFunctionCreateOFACValue.description02,
              hardCoded: callFunctionCreateOFACValue.hardCoded,
              specialHandling: callFunctionCreateOFACValue.specialHandling,
            },
            metadata: {
              key: buscarConstanteLD_PROV_LOCAL_OFAC.valor,
            },
            key: buscarConstanteLD_PROV_LOCAL_OFAC.valor,
          };
        }
      }
    }

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object[]} params.ofacData 
     * @param {string} params.code 
     * @return {object} 
     */
    async createOFACvalue(context, { ofacData, code }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const item = ofacData.find(element => element.code === code);
      return item;
    }
  }

  return actInicioPagina;
});