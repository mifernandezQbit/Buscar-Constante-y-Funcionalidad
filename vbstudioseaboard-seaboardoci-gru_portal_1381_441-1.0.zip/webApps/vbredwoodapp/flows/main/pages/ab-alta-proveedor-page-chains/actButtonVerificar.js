define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actButtonVerificar extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {

      const { $page, $flow, $application, $variables } = context;
      console.log('>>> MN ENTRA: actButtonVerificar', {
    deposito: $variables.parametrosCabecera.deposito,
    idFiscal: $variables.parametrosCabecera.idFiscal,
    pais: $variables.parametrosCabecera.pais,
    tipoBusqueda: $variables.parametrosCabecera.tipoBusqueda,
    tipoDocumento: $variables.parametrosCabecera.tipoDocumento,
    tipoProveedor: $variables.parametrosCabecera.tipoProveedor,
    tipoSocietario: $variables.parametrosCabecera.tipoSocietario,
    razonSocial: $variables.razonSocial,
    showBadgeProveedorExtranjero: $variables.showBadgeProveedorExtranjero
});
      const guardarLog = await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'VERIFICAR',
          suscriptorId: $application.variables.suscriptor.id,
          numeroAn8: $application.variables.user.numeroAn8,
          proveedor: $application.variables.user.esProveedor,
          pagina: $application.currentPage.id,
          roles: $application.variables.userRoles.userRolesSt,
          usuario: $application.variables.user.ociUser,
          funcionalidad: $variables.parFuncionalidad,
          transaccion: $variables.parametrosCabecera.pais.data.code+ "-" + $variables.parametrosCabecera.idFiscal + "-" + $variables.razonSocial,
        },
      });
    
// valida seguridad JDE
      const seguridadOK = await Actions.callChain(context, {
        chain: 'application:validar_seguridad',
        params: {
          accionJDE: 'A',
          funcionalidad: $variables.parFuncionalidad,
          valor: $variables.parametrosCabecera.deposito,
          nroProveedor: '0',
        },
      });

// si no hubo error de seguridad, pide confirmación
if (seguridadOK) {
      const popUpAltaOpen = await Actions.callComponentMethod(context, {
        selector: '#popUpAlta',
        method: 'open',
      });
      }
      else {
        $variables.parametrosCabecera.deposito = "";
      }
    }
  }

  return actButtonVerificar;
});
