define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actSelectTipoDocumentoValue extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {

      const { $page, $flow, $application, $variables } = context;
      console.log('>>> MN ENTRA: actSelectTipoDocumentoValue', {
    deposito: $variables.parametrosCabecera.deposito,
    idFiscal: $variables.parametrosCabecera.idFiscal,
    pais: $variables.parametrosCabecera.pais,
    tipoBusqueda: $variables.parametrosCabecera.tipoBusqueda,
    tipoDocumento: $variables.parametrosCabecera.tipoDocumento,
    tipoProveedor: $variables.parametrosCabecera.tipoProveedor,
    tipoSocietario: $variables.parametrosCabecera.tipoSocietario,
    razonSocial: $variables.razonSocial,
    showBadgeProveedorExtranjero: $variables.showBadgeProveedorExtranjero
});
   $variables.flagTipoDocumentoSel=false;
  $page.variables.parametrosCabecera.idFiscal = undefined;

if (data!==undefined && data !== null && data !== "") {
  $variables.flagTipoDocumentoSel=true;

          // Si el tipo de documento seleccionado es CUIT del exterior y no se seleccionó previamente un país, se dispara una notificación
         if ($page.variables.parametrosCabecera.tipoDocumento.data.specialHandling.substring(0,1) === '1') {
          if ($page.variables.parametrosCabecera.pais.data){
            // Si el proveedor es extranjero y el tipo de documento seleccionado es CUIT, se autocompleta el valor de ID fiscal determinado para el país seleccionado
          //  if ($page.variables.parametrosCabecera.pais.data.specialHandling.substring(0,3) !== '032') {
              if ($variables.showBadgeProveedorExtranjero) {
               $page.variables.parametrosCabecera.idFiscal = $variables.cuitExtranjero.description01;
            }
          } else {
            
            const notificarError = await Actions.callChain(context, {
              chain: 'application:notificar_error',
              params: {
                codigo: 'seleccionar-pais',
              },
            });
          }
           if ($variables.cuitExtranjero.specialHandling === 'NC' || $variables.cuitExtranjero.specialHandling === 'nc' || $variables.cuitExtranjero.specialHandling === 'Nc' || $variables.cuitExtranjero.specialHandling === 'nC') {
        $variables.badge = 'No Cooperante';
        } else if ($variables.cuitExtranjero.specialHandling === 'CO' || $variables.cuitExtranjero.specialHandling === 'co' || $variables.cuitExtranjero.specialHandling === 'Co' || $variables.cuitExtranjero.specialHandling === 'cO'){
        $variables.badge = 'Cooperante';  
        }
         }

} 

    }
  }

  return actSelectTipoDocumentoValue;
});