define([
        'vb/action/actionChain',
        'vb/action/actions',
        'vb/action/actionUtils',
    ], (
        ActionChain,
        Actions,
        ActionUtils) => {
    'use strict';

    class actIdFiscalValue extends ActionChain {

        /**
         * @param {Object} context
         * @param {Object} params
         * @param {any} params.value
         */
        async run(context, {
            value
        }) {
            const { $page, $flow, $application, $variables } = context;

            if (value !== undefined && value !== null && value !== "") {
                $variables.flagNroDocumentoSel = true;
            } else {
                $variables.flagNroDocumentoSel = false;
            }
            if ($page.variables.parametrosCabecera.idFiscal !== undefined) {

                await Actions.resetVariables(context, {
                    variables: [
                        '$page.variables.arcaError',
                    ],
                });

                await Actions.resetVariables(context, {
                    variables: [
                        '$page.variables.arcaContribuyenteNoActivo',
                    ],
                });

                await Actions.resetVariables(context, {
                    variables: [
                        '$page.variables.razonSocial',
                    ],
                });

                await Actions.resetVariables(context, {
                    variables: [
                        '$page.variables.correoElectronico',
                    ],
                });

                await Actions.resetVariables(context, {
                    variables: [
                        '$page.variables.parametrosCabecera.deposito',
                    ],
                });

                $page.variables.cuitDuplicadoOk = false;
         
                $variables.arca = false;
                if ($page.variables.parametrosCabecera.tipoDocumento.data.specialHandling.substring(0, 1) === '1' && !$variables.showBadgeProveedorExtranjero) {
                    $variables.arca = true;
                    const regex = new RegExp('^[0-9]{11}$');

                    if (regex.test($page.variables.parametrosCabecera.idFiscal) === false) {

                        const notificarError = await Actions.callChain(context, {
                            chain: 'application:notificar_error',
                            params: {
                                codigo: 'cuit-invalido',
                                modoVisualizacion: 'transient',
                            },
                        });

                        $page.variables.parametrosCabecera.idFiscal = undefined;
                    } else {
                        const validacionCUIT = await Actions.callRest(context, {
                            endpoint: 'GatewayPortal/postQ71PO_ValidarIDFiscal',
                            body: {
                                token: $application.variables.token,
                                "nroProveedor": "",
                                "idFiscal": $page.variables.parametrosCabecera.idFiscal,
                                "tipoIDFiscal": $page.variables.tipoDocumento.idAttribute,
                                "usarWS": false,
                                "compania": $application.variables.selectedCompany.company,
                            },
                        });
                        await Actions.callChain(context, {
                            chain: 'application:verificar_respuesta_jdeError',
                            params: {
                                error: !validacionCUIT.ok,
                                funcion: 'ValidarIDFiscal',
                                tokenExpirado: validacionCUIT.body.tokenExpirado,
                                funcionalidad: $application.variables.funcionalidad,
                                status: validacionCUIT.status,
                            },
                        });

                        if (validacionCUIT.ok && !validacionCUIT.body.errorJde && validacionCUIT.body.rowset.length >= 1) {
                            if ($page.variables.cuitDuplicadoPermitido === "1") {
                                await Actions.callChain(context, {
                                    chain: 'application:notificar_error',
                                    params: {
                                        codigo: 'aviso-proveedor-duplicado',
                                    },
                                });
                                $page.variables.cuitDuplicadoOk = true;
                       
                            } else {
                                await Actions.callChain(context, {
                                    chain: 'application:notificar_error',
                                    params: {
                                        codigo: 'error-proveedor-duplicado',
                                    },
                                });

                            }

                        } else {
                            $page.variables.cuitDuplicadoOk = true;
                        }

                        const buscarConstanteARCA_CONSTANCIA_INSCRIPCION = await Actions.callChain(context, {
                            chain: 'application:buscar_constante',
                            params: {
                                constante: 'ARCA_CONSTANCIA_INSCRIPCION',
                            },
                        });

                        if (buscarConstanteARCA_CONSTANCIA_INSCRIPCION.existe === true && buscarConstanteARCA_CONSTANCIA_INSCRIPCION.valor === '1') {

                            $variables.constARCA_CONSTANCIA_INSCRIPCION = buscarConstanteARCA_CONSTANCIA_INSCRIPCION.valor;

                            const responsepostQ71PO_GetPersonaV2 = await Actions.callRest(context, {
                                endpoint: 'GatewayPortal2/postQ71PO_GetPersonaV2',
                                body: {
                                    token: $application.variables.token,
                                    CompanyKey: $application.variables.selectedCompany.company,
                                    cuit: $application.variables.selectedCompany.cuit,
                                    idPersona: $page.variables.parametrosCabecera.idFiscal,
                                },
                            });

                            await Actions.callChain(context, {
                                chain: 'application:verificar_respuesta_jdeError',
                                params: {
                                    error: !responsepostQ71PO_GetPersonaV2.ok,
                                    funcion: 'GetPersonaV2',
                                    funcionalidad: 'CREAR_PROVEEDOR',
                                    tokenExpirado: responsepostQ71PO_GetPersonaV2.body.tokenExpirado,
                                    transaccion: $page.variables.parametrosCabecera.idFiscal,
                                    status: responsepostQ71PO_GetPersonaV2.status,
                                },
                            });

                            if (responsepostQ71PO_GetPersonaV2.body.errorCodeArca == 0) {
                                if (responsepostQ71PO_GetPersonaV2.body.data.datosGenerales !== undefined) {
                                    if (responsepostQ71PO_GetPersonaV2.body.data.datosGenerales.domicilioFiscal.direccion !== undefined) {
                                        $variables.domicilioFiscal.direccionFiscal = responsepostQ71PO_GetPersonaV2.body.data.datosGenerales.domicilioFiscal.direccion;
                                    }
                                    if (responsepostQ71PO_GetPersonaV2.body.data.datosGenerales.domicilioFiscal.codPostal !== undefined) {
                                        $variables.domicilioFiscal.codigoPostal = responsepostQ71PO_GetPersonaV2.body.data.datosGenerales.domicilioFiscal.codPostal;
                                    }
                                    if (responsepostQ71PO_GetPersonaV2.body.data.datosGenerales.razonSocial !== undefined) {
                                        $variables.razonSocial = (responsepostQ71PO_GetPersonaV2.body.data.datosGenerales.razonSocial).slice(0, 40);
                                    } else {
                                        if (responsepostQ71PO_GetPersonaV2.body.data.datosGenerales.apellido !== undefined) {
                                            $variables.razonSocial = (responsepostQ71PO_GetPersonaV2.body.data.datosGenerales.apellido + (responsepostQ71PO_GetPersonaV2.body.data.datosGenerales.nombre ? " " + responsepostQ71PO_GetPersonaV2.body.data.datosGenerales.nombre : '')).slice(0, 40);
                                        }
                                    };
                                    if (responsepostQ71PO_GetPersonaV2.body.data.datosGenerales.domicilioFiscal.localidad !== undefined) {
                                        $variables.domicilioFiscal.ciudad = responsepostQ71PO_GetPersonaV2.body.data.datosGenerales.domicilioFiscal.localidad.substring(0,25);
                                    }
                                    if (responsepostQ71PO_GetPersonaV2.body.data.datosGenerales.domicilioFiscal.descripcionProvincia !== undefined) {
                                        $variables.domicilioFiscal.descripcionProvincia = responsepostQ71PO_GetPersonaV2.body.data.datosGenerales.domicilioFiscal.descripcionProvincia;
                                    }
                                    if (responsepostQ71PO_GetPersonaV2.body.data.datosGenerales.domicilioFiscal.idProvincia !== undefined) {
                                        $variables.domicilioFiscal.idProvincia = responsepostQ71PO_GetPersonaV2.body.data.datosGenerales.domicilioFiscal.idProvincia;
                                    }
                                    if (responsepostQ71PO_GetPersonaV2.body.data.datosGenerales.estadoClave !== 'ACTIVO') {
                                        $variables.arcaContribuyenteNoActivo = true;
                                    }
                                }
                            } else {

                                $variables.arcaError.code = responsepostQ71PO_GetPersonaV2.body.errorCodeArca;

                                if (responsepostQ71PO_GetPersonaV2.body.data.errorConstancia !== undefined && responsepostQ71PO_GetPersonaV2.body.data.errorConstancia.length !== 0) {
                                    if (responsepostQ71PO_GetPersonaV2.body.data.errorConstancia.apellido !== undefined) {
                                        $variables.arcaError.errorConstancia.apellido = responsepostQ71PO_GetPersonaV2.body.data.errorConstancia.apellido;
                                    }
                                    if (responsepostQ71PO_GetPersonaV2.body.data.errorConstancia.error !== undefined) {
                                        $variables.arcaError.errorConstancia.error = responsepostQ71PO_GetPersonaV2.body.data.errorConstancia.error;
                                    }
                                    if (responsepostQ71PO_GetPersonaV2.body.data.errorConstancia.idPersona !== undefined) {
                                        $variables.arcaError.errorConstancia.idPersona = responsepostQ71PO_GetPersonaV2.body.data.errorConstancia.idPersona;
                                    }
                                    if (responsepostQ71PO_GetPersonaV2.body.data.errorConstancia.nombre !== undefined) {
                                        $variables.arcaError.errorConstancia.nombre = responsepostQ71PO_GetPersonaV2.body.data.errorConstancia.nombre;
                                    }
                                }
                                $variables.arca = false;

                                if ($variables.arcaError.errorConstancia.apellido !== undefined || $variables.arcaError.errorConstancia.error !== undefined || $variables.arcaError.errorConstancia.idPersona !== undefined || $variables.arcaError.errorConstancia.nombre !== undefined) {
                                    $variables.errorArcaDescripcion = "";
                                    if ($variables.arcaError.errorConstancia.apellido !== undefined) {
                                        $variables.errorArcaDescripcion = $variables.errorArcaDescripcion + "Apellido: " + $variables.arcaError.errorConstancia.apellido;
                                    }
                                    if ($variables.arcaError.errorConstancia.nombre !== undefined) {
                                        $variables.errorArcaDescripcion = $variables.errorArcaDescripcion + " - Nombre: " + $variables.arcaError.errorConstancia.nombre;
                                    }
                                    if ($variables.arcaError.errorConstancia.error !== undefined) {
                                        $variables.errorArcaDescripcion = $variables.errorArcaDescripcion + " - Error: " + $variables.arcaError.errorConstancia.error;
                                    }
                                    if ($variables.arcaError.errorConstancia.idPersona !== undefined) {
                                        $variables.errorArcaDescripcion = $variables.errorArcaDescripcion + " - Id Persona: " + $variables.arcaError.errorConstancia.idPersona;
                                    }

                                    const notificarError2 = await Actions.callChain(context, {
                                        chain: 'application:notificar_error',
                                        params: {
                                            titulo: 'Error en ARCA',
                                            descripcion: $variables.errorArcaDescripcion,
                                            tipoNotificacion: 'error',
                                            modoVisualizacion: 'persist',
                                        },
                                    });
                                }
                                if (responsepostQ71PO_GetPersonaV2.body.data.errorMonotributo.length !== undefined && responsepostQ71PO_GetPersonaV2.body.data.errorMonotributo.length !== '0') {
                                    if (responsepostQ71PO_GetPersonaV2.body.data.errorMonotributo.error !== undefined) {
                                        $variables.arcaError.errorMonotributo.error = responsepostQ71PO_GetPersonaV2.body.data.errorMonotributo.error;
                                    }
                                    if (responsepostQ71PO_GetPersonaV2.body.data.errorMonotributo.mensaje !== undefined) {
                                        $variables.arcaError.errorMonotributo.mensaje = responsepostQ71PO_GetPersonaV2.body.data.errorMonotributo.mensaje;
                                    }
                                }
                                if (responsepostQ71PO_GetPersonaV2.body.data.errorRegimenGeneral !== undefined && responsepostQ71PO_GetPersonaV2.body.data.errorRegimenGeneral.length !== '0') {
                                    if (responsepostQ71PO_GetPersonaV2.body.data.errorRegimenGeneral.error !== undefined) {
                                        $variables.arcaError.errorRegimenGeneral.error = responsepostQ71PO_GetPersonaV2.body.data.errorRegimenGeneral.error;
                                    }
                                    if (responsepostQ71PO_GetPersonaV2.body.data.errorRegimenGeneral.mensaje !== undefined) {
                                        $variables.arcaError.errorRegimenGeneral.mensaje = responsepostQ71PO_GetPersonaV2.body.data.errorRegimenGeneral.mensaje;
                                    }
                                }
                            }
                            $variables.arca = false;

                        } else {
                            $variables.arca = false;

                            //MIF $variables.cuitDuplicadoOk = true;
                   
                        }

                    }
                    $variables.arca = false;

                } else {
                    $page.variables.cuitDuplicadoOk = true;
         
                    $variables.arca = false;

                    // VAlidar que solo se hayan ingresado números y no caracteres especiales ni letras
                    if ($page.variables.parametrosCabecera.idFiscal !== undefined && $page.variables.parametrosCabecera.idFiscal !== null && $page.variables.parametrosCabecera.idFiscal !== "") {
                        const regex = new RegExp('^([0-9]{1,20})$');

                        if (regex.test($page.variables.parametrosCabecera.idFiscal) === false) {
                            const notificarError = await Actions.callChain(context, {
                                chain: 'application:notificar_error',
                                params: {
                                    codigo: 'id-fiscal-invalido',
                                },
                            });

                            $page.variables.parametrosCabecera.idFiscal = undefined;
                            $page.variables.cuitDuplicadoOk = false;
                       
                        }
                    }
                }
            }
        }
    }

    return actIdFiscalValue;
});