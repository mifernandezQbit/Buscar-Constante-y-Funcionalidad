define([
        'vb/action/actionChain',
        'vb/action/actions',
        'vb/action/actionUtils',
    ], (
        ActionChain,
        Actions,
        ActionUtils) => {
    'use strict';

    class actEnableVerificarButton extends ActionChain {

        /**
         * @param {Object} context
         * @param {Object} params
         * @param {any} params.key
         * @param {any} params.data
         * @param {any} params.metadata
         */
        async run(context, {
            key,
            data,
            metadata
        }) {

            const { $page, $flow, $application, $variables } = context;
            console.log('>>> MN ENTRA: actEnableVerificarButton', {
    deposito: $variables.parametrosCabecera.deposito,
    idFiscal: $variables.parametrosCabecera.idFiscal,
    pais: $variables.parametrosCabecera.pais,
    tipoBusqueda: $variables.parametrosCabecera.tipoBusqueda,
    tipoDocumento: $variables.parametrosCabecera.tipoDocumento,
    tipoProveedor: $variables.parametrosCabecera.tipoProveedor,
    tipoSocietario: $variables.parametrosCabecera.tipoSocietario,
    razonSocial: $variables.razonSocial,
    showBadgeProveedorExtranjero: $variables.showBadgeProveedorExtranjero
});
            // verificar si está ingreado el centro de costos
            if ($variables.parametrosCabecera.deposito !== undefined && $variables.parametrosCabecera.deposito !== null && $variables.parametrosCabecera.deposito !== "") {
                $page.variables.flagCCSel = true;
            } else {
                $page.variables.flagCCSel = false;
            }
            // Verifica que todos los campos requeridos se encuentren completos
            const callFunctionVerificarCamposRequeridos = await this.verificarCamposRequeridos(context, {
                parametrosCabecera: $variables.parametrosCabecera
            });

            console.log('>>> MN VALIDACION CAMPOS REQUERIDOS', {
            todosCompletos: callFunctionVerificarCamposRequeridos,
            correoElectronico: $variables.correoElectronico,
            correoOk: $variables.correoOk,
            showBadgeProveedorExtranjero: $variables.showBadgeProveedorExtranjero,
            razonSocial: $variables.razonSocial,
            disableVerificarButton: $variables.disableVerificarButton,
            parametrosCabecera: $variables.parametrosCabecera
            });
	

            if ($variables.arcaContribuyenteNoActivo === false && $variables.arcaError.code !== undefined && $variables.arcaError.code !== '0') {
                $variables.disableVerificarButton = true;
            } else {

                console.log('>>> MN VALIDACION LOCAL', {
                        correoElectronico: $variables.correoElectronico,
                        correoOk: $variables.correoOk,
                        condicionCorreo: (
                            $variables.correoElectronico !== undefined &&
                            $variables.correoOk
                        )
                });
                if (callFunctionVerificarCamposRequeridos === true) {
        
                    if ($page.variables.controlOFACValue) {
                        //if ($page.variables.parametrosCabecera.pais.data.specialHandling.substring(0, 3) !== '032') {
                      /*  if ($variables.showBadgeProveedorExtranjero) {
                          if ($page.variables.razonSocial) {
                              $page.variables.disableVerificarButton = false;
                          } else {
                              const notificarError = await Actions.callChain(context, {
                                  chain: 'application:notificar_error',
                                  params: {
                                      codigo: 'razon-social-invalida',
                                      modoVisualizacion: 'persist',
                                  },
                              });
                          }*/

                          if ($variables.showBadgeProveedorExtranjero) {

                            if ($page.variables.razonSocial) {

                                $page.variables.disableVerificarButton = false;

                                // La razón social está completa nuevamente,
                                // permitimos volver a mostrar el mensaje en una futura validación
                                $variables.razonSocialErrorMostrado = false;

                            } else {

                                if (!$variables.razonSocialErrorMostrado) {

                                    $variables.razonSocialErrorMostrado = true;

                                    const notificarError = await Actions.callChain(context, {
                                        chain: 'application:notificar_error',
                                        params: {
                                            codigo: 'razon-social-invalida',
                                            modoVisualizacion: 'persist',
                                        },
                                    });
                                }
                            }
                        // no es obligatorio el email para los extranjeros, pero si está undefined es válido
                        if ($variables.correoElectronico === undefined ) {
                            $variables.flagEmailSel=true;}
                        } else {
                            $variables.disableVerificarButton = true;
                  
                            if ($variables.correoElectronico !== undefined && $variables.correoOk) {
                                $variables.disableVerificarButton = false;
                            }

                           // if ($variables.correoElectronico !== undefined && $variables.correoElectronico !== null && $variables.correoElectronico !== '' && $variables.correoOk) {
                            //  $variables.disableVerificarButton = false;
                         // }
                        }
                    }
                    // controla centro de costos que no tenga error y si no lo tiene
                    // verifica que esté configurado el código de categoría para WF

                    if ($page.variables.errorCentroCostos) {
                        $variables.disableVerificarButton = true;

                    } else {

                        const verificarUnNegocio = await Actions.callChain(context, {
                            chain: 'application:actBuscarCodCatUnidadNegocio',
                            params: {
                                unidadNegocio: $variables.parametrosCabecera.deposito,
                                wfFacturas: false,
                            },
                        });

                        // guardo el centro de csotos validado, si no está condigurado se blanquea
                        $variables.parametrosCabecera.deposito = verificarUnNegocio.unidadNegocio;
                        if ($variables.parametrosCabecera.deposito === "") {
                            $variables.disableVerificarButton = true;
                        } else {

                            $variables.disableVerificarButton = false;
                        }
                    }
                    if ($variables.arcaContribuyenteNoActivo === true) {
                        $variables.disableVerificarButton = true;
                        const notificarErrorArcaNoActivo = await Actions.callChain(context, {
                            chain: 'application:notificar_error',
                            params: {
                                codigo: 'arca-no-activo',
                                modoVisualizacion: 'persist',
                            },
                        });
                    }
                    if ($variables.arcaError.code !== undefined && $variables.arcaError.code !== '0') {

                        $variables.disableVerificarButton = true;
                    }
                }
            }

        }

        /**
         * @param {Object} context
         * @param {Object} params
         * @param {object} params.parametrosCabecera
         * @return {boolean}
         */
        async verificarCamposRequeridos(context, {
            parametrosCabecera
        }) {
            const { $page, $flow, $application, $constants, $variables } = context;
            return Object.entries(parametrosCabecera).every(([key, value]) => {
			
                // Si la clave es 'correoElectronico', no se valida
                if (key === 'correoElectronico') {
                    return true; // El correo puede ser cualquier valor
                }

                // Si el valor es un objeto, comprobamos que no sea un objeto vacío
                if (typeof value === 'object' && value !== null) {
                    return Object.keys(value).length > 0; // Aseguramos que el objeto no esté vacío
                }

                // Validamos que el valor no sea '', null o undefined
                return value !== undefined && value !== null && value !== '';
            });

        }
    }

    return actEnableVerificarButton;
});
