define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actEmailInputValue extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {

      const { $page, $flow, $application, $variables } = context;
      console.log('>>> MN ENTRA: actEmailInputValue', {
    deposito: $variables.parametrosCabecera.deposito,
    idFiscal: $variables.parametrosCabecera.idFiscal,
    pais: $variables.parametrosCabecera.pais,
    tipoBusqueda: $variables.parametrosCabecera.tipoBusqueda,
    tipoDocumento: $variables.parametrosCabecera.tipoDocumento,
    tipoProveedor: $variables.parametrosCabecera.tipoProveedor,
    tipoSocietario: $variables.parametrosCabecera.tipoSocietario,
    razonSocial: $variables.razonSocial,
    showBadgeProveedorExtranjero: $variables.showBadgeProveedorExtranjero
});
//if ((value!== undefined && value!==null && value!=="") || $variables.parametrosCabecera.pais.data.specialHandling.substring(0,3) !== '032') {
  if ((value!== undefined && value!==null && value!=="") || $variables.showBadgeProveedorExtranjero) {
$page.variables.flagEmailSel=true;
} else {
$page.variables.flagEmailSel=false;
}

     // if (value !== undefined || $variables.parametrosCabecera.pais.data.specialHandling.substring(0,3) === '032') {
      if (value !== undefined || !$variables.showBadgeProveedorExtranjero) {

const regex = new RegExp('^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$');

    if (regex.test(value)) {
          $page.variables.parametrosCabecera.correoElectronico = value;
          $page.variables.correoOk=true;
} else {
          const notificarError = await Actions.callChain(context, {
            chain: 'application:notificar_error',
            params: {
              codigo: 'correo-invalido',
            },
          });
          $page.variables.correoOk=false;
}
      }
      else {
        $page.variables.correoOk=true;
      }




    }
  }

  return actEmailInputValue;
});
