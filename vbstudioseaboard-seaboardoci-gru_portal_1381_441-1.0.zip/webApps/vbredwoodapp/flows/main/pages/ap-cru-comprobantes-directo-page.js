define([], () => {
  'use strict';

  class PageModule {
    // Método para convertir la fecha de "YYYY-MM-DD" a "DD/MM/YYYY"
    formatDateDDMMYYYY(dateString) {
      if (dateString) {
        let dateArray = dateString.split("-");
        if (dateArray.length === 3) {
          // Formatear a "DD/MM/YYYY"
          return dateArray[2] + '/' + dateArray[1] + '/' + dateArray[0];
        }
      }
      return dateString; // Retorna el valor original si no hay conversión
    }

    // Método para convertir la fecha por ejemplo de "YYYY-MM-DD" a "DD/MM/YYYY"
    formatDateString(dateString, simpleDateFormat) {
      if (!dateString || !simpleDateFormat) return dateString; // Validación inicial

      // Detectar el delimitador y dividir la fecha
      const delimiter = dateString.includes('-') ? '-' : '/';
      const dateArray = dateString.split(delimiter);

      // Asegurarse de que la fecha tenga tres partes
      if (dateArray.length !== 3) return dateString;

      // Identificar año, mes y día de forma genérica
      const [year, month, day] = delimiter === '-' ? dateArray : dateArray.reverse();

      // Manejar diferentes formatos
      switch (simpleDateFormat) {
        case 'dd/MM/yy':
          return `${day}/${month}/${year.slice(-2)}`;
        case 'dd/MM/yyyy':
          return `${day}/${month}/${year}`;
        case 'MM-dd-yyyy':
          return `${month}-${day}-${year}`;
        case 'yyyy/MM/dd':
          return `${year}/${month}/${day}`;
        case 'yyyy-MM-dd':
          return `${year}-${month}-${day}`;
        default:
          return dateString; // Retorna el valor original si el formato no está soportado
      }
    }

/*
    //funciones para comparar dos objetos complejos. ej. requestQ71PO_ActualizarVoucherGridData / requestQ71PO_AltaVoucherSinMatching
    // Función auxiliar para comparar valores primitivos de forma segura
    deepEqualPrimitive(val1, val2) {
      return val1 === val2 || (Number.isNaN(val1) && Number.isNaN(val2)); // Maneja NaN correctamente
    }

    deepEqualIterative(obj1, obj2) {
      if (obj1 === obj2) return true;
      if (typeof obj1 !== 'object' || typeof obj2 !== 'object' || obj1 === null || obj2 === null) return false;

      let stack = [{ obj1, obj2 }];

      while (stack.length > 0) {
        let { obj1, obj2 } = stack.pop();

        // Comparar fechas
        if (obj1 instanceof Date && obj2 instanceof Date) {
          if (obj1.getTime() !== obj2.getTime()) return false;
          continue;
        }

        // Comparar Set
        if (obj1 instanceof Set && obj2 instanceof Set) {
          if (obj1.size !== obj2.size) return false;
          let arr1 = Array.from(obj1);
          let arr2 = Array.from(obj2);
          if (arr1.some(item => !arr2.includes(item))) return false;
          continue;
        }

        // Comparar Map
        if (obj1 instanceof Map && obj2 instanceof Map) {
          if (obj1.size !== obj2.size) return false;
          let entries1 = Array.from(obj1.entries());
          let entries2 = Array.from(obj2.entries());
          for (let i = 0; i < entries1.length; i++) {
            let [key1, value1] = entries1[i];
            let matchingEntry = entries2.find(([key2]) => deepEqualPrimitive(key1, key2));
            if (!matchingEntry) return false;
            let [, value2] = matchingEntry;
            stack.push({ obj1: value1, obj2: value2 });
          }
          continue;
        }

        let keys1 = Object.keys(obj1);
        let keys2 = Object.keys(obj2);

        if (keys1.length !== keys2.length) return false;

        for (let key of keys1) {
          if (!keys2.includes(key)) return false;

          let val1 = obj1[key];
          let val2 = obj2[key];

          if (typeof val1 === 'object' && typeof val2 === 'object' && val1 !== null && val2 !== null) {
            stack.push({ obj1: val1, obj2: val2 });
          } else if (!deepEqualPrimitive(val1, val2)) {
            return false;
          }
        }
      }

      return true;
    }
*/

    formatNumberToStringAuto(inputValue, outputDecimalFormat = ',') {
      if (typeof inputValue !== 'string') {
        inputValue = String(inputValue);
      }

      let inputDecimalFormat = '.';
      let inputGroupFormat = '';

      const hasComma = inputValue.includes(',');
      const hasDot = inputValue.includes('.');

      if (hasComma && hasDot) {
        // Determinar cuál es el decimal (el que esté más a la derecha)
        if (inputValue.lastIndexOf(',') > inputValue.lastIndexOf('.')) {
          inputDecimalFormat = ',';
          inputGroupFormat = '.';
        } else {
          inputDecimalFormat = '.';
          inputGroupFormat = ',';
        }
      } else if (hasComma) {
        const commaPos = inputValue.lastIndexOf(',');
        if (inputValue.length - commaPos <= 3) {
          inputDecimalFormat = ',';
        } else {
          inputGroupFormat = ',';
        }
      } else if (hasDot) {
        const dotPos = inputValue.lastIndexOf('.');
        if (inputValue.length - dotPos <= 3) {
          inputDecimalFormat = '.';
        } else {
          inputGroupFormat = '.';
        }
      }

      // Eliminar separadores de miles
      let normalized = inputValue;
      if (inputGroupFormat) {
        const regexGroup = new RegExp('\\' + inputGroupFormat, 'g');
        normalized = normalized.replace(regexGroup, '');
      }
      if (inputDecimalFormat !== '.') {
        const regexDecimal = new RegExp('\\' + inputDecimalFormat);
        normalized = normalized.replace(regexDecimal, '.');
      }

      const number = parseFloat(normalized);
      if (isNaN(number)) return '';

      // Formatear número con salida deseada
      const formatter = new Intl.NumberFormat('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
        useGrouping: false
      });

      let result = formatter.format(number); // por defecto con `.`
      if (outputDecimalFormat !== '.') {
        result = result.replace('.', outputDecimalFormat);
      }

      return result;
    }


    parseFormattedNumber(inputValue) {
      // Caso 1: valor vacío, nulo o no numérico reconocible
      if (
        inputValue === '' ||
        inputValue === null ||
        inputValue === undefined ||
        (typeof inputValue === 'number' && isNaN(inputValue))
      ) {
        return 0.00;
      }

      // Caso 2: ya es un número válido
      if (typeof inputValue === 'number') return inputValue;

      // Caso 3: inputValue es string con formato
      if (typeof inputValue !== 'string') return 0.00;

      const hasComma = inputValue.includes(',');
      const hasDot = inputValue.includes('.');

      let decimalSep = '.';
      let groupSep = '';

      if (hasComma && hasDot) {
        decimalSep = inputValue.lastIndexOf(',') > inputValue.lastIndexOf('.') ? ',' : '.';
        groupSep = decimalSep === ',' ? '.' : ',';
      } else if (hasComma) {
        decimalSep = inputValue.length - inputValue.lastIndexOf(',') <= 3 ? ',' : '.';
        groupSep = decimalSep === ',' ? '' : ',';
      } else if (hasDot) {
        decimalSep = inputValue.length - inputValue.lastIndexOf('.') <= 3 ? '.' : ',';
        groupSep = decimalSep === '.' ? '' : '.';
      }

      // Eliminar separador de miles
      if (groupSep) {
        inputValue = inputValue.replace(new RegExp('\\' + groupSep, 'g'), '');
      }

      // Reemplazar separador decimal por punto
      if (decimalSep !== '.') {
        inputValue = inputValue.replace(decimalSep, '.');
      }

      const parsed = parseFloat(inputValue);
      return isNaN(parsed) ? 0.00 : parsed;
    }



  }

  return PageModule;
});
