define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBotonesClick extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.accion 
     */
    async run(context, { accion }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if (accion === 'rechazar') {

        $variables.motivoRequerido = true;

        $variables.accionBoton = '1';

        $variables.mensajeConfirmar = true;

        // guardo acción elegida
        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'RECHAZAR',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            funcionalidad: $page.variables.funcionalidad,
            transaccion: $variables.workflowId + "-" + $variables.workflowInstance + " - " + $variables.nodo,
            observaciones: $variables.numeroProveedor.toString().padStart(8,'0'),
          },
        });

        const popupBotonesOpen = await Actions.callComponentMethod(context, {
          selector: '#popupBotones',
          method: 'open',
        });
      }

      if (accion === 'devolver') {

        $variables.motivoRequerido = true;

        $variables.accionBoton = '2';

        $variables.mensajeConfirmar = true;

        // guardo acción elegida
        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'DEVOLVER',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            funcionalidad: $page.variables.funcionalidad,
            transaccion: $variables.workflowId + "-" + $variables.workflowInstance + " - " + $variables.nodo,
            observaciones: $variables.numeroProveedor.toString().padStart(8,'0'),
          },
        });

        const popupBotonesOpen = await Actions.callComponentMethod(context, {
          selector: '#popupBotones',
          method: 'open',
        });
      }

      if (accion === 'aprobar') {

        $variables.motivoRequerido = false;

        $variables.accionBoton = '3';

        $variables.mensajeConfirmar = false;

        // guardo acción elegida
        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'APROBAR',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            funcionalidad: $page.variables.funcionalidad,
            transaccion: $variables.workflowId + "-" + $variables.workflowInstance + " - " + $variables.nodo,
            observaciones: $variables.numeroProveedor.toString().padStart(8,'0'),
          },
        });

        const popupBotonesOpen2 = await Actions.callComponentMethod(context, {
          selector: '#popupBotones',
          method: 'open',
        });
      }
    }
  }

  return actBotonesClick;
});
