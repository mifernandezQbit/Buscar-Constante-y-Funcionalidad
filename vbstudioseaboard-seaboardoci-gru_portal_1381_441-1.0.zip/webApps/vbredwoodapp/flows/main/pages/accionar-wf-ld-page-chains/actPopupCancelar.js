define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actPopupCancelar extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const guardarLog = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'CANCELAR',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            funcionalidad: $page.variables.funcionalidad,
            transaccion: $variables.workflowId + "-" + $variables.workflowInstance + " - " + $variables.nodo,
 	          observaciones: $variables.numeroProveedor.toString().padStart(8,'0'),
          },
        });
    
        const popupBotonesClose = await Actions.callComponentMethod(context, {
          selector: '#popupBotones',
          method: 'close',
        });

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.mensajeMotivo',
        ],
      });
    }
  }

  return actPopupCancelar;
});
