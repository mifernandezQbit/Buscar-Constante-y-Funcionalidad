define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actPopupHabilitarConfirmar extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if (value === undefined || value === null || value === '' && $variables.accionBoton !== '3') {
        $variables.mensajeConfirmar = true;
      } else {
        $variables.mensajeConfirmar = false;
      }
    }
  }

  return actPopupHabilitarConfirmar;
});
