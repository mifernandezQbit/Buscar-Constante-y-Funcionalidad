define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actInicio extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const permisoModificar = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: $variables.funcionalidad,
        },
      });

      if (permisoModificar.existe === false) {

        const guardarLog = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'INTENTO_INGRESO_NH',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            funcionalidad: $page.variables.funcionalidad,
            transaccion: $variables.workflowId + "-" + $variables.workflowInstance + " - " + $variables.nodo,
          },
        });
        const toAccesoNoAutorizado2 = await Actions.navigateToPage(context, {
          page: 'acceso-no-autorizado',
        });
      } else {
        const guardarLog2 = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'INGRESA',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            funcionalidad: $page.variables.funcionalidad,
            transaccion: $variables.workflowId + "-" + $variables.workflowInstance + " - " + $variables.nodo,
            observaciones: $variables.numeroProveedor.toString().padStart(8,'0'),
          },
        });
      }

      // Buscar ID tipo chat
      const tipoChatID = await Actions.callChain(context, {
        chain: 'application:buscar_tipoChat',
        params: {
          tipoObjetoChat: 'PR',
        },
      });

      $variables.tipochatID = tipoChatID.tipoChatID;
           // MIF buscar configuración de nodo de workflow para ver que sección puede modificar
          $variables.workflowNodo = await Actions.callChain(context, {
            chain: 'application:buscar_workflow_nodo',
            params: {
              nodo: $page.variables.nodo,
              workflow: $page.variables.workflowId,
            },
          });
    }
  }

  return actInicio;
});
