define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class mostrarDrawerMensajes extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const nuevoValor = await this.generarRandom(context);

      $variables.mostrarDrawer = 'nuevoValor';
    }

    /**
     * @param {Object} context
     */
    async generarRandom(context) {
      let random = Math.random(1, 10);

      return random;

    }
  }

  return mostrarDrawerMensajes;
});
