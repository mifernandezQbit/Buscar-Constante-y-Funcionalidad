define([
    'vb/action/actionChain',
    'vb/action/actions',
    'vb/action/actionUtils',
], (
    ActionChain,
    Actions,
    ActionUtils
) => {
    'use strict';

    class actPopupConfirmar extends ActionChain {

        /**
         * @param {Object} context
         */
        async run(context) {
            const {
                $page,
                $flow,
                $application,
                $constants,
                $variables
            } = context;

            $variables.actualizando = true;
            const ADJUNTOS_VISIBLES_PORTAL_CC = await Actions.callChain(context, {
                chain: 'application:buscar_constante',
                params: {
                    constante: 'ADJUNTOS_VISIBLES_PORTAL_CC',
                },
            });

            const ADJUNTOS_VISIBLES_PORTAL_COD = await Actions.callChain(context, {
                chain: 'application:buscar_constante',
                params: {
                    constante: 'ADJUNTOS_VISIBLES_PORTAL_COD',
                },
            });

            $page.variables.inParamListaArchivos.incluirMetadatos = true;

            $page.variables.inParamListaArchivos.metadatos.codigosCategoria[ADJUNTOS_VISIBLES_PORTAL_CC.valor] = ADJUNTOS_VISIBLES_PORTAL_COD.valor;

            $page.variables.inParamListaArchivos.metadatos.mokey = $variables.activityInstanceUniqueID;
            $page.variables.inParamListaArchivos.idUnicoTareaWorkflow = $variables.activityInstanceUniqueID;

            $page.variables.inParamListaArchivos.numeroProveedor = $variables.numeroProveedor;

            $page.variables.inParamListaArchivos.tipoObjeto = 'GT98866';

            $page.variables.inParamListaArchivos.token = $application.variables.token;


            // Se actualiza la respuesta del WF elegida en jde
            let respuestaWF = "";
            if ($variables.accionBoton === "1") {
                respuestaWF = 'R';
            } else if ($variables.accionBoton === "2") {
                respuestaWF = 'V';
            } else if ($variables.accionBoton === "3") {
                respuestaWF = 'A';
            }

            // armar array de atributos a actualizar
            let atributos = [{
                atributo: 'ADDMSG',
                valor: $page.variables.mensajeMotivo,
            }];
            // se modifican datos generales
            if ($variables.seccionGeneralModificada || ($variables.seccionGeneralDocumentacionModificada ?? false)) {
                atributos.push({
                    atributo: 'EV01',
                    valor: ($variables.seccionGeneralModificada || ($variables.seccionGeneralDocumentacionModificada ?? false)),
                });
            }

            // se modifican datos impuestos
            if ($variables.seccionImpuestosModificada || ($variables.seccionImpuestosDocumentacionModificada ?? false)) {
                atributos.push({
                    atributo: 'EV02',
                    valor: ($variables.seccionImpuestosModificada || ($variables.seccionImpuestosDocumentacionModificada ?? false)),
                });
            }

            // se modifican datos tesoreria
            if ($variables.seccionBancoModificada || ($variables.seccionBancoDocumentacionModificada ?? false)) {
                atributos.push({
                    atributo: 'EV03',
                    valor: ($variables.seccionBancoModificada || ($variables.seccionBancoDocumentacionModificada ?? false)),
                });
            }

            // se modifican datos contabilidad
            if ($variables.seccionContabilidadModificada || ($variables.seccionContabilidadDocumentacionModificada ?? false)) {
                atributos.push({
                    atributo: 'EV04',
                    valor: ($variables.seccionContabilidadModificada || ($variables.seccionContabilidadDocumentacionModificada ?? false)),
                });
            }

            // se modifican datos transportista
            if ($variables.seccionTransportistaModificada || ($variables.seccionTransportistasDocumentacionModificada ?? false)) {
                atributos.push({
                    atributo: 'EV05',
                    valor: ($variables.seccionTransportistaModificada || ($variables.seccionTransportistasDocumentacionModificada ?? false)),
                });
            }

            // se modifican datos contactos
            if ($variables.seccionContactosModificada || ($variables.seccionContactosDocumentacionModificada ?? false)) {
                atributos.push({
                    atributo: 'EV06',
                    valor: ($variables.seccionContactosModificada || ($variables.seccionContactosDocumentacionModificada ?? false)),
                });
            }

            // sección ofac
            if ($variables.seccionOfacModificada || ($variables.seccionOfacDocumentacionModificada ?? false)) {
                atributos.push({
                    atributo: 'EV07',
                    valor: ($variables.seccionOfacModificada || ($variables.seccionOfacDocumentacionModificada ?? false)),
                });
            }

            // actualizar respuesta workflow
            const response = await Actions.callRest(context, {
                endpoint: 'GatewayPortal2/postQ71PO_ActualizarRespuestaWF',
                body: {
                    token: $application.variables.token,
                    atributos: atributos,
                    modo: '0',
                    idUnicoActividad: $page.variables.activityInstanceUniqueID,
                    codigoAccionActividad: respuestaWF,
                    wfRespuesta: respuestaWF,
                    modulo: '01',
                    funcionalidadPortal: $page.variables.funcionalidad,
                    accionWF: $page.variables.actionWf,
                    accionJDE: 'C',
                    usuarioAn8: $application.variables.user.numeroAn8,
                    nroProveedor: $page.variables.numeroProveedor,
                    tipoDocumento: '',
                    nroDocumento: '',
                    ciaDocumento: '',
                },
            });

            await Actions.callChain(context, {
              chain: 'application:verificar_respuesta_jdeError',
              params: {
                error: !response.ok,
                funcion: 'ActualizarRespuestaWf',
                funcionalidad: $variables.funcionalidad,
                tokenExpirado: response.body.tokenExpirado,
                transaccion: $variables.activityInstanceUniqueID,
                status: response.status,
                observaciones: '',
              },
            });

            let sinError = response.ok && response.body.success && !response.body.errorJde ? true : false;
            let accionBoton = "APROBAR";
            if (sinError === true) {


                if ($variables.accionBoton === '1') {
                    accionBoton = "RECHAZAR";
                    const guardarLog = await Actions.callChain(context, {
                        chain: 'application:guardar_log',
                        params: {
                            accion: accionBoton + "_OK", //'RECHAZA',
                            numeroAn8: $application.variables.user.numeroAn8,
                            pagina: $flow.currentPage,
                            proveedor: $application.variables.user.esProveedor,
                            roles: $application.variables.userRoles.userRolesSt,
                            suscriptorId: $application.variables.suscriptor.id,
                            usuario: $application.variables.user.ociUser,
                            funcionalidad: $page.variables.funcionalidad,
                            transaccion: $variables.workflowId + "-" + $variables.workflowInstance + " - " + $variables.nodo,
 	                          observaciones: $variables.numeroProveedor.toString().padStart(8,'0'),
                        },
                    });


                    if ($variables.mensajeMotivo !== undefined && $variables.mensajeMotivo.trim() !== "") {

                        await Actions.callChain(context, {
                            chain: 'application:convertir_y_subir_pdf',
                            params: {
                                inParamAdjuntoPDF: true,
                                mensaje: $page.variables.mensajeMotivo,
                                nombrePDF: 'RechazoPDF.pdf',
                                attributosJDE: $page.variables.inParamListaArchivos,
                            },
                        });


                        const popupBotonesClose = await Actions.callComponentMethod(context, {
                            selector: '#popupBotones',
                            method: 'close',
                        });
                    }

                }
                if ($variables.accionBoton === '2') {
                    accionBoton = "DEVOLVER";
                    const guardarLog1 = await Actions.callChain(context, {
                        chain: 'application:guardar_log',
                        params: {
                            accion: accionBoton + "_OK", //'DEVUELVE',
                            numeroAn8: $application.variables.user.numeroAn8,
                            pagina: $flow.currentPage,
                            proveedor: $application.variables.user.esProveedor,
                            roles: $application.variables.userRoles.userRolesSt,
                            suscriptorId: $application.variables.suscriptor.id,
                            usuario: $application.variables.user.ociUser,
                            funcionalidad: $page.variables.funcionalidad,
                            transaccion: $variables.workflowId + "-" + $variables.workflowInstance + " - " + $variables.nodo,
 	                          observaciones: $variables.numeroProveedor.toString().padStart(8,'0'),
                        },
                    });


                    if ($variables.mensajeMotivo !== undefined && $variables.mensajeMotivo.trim() !== "") {
                        await Actions.callChain(context, {
                            chain: 'application:convertir_y_subir_pdf',
                            params: {
                                inParamAdjuntoPDF: true,
                                mensaje: $page.variables.mensajeMotivo,
                                nombrePDF: 'DevolucionPDF.pdf',
                                attributosJDE: $page.variables.inParamListaArchivos,
                            },
                        });


                    }




                    const popupBotonesClose = await Actions.callComponentMethod(context, {
                        selector: '#popupBotones',
                        method: 'close',
                    });
                }



                if ($variables.accionBoton === '3') {

                    const guardarLog2 = await Actions.callChain(context, {
                        chain: 'application:guardar_log',
                        params: {
                            accion: accionBoton + "_OK", //'APRUEBA',
                            numeroAn8: $application.variables.user.numeroAn8,
                            pagina: $flow.currentPage,
                            proveedor: $application.variables.user.esProveedor,
                            roles: $application.variables.userRoles.userRolesSt,
                            suscriptorId: $application.variables.suscriptor.id,
                            usuario: $application.variables.user.ociUser,
                            funcionalidad: $page.variables.funcionalidad,
                            transaccion: $variables.workflowId + "-" + $variables.workflowInstance + " - " + $variables.nodo,
 	                          observaciones: $variables.numeroProveedor.toString().padStart(8,'0'),
                        },
                    });

                    if ($variables.mensajeMotivo !== undefined && $variables.mensajeMotivo.trim() !== "") {
                        await Actions.callChain(context, {
                            chain: 'application:convertir_y_subir_pdf',
                            params: {
                                inParamAdjuntoPDF: true,
                                mensaje: $page.variables.mensajeMotivo,
                                nombrePDF: 'AprobacionPDF.pdf',
                                attributosJDE: $page.variables.inParamListaArchivos,
                            },
                        });

                    }
                    const popupBotonesClose = await Actions.callComponentMethod(context, {
                        selector: '#popupBotones',
                        method: 'close',
                    });
                }


                const notificarError = await Actions.callChain(context, {
                    chain: 'application:notificar_error',
                    params: {
                        codigo: 'respuesta-wf-ok',
                        modoVisualizacion: '',
                    },
                });

                await Actions.resetVariables(context, {
                    variables: [
                        '$page.variables.mensajeMotivo',
                    ],
                });

                $variables.actualizando = false;
                await Actions.navigateBack(context, {});
            } else {
              if (response.ok) {
                  const guardarLog2 = await Actions.callChain(context, {
                        chain: 'application:guardar_log',
                        params: {
                            accion: accionBoton + "_ERROR",
                            numeroAn8: $application.variables.user.numeroAn8,
                            pagina: $flow.currentPage,
                            proveedor: $application.variables.user.esProveedor,
                            roles: $application.variables.userRoles.userRolesSt,
                            suscriptorId: $application.variables.suscriptor.id,
                            usuario: $application.variables.user.ociUser,
                            funcionalidad: $page.variables.funcionalidad,
                            transaccion: $variables.workflowId + "-" + $variables.workflowInstance + " - " + $variables.nodo,
 	                          observaciones: $variables.numeroProveedor.toString().padStart(8,'0'),
                        },
                    });
              }
                const notificarError2 = await Actions.callChain(context, {
                    chain: 'application:notificar_error',
                    params: {
                        codigo: 'respuesta-wf-error',
                        modoVisualizacion: '',
                    },
                });
            }

            $variables.actualizando = false;
        }
    }

    return actPopupConfirmar;
});
