define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actInicio extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const toApCruComprobantesMatching = await Actions.navigateToPage(context, {
        page: 'ap-cru-comprobantes-matching',
        params: {
          paramMatching: $variables.paramMatching,
          paramModoCRU: $variables.paramModoCRU,
          paramNroProveedor: $variables.paramNroProveedor,
          paramTipoObjetoChat: $variables.paramTipoObjetoChat,
          paramTitulo: $variables.paramTitulo,
          paramVersionJDE: $variables.paramVersionJDE,
          paramFuncionalidadMenu: $variables.paramFuncionalidadMenu,
        },
      });
    }
  }

  return actInicio;
});
