define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class archivoAdjuntoVOUCHERListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:object,value:object}} params.event
     */
    async run(context, { event }) {
      const { $page } = context;

      // Verificamos si hay un valor nuevo y si contiene un archivo
      if (event.value && event.value.archivo && event.value.archivo !== "") {
        
        $page.variables.flagPageLoading = true; // Activamos carga
          
        await this.previewArchivoAdjuntoVOUCHER(context, { 
          id: 'previewArchivo', 
          blob: event.value.archivo, 
          nombreArchivo: event.value.nombreArchivo 
        });

      } else {
        // Limpiamos el contenedor si no hay archivo
        const container = document.getElementById('previewArchivo');
        if (container) container.innerHTML = '';
        $page.variables.flagPageLoading = false;
      }
    }

    /**
     * Renderiza en pantalla el archivo descargado usando Blobs y ObjectURLs
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.id ID del contenedor HTML
     * @param {string} params.blob Base64 del archivo
     * @param {string} params.nombreArchivo Nombre del archivo con extensión
     */
    async previewArchivoAdjuntoVOUCHER(context, { id, blob, nombreArchivo }) {
      const { $page } = context;

      return new Promise((resolve, reject) => {
        try {
          if (!blob) {
            $page.variables.flagPageLoading = false;
            return resolve();
          }

          const container = document.getElementById(id);
          if (!container) return resolve();
          container.innerHTML = ""; // Limpiamos el contenedor

          // 1. Convertir Base64 a Array de Bytes de forma eficiente
          const binaryString = atob(blob);
          const len = binaryString.length;
          const bytes = new Uint8Array(len);
          for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }

          // 2. Determinar Tipo MIME por extensión
          let mimeType = "application/octet-stream";
          const name = nombreArchivo.toUpperCase();
          
          if (name.endsWith('.PDF')) {
            mimeType = "application/pdf";
          } else if (name.endsWith('.JPG') || name.endsWith('.JPEG')) {
            mimeType = "image/jpeg";
          } else if (name.endsWith('.PNG')) {
            mimeType = "image/png";
          } else if (name.endsWith('.GIF')) {
            mimeType = "image/gif";
          } else if (name.endsWith('.TXT')) {
            mimeType = "text/plain";
          }

          // 3. Crear el objeto Blob y su URL (esto no consume memoria de string)
          const fileBlob = new Blob([bytes], { type: mimeType });
          const fileUrl = URL.createObjectURL(fileBlob);

          // 4. Renderizado según tipo
          if (mimeType === "application/pdf") {
            const pdfObj = document.createElement('object');
            pdfObj.style.width = '100%';
            pdfObj.style.height = '650px';
            pdfObj.style.padding = "2px";
            pdfObj.type = 'application/pdf';
            pdfObj.data = fileUrl; // URL del Blob
            
            container.appendChild(pdfObj);
            $page.variables.flagPageLoading = false;
            resolve({ "url": fileUrl, "tipo": "pdf" });

          } else if (mimeType.startsWith("image/")) {
            const img = document.createElement("img");
            img.src = fileUrl;
            img.alt = nombreArchivo;
            img.style.maxWidth = "100%";
            img.style.display = "block";
            
            container.appendChild(img);
            $page.variables.flagPageLoading = false;
            resolve({ "url": fileUrl, "tipo": "img" });

          } else if (mimeType === "text/plain") {
            fileBlob.text().then(text => {
              container.style.whiteSpace = "pre-wrap";
              container.innerHTML = text;
              $page.variables.flagPageLoading = false;
              resolve({ "data": text });
            });

          } else {
            // Descarga para formatos no previsualizables
            const link = document.createElement('a');
            link.href = fileUrl;
            link.download = nombreArchivo;
            link.click();
            $page.variables.flagPageLoading = false;
            resolve({ "descarga": true });
          }

        } catch (error) {
          console.error("Error en previewArchivoAdjuntoVOUCHER:", error);
          $page.variables.flagPageLoading = false;
          reject(error);
        }
      });
    }
  }

  return archivoAdjuntoVOUCHERListener;
});
