define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnAdjuntarComprobante extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const callFunctionMostrarDrawerAdjuntarArchivosComprobante = await this.generarRandomComprobante(context);
      $page.variables.mostrarDrawerAdjuntarArchivosComprobante = callFunctionMostrarDrawerAdjuntarArchivosComprobante;

      const guardarLogAdjuntarArchivosComprobante = await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'ADJUNTAR_COMPROBANTE',
          pagina: $flow.currentPage,
          proveedor: $application.variables.user.esProveedor,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          numeroAn8: $application.variables.user.numeroAn8,
          //transaccion: '',
          roles: $application.variables.userRoles.userRolesSt,
          funcionalidad: $page.variables.paramFuncionalidadMenu,
        },
      });

    }

    /**
    * @param {Object} context
    */
    async generarRandomComprobante(context) {
      const { $page, $flow, $application } = context;
      let random = Math.random(1, 10);
      return random;
    }


  }

  return actBtnAdjuntarComprobante;
});
