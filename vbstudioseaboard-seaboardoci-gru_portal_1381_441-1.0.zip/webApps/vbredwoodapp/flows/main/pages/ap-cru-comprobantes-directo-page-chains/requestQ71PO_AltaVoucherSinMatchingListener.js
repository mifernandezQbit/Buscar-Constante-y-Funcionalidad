define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class requestQ71PO_AltaVoucherSinMatchingListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:typRequestQ71PO_AltaVoucherSinMatching,value:typRequestQ71PO_AltaVoucherSinMatching}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application } = context;


      //marco modificacion / se sale esta marca con el Guardar en modoCRU U
      if (!$page.variables.flagPageLoading && !$page.variables.flagModified && ['U', 'P'].includes($page.variables.paramModoCRU)) {
        $page.variables.flagModified = true;
      }

    }
  }

  return requestQ71PO_AltaVoucherSinMatchingListener;
});
