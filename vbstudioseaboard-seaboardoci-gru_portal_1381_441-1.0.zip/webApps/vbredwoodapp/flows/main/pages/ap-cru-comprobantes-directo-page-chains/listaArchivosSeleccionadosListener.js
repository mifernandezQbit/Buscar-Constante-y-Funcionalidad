define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class listaArchivosSeleccionadosListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:application:archivoAdjunto[],value:application:archivoAdjunto[]}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      /*
      //ANULO TODA ESTA LOGICA PARA QUE NO HAGA NADA CON EL ROLLBACK DE COMPORTAMIENTO COMO DEBERÍA CON LISTAS POR SEPARADO PARA CADA FRAGMENTO
      console.log('logjmp', 'listaArchivosSeleccionadosListener', event.value[event.value.length - 1], $page.variables.mostrarDrawerAdjuntarArchivosComprobante, $page.variables.mostrarDrawerAdjuntarArchivosCaucion, $page.variables.mostrarDrawerAdjuntarArchivosOtros);

      if (event.value.length > 0) {

        if ($page.variables.mostrarDrawerAdjuntarArchivosCaucion > 0) {
          let auxArchivoCaucion = { ...event.value[event.value.length - 1]};
          auxArchivoCaucion.nombreArchivo = 'Caucion-'+auxArchivoCaucion.nombreArchivo; 
          $page.variables.listaArchivosSeleccionadosCaucion.push(auxArchivoCaucion);
          console.log('logjmp', 'listaArchivosSeleccionadosListener listaArchivosSeleccionadosCaucion.push', $page.variables.listaArchivosSeleccionadosCaucion.length, $page.variables.listaArchivosSeleccionadosCaucion);
          $page.variables.mostrarDrawerAdjuntarArchivosCaucion = -1;
        }
        if ($page.variables.mostrarDrawerAdjuntarArchivosOtros > 0) {
          let auxArchivoOtros = { ...event.value[event.value.length - 1] };
          auxArchivoOtros.nombreArchivo = 'Otros-'+auxArchivoOtros.nombreArchivo; 
          $page.variables.listaArchivosSeleccionadosOtros.push(auxArchivoOtros);
          console.log('logjmp', 'listaArchivosSeleccionadosListener listaArchivosSeleccionadosOtros.push', $page.variables.listaArchivosSeleccionadosOtros.length, $page.variables.listaArchivosSeleccionadosOtros[0]);
          $page.variables.mostrarDrawerAdjuntarArchivosOtros = -1;
        }
        if ($page.variables.mostrarDrawerAdjuntarArchivosComprobante > 0) {
          let auxArchivoComprobante = { ...event.value[event.value.length - 1]};
          auxArchivoComprobante.nombreArchivo = 'Comprobante-'+auxArchivoComprobante.nombreArchivo; 
          $page.variables.listaArchivosSeleccionadosComprobante.push(auxArchivoComprobante);
          console.log('logjmp', 'listaArchivosSeleccionadosListener listaArchivosSeleccionadosComprobante.push', $page.variables.listaArchivosSeleccionadosComprobante.length, $page.variables.listaArchivosSeleccionadosComprobante);
          $page.variables.mostrarDrawerAdjuntarArchivosComprobante = -1;


          //esta conversión servía si se necesitaba pasar de base64 a blob, pero finalmente viene en blob directo desde el adjuntar archivo
          //const byteCharacters = atob($page.variables.listaArchivosSeleccionados[0].archivo);
          //const byteNumbers = new Array(byteCharacters.length);
          //for (let i = 0; i < byteCharacters.length; i++) {
          //  byteNumbers[i] = byteCharacters.charCodeAt(i);
          //}
          //const byteArray = new Uint8Array(byteNumbers);
          //const returnBlob = new Blob([byteArray], { type: $page.variables.listaArchivosSeleccionados[0].typeAdjunto });

          const callFunction = await this.preview(context, { id: 'previewArchivo', blob: $page.variables.listaArchivosSeleccionadosComprobante[0].archivo, nombreArchivo: $page.variables.listaArchivosSeleccionadosComprobante[0].nombreArchivo }); //returnBlob });


        } else {
          document.getElementById('previewArchivo').innerHTML = '';
        }

      } 
      /// *
      else {
        //reseteo las listas de archivos adjuntos
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.listaArchivosSeleccionadosComprobante',
            '$page.variables.listaArchivosSeleccionadosCaucion',
            '$page.variables.listaArchivosSeleccionadosOtros',
          ],
        });
      }
      //* /

      / *
      //reseteo los mostraDrawerAdjuntarArchivos
      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.mostrarDrawerAdjuntarArchivosComprobante',
          '$page.variables.mostrarDrawerAdjuntarArchivosCaucion',
          '$page.variables.mostrarDrawerAdjuntarArchivosOtros',
        ],
      });
      * /
      */




    }

    /**
     * renderiza en pantalla el archivo descargado
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.id 
     * @param {any} params.blob archivo descargado tipo blob
     * @return {object} 
    */
    async preview(context, { id,
      blob, nombreArchivo }) {
      const { $page, $application } = context;
      return new Promise(function (resolve, reject) {

        let url = "";
        let reader = new FileReader();
        window.URL = window.webkitURL || window.URL;

        if (blob) {
          /////////////////////
          /////////////////////
          ///////////////////// se crea el blob de acuerdo al tipo para el handle reader
          let blobl = atob(blob);
          let name = nombreArchivo;

          const bytes = new Uint8Array(blobl.length);
          for (let i = 0; i < blobl.length; i++) { bytes[i] = blobl.charCodeAt(i); }

          if (name.toUpperCase().includes('.JPEG') || name.toUpperCase().includes('.JPG') || name.toUpperCase().includes('.PNG') || name.toUpperCase().includes('.GIF')) {
            blob = new Blob([bytes.buffer], { type: "application" });
          } else if (name.toUpperCase().includes('.PDF')) {
            blob = new Blob([bytes.buffer], { type: "application/pdf" });
          } else if (name.toUpperCase().includes('.TXT')) {
            blob = new Blob([bytes.buffer], { type: "txt" });
          } else {
            blob = new Blob([bytes.buffer], { type: "application" });
          }
          /////////////////////
          /////////////////////
          /////////////////////
          reader.onload = function (e) {
            document.getElementById(id).innerHTML = "";
            if (name.toUpperCase().includes('.JPEG') || name.toUpperCase().includes('.JPG') || name.toUpperCase().includes('.PNG') || name.toUpperCase().includes('.GIF')) {
              url = URL.createObjectURL(blob);
              let elem = document.createElement("img");
              elem.setAttribute("src", url);
              elem.setAttribute("alt", name);
              document.getElementById(id).style.display = "block";
              document.getElementById(id).appendChild(elem);
              resolve({ "url": url, "tipo": "img" });
            } else if (name.toUpperCase().includes('.PDF')) {
              const myPDF = document.createElement('object');
              myPDF.style.width = '100%'; //'850px';
              myPDF.style.height = '650px'; //'850px'; //'100%';  //'1024px';
              myPDF.style.padding = "2px";
              myPDF.type = 'application/pdf';
              myPDF.data = reader.result;
              myPDF.data = myPDF.data.replace("data:application/octet-stream;base64", "data:application/pdf;base64");
              document.getElementById(id).appendChild(myPDF);

            } else if (name.toUpperCase().includes('.TXT')) {
              url = URL.createObjectURL(blob);
              blob.text().then(text => {
                document.getElementById(id).style.width = "100%";
                document.getElementById(id).style.height = "100%";
                document.getElementById(id).style.padding = "4px";
                document.getElementById(id).innerHTML = text;
                resolve({ "data": text });
              });
            } else {
              url = URL.createObjectURL(blob);
              let link = document.createElement('a');
              link.href = url;
              link.download = name;
              link.click();
            }
          };
          reader.readAsDataURL(blob);
        }
      });


    }
  }

  return listaArchivosSeleccionadosListener;
});
