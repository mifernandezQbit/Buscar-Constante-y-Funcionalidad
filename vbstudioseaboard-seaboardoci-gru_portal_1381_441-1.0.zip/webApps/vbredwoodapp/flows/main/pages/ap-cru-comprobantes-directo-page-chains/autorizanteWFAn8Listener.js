define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class autorizanteWFAn8Listener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:string,value:string}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      //rectifico flagModified para frag WF
      if ((!event.value || event.value === '')
        && $variables.paramModoCRU === 'U'
        && $variables.actionWf === 'A'
        && ($variables.uniqueWorkflowMatriz && $variables.uniqueWorkflowMatriz[0]?.modoNodoInicial === 'P')
      ) {
        $page.variables.flagModified = true; //deshabilita básicamente el btn wf Aprobar
      }

    }
  }

  return autorizanteWFAn8Listener;
});
