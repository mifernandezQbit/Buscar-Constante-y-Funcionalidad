define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class menuOpcionesActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.menuId 
     */
    async run(context, { menuId }) {
      const { $page, $flow, $application, $variables } = context;

            const buscarConstanteADJUNTOS_AP_TIPO_CC = await Actions.callChain(context, {
              chain: 'application:buscar_constante',
              params: {
                constante: 'ADJUNTOS_AP_TIPO_CC',
              },
            });
            if (buscarConstanteADJUNTOS_AP_TIPO_CC.existe === true) {

              $page.variables.consADJUNTOS_AP_TIPO_CC = buscarConstanteADJUNTOS_AP_TIPO_CC.valor;

            }


      switch (menuId) {

        case 'VER_POLIZA_CAUCION':

          const buscarConstanteADJUNTOS_VISIBLES_PORTAL_CC_POLIZA_CAUCION = await Actions.callChain(context, {
            chain: 'application:buscar_constante',
            params: {
              constante: 'ADJUNTOS_VISIBLES_PORTAL_CC',
            },
          });
          if (buscarConstanteADJUNTOS_VISIBLES_PORTAL_CC_POLIZA_CAUCION.existe === true) {

            $page.variables.consADJUNTOS_VISIBLES_PORTAL_CC = buscarConstanteADJUNTOS_VISIBLES_PORTAL_CC_POLIZA_CAUCION.valor;


            //como ya obtuve la posición del array de códigosCategoria ahora busco el valor a setear
            const buscarConstanteADJUNTOS_VISIBLES_PORTAL_COD = await Actions.callChain(context, {
              chain: 'application:buscar_constante',
              params: {
                constante: 'ADJUNTOS_VISIBLES_PORTAL_COD',
              },
            });
            if (buscarConstanteADJUNTOS_VISIBLES_PORTAL_COD.existe === true) {

              $page.variables.consADJUNTOS_VISIBLES_PORTAL_COD = buscarConstanteADJUNTOS_VISIBLES_PORTAL_COD.valor;


              //asigno en la posición del Array CC, el valor de COD
              $page.variables.visualizarAdjuntosCodigosCategoria[$page.variables.consADJUNTOS_VISIBLES_PORTAL_CC] = $page.variables.consADJUNTOS_VISIBLES_PORTAL_COD;
            
              //20260622 jmp TODO: ajustar utilizando Constantes
              $page.variables.visualizarAdjuntosCodigosCategoria[$page.variables.consADJUNTOS_AP_TIPO_CC] = 'CAUCION';                        
            
            }

          } else {

            const notificarError = await Actions.callChain(context, {
              chain: 'application:notificar_error',
              params: {
                codigo: 'constantes-adjuntos-not-found',
              },
            });

          }

          $page.variables.visualizarAdjuntosMoKey = $page.variables.responseQ71PO_BuscarVoucherSinMatching.data.ciaDocumento + '|' + $page.variables.responseQ71PO_BuscarVoucherSinMatching.data.tipoDocumento + '|' + $page.variables.responseQ71PO_BuscarVoucherSinMatching.data.nroDocumento + '|' + '001';

          //reseteo el condicional que despliega o no el drawer de visualizar adjuntos
          await Actions.resetVariables(context, {
            variables: [
              '$page.variables.mostrarDrawerVerAdjuntos',
            ],
          });

          //activa el despliegue del drawer de visualizar adjuntos
          const callFunctionMostrarDrawerVerAdjuntos = await this.generarRandomVerAdjuntos(context);
          $page.variables.mostrarDrawerVerAdjuntos = callFunctionMostrarDrawerVerAdjuntos;

          //log
          const guardarLogVerAdjuntos = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              funcionalidad: 'VER_COMPROBANTE',
              accion: 'VER_POLIZA_CAUCION',
              pagina: $flow.currentPage,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
              transaccion: [[$page.variables.responseQ71PO_BuscarVoucherSinMatching.data.ciaDocumento]] + '|' + [[$page.variables.responseQ71PO_BuscarVoucherSinMatching.data.tipoDocumento]] + '|' + [[$page.variables.responseQ71PO_BuscarVoucherSinMatching.data.nroDocumento]] + '|' + '001',
              roles: $application.variables.userRoles.userRolesSt,
            },
          });

          break;

        case 'ADJUNTAR_POLIZA_CAUCION':

          const callFunctionMostrarDrawerAdjuntarArchivosCaucion = await this.generarRandomCaucion(context);
          $page.variables.mostrarDrawerAdjuntarArchivosCaucion = callFunctionMostrarDrawerAdjuntarArchivosCaucion;

          //const guardarLog = 
          await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              funcionalidad: $page.variables.paramFuncionalidadMenu,
              accion: 'ADJUNTAR_POLIZA_CAUCION',
              pagina: $flow.currentPage,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
              transaccion: '', 
              roles: $application.variables.userRoles.userRolesSt,
            },
          });
          break;

        case 'ADJUNTAR_ARCHIVOS':

          if (['U', 'P'].includes($page.variables.paramModoCRU)) { $page.variables.NOUSARrequestQ71PO_ActualizarVoucher = $page.variables.requestQ71PO_AltaVoucherSinMatching;  }

          const callFunctionMostrarDrawerAdjuntarArchivosOtros = await this.generarRandomOtros(context);
          $page.variables.mostrarDrawerAdjuntarArchivosOtros = callFunctionMostrarDrawerAdjuntarArchivosOtros; 

          //const guardarLog = 
          await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              funcionalidad: $page.variables.paramFuncionalidadMenu,
              accion: 'ADJUNTAR_ARCHIVOS',
              pagina: $flow.currentPage,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
              transaccion: '', 
              roles: $application.variables.userRoles.userRolesSt,
            },
          });
          break;

        case 'VER_MENSAJES':

          //reseteo el condicional que despliega o no el drawer de visualizar adjuntos
          await Actions.resetVariables(context, {
            variables: [
              '$page.variables.mostrarDrawerMensajes',
            ],
          });

          const callFunctionMostrarDrawerMensajes = await this.generarRandomMensajes(context);
          $page.variables.mostrarDrawerMensajes = callFunctionMostrarDrawerMensajes;

          //const guardarLog = 
          await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              funcionalidad: $page.variables.paramFuncionalidadMenu,
              accion: 'VER_MENSAJES',
              pagina: $flow.currentPage,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
              transaccion: [[$page.variables.responseQ71PO_BuscarVoucherSinMatching.data.ciaDocumento]] + '|' + [[$page.variables.responseQ71PO_BuscarVoucherSinMatching.data.tipoDocumento]] + '|' + [[$page.variables.responseQ71PO_BuscarVoucherSinMatching.data.nroDocumento]] + '|' + '001',
              roles: $application.variables.userRoles.userRolesSt,
            },
          });

          break;

        case 'VER_ADJUNTOS':

          const buscarConstanteADJUNTOS_VISIBLES_PORTAL_CC = await Actions.callChain(context, {
            chain: 'application:buscar_constante',
            params: {
              constante: 'ADJUNTOS_VISIBLES_PORTAL_CC',
            },
          });
          if (buscarConstanteADJUNTOS_VISIBLES_PORTAL_CC.existe === true) {

            $page.variables.consADJUNTOS_VISIBLES_PORTAL_CC = buscarConstanteADJUNTOS_VISIBLES_PORTAL_CC.valor;


            //como ya obtuve la posición del array de códigosCategoria ahora busco el valor a setear
            const buscarConstanteADJUNTOS_VISIBLES_PORTAL_COD = await Actions.callChain(context, {
              chain: 'application:buscar_constante',
              params: {
                constante: 'ADJUNTOS_VISIBLES_PORTAL_COD',
              },
            });
            if (buscarConstanteADJUNTOS_VISIBLES_PORTAL_COD.existe === true) {

              $page.variables.consADJUNTOS_VISIBLES_PORTAL_COD = buscarConstanteADJUNTOS_VISIBLES_PORTAL_COD.valor;


              //asigno en la posición del Array CC, el valor de COD
              $page.variables.visualizarAdjuntosCodigosCategoria[$page.variables.consADJUNTOS_VISIBLES_PORTAL_CC] = $page.variables.consADJUNTOS_VISIBLES_PORTAL_COD;
            
              //20260622 jmp TODO: ajustar utilizando Constantes
              $page.variables.visualizarAdjuntosCodigosCategoria[$page.variables.consADJUNTOS_AP_TIPO_CC] = 'OTROS';                        
            
            }


          } else {

            const notificarError = await Actions.callChain(context, {
              chain: 'application:notificar_error',
              params: {
                codigo: 'constantes-adjuntos-not-found',
              },
            });

          }

          $page.variables.visualizarAdjuntosMoKey = $page.variables.responseQ71PO_BuscarVoucherSinMatching.data.ciaDocumento + '|' + $page.variables.responseQ71PO_BuscarVoucherSinMatching.data.tipoDocumento + '|' + $page.variables.responseQ71PO_BuscarVoucherSinMatching.data.nroDocumento + '|' + '001';

          //reseteo el condicional que despliega o no el drawer de visualizar adjuntos
          await Actions.resetVariables(context, {
            variables: [
              '$page.variables.mostrarDrawerVerAdjuntos',
            ],
          });

          //activa el despliegue del drawer de visualizar adjuntos
          const callFunctionMostrarDrawerVerAdjuntosPolizaCaucion = await this.generarRandomVerAdjuntos(context);
          $page.variables.mostrarDrawerVerAdjuntos = callFunctionMostrarDrawerVerAdjuntosPolizaCaucion;

          //log
          const guardarLogVerAdjuntosPolizaCaucion = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              funcionalidad: 'VER_COMPROBANTE',
              accion: 'VER_ADJUNTOS',
              pagina: $flow.currentPage,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
              transaccion: [[$page.variables.responseQ71PO_BuscarVoucherSinMatching.data.ciaDocumento]] + '|' + [[$page.variables.responseQ71PO_BuscarVoucherSinMatching.data.tipoDocumento]] + '|' + [[$page.variables.responseQ71PO_BuscarVoucherSinMatching.data.nroDocumento]] + '|' + '001',
              roles: $application.variables.userRoles.userRolesSt,
            },
          });

          break;
      }
    }

    /**
    * @param {Object} context
    */
    async generarRandomCaucion(context) {
      const { $page, $flow, $application } = context;
      let random = Math.random(1, 10);
      return random;
    }
    async generarRandomOtros(context) {
      const { $page, $flow, $application } = context;
      let random = Math.random(1, 10);
      return random;
    }
    async generarRandomVerAdjuntos(context) {
      const { $page, $flow, $application } = context;
      let random = Math.random(1, 10);
      return random;
    }
    async generarRandomMensajes(context) {
      const { $page, $flow, $application } = context;
      let random = Math.random(1, 10);
      return random;
    }

  }

  return menuOpcionesActionChain;
});
