define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class listaArchivosSeleccionadosComprobanteListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:application:archivoAdjunto[],value:application:archivoAdjunto[]}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      //permite previsualizar archivos pdf grandes... probado con >10Mb
      $page.variables.flagPageLoading = true;

      if ($page.variables.listaArchivosSeleccionadosComprobante && $page.variables.listaArchivosSeleccionadosComprobante.length > 0) {
        
        // Llamada a la función de previsualización
        await this.previewComprobante(context, { 
          id: 'previewArchivo', 
          blob: $page.variables.listaArchivosSeleccionadosComprobante[0].archivo, 
          nombreArchivo: $page.variables.listaArchivosSeleccionadosComprobante[0].nombreArchivo 
        });

      } else {
        const container = document.getElementById('previewArchivo');
        if (container) container.innerHTML = '';
        $page.variables.flagPageLoading = false;
      }
    }

    /**
     * renderiza en pantalla el archivo descargado
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.id 
     * @param {any} params.blob base64 del archivo
     */
    async previewComprobante(context, { id, blob, nombreArchivo }) {
      const { $page } = context;
      
      return new Promise((resolve, reject) => {
        try {
          if (!blob) {
            $page.variables.flagPageLoading = false;
            return resolve();
          }

          const container = document.getElementById(id);
          container.innerHTML = ""; // Limpiamos el contenedor
          
          // 1. Convertir Base64 a Array de Bytes (Uint8Array)
          const binaryString = atob(blob);
          const len = binaryString.length;
          const bytes = new Uint8Array(len);
          for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }

          // 2. Determinar Tipo MIME de forma segura
          let mimeType = "application/octet-stream";
          const name = nombreArchivo.toUpperCase();
          
          if (name.endsWith('.PDF')) {
            mimeType = "application/pdf";
          } else if (name.endsWith('.JPG') || name.endsWith('.JPEG')) {
            mimeType = "image/jpeg";
          } else if (name.endsWith('.PNG')) {
            mimeType = "image/png";
          } else if (name.endsWith('.GIF')) {
            mimeType = "image/gif";
          } else if (name.endsWith('.TXT')) {
            mimeType = "text/plain";
          }

          // 3. Crear el objeto Blob real
          const fileBlob = new Blob([bytes], { type: mimeType });
          const fileUrl = URL.createObjectURL(fileBlob);

          // 4. Renderizado según tipo
          if (mimeType === "application/pdf") {
            const pdfObj = document.createElement('object');
            pdfObj.style.width = '100%';
            pdfObj.style.height = '650px';
            pdfObj.style.padding = "2px";
            pdfObj.type = 'application/pdf';
            pdfObj.data = fileUrl; // Usamos el ObjectURL
            
            container.appendChild(pdfObj);
            $page.variables.flagPageLoading = false;
            resolve({ "url": fileUrl, "tipo": "pdf" });

          } else if (mimeType.startsWith("image/")) {
            const img = document.createElement("img");
            img.src = fileUrl;
            img.alt = nombreArchivo;
            img.style.maxWidth = "100%";
            img.style.display = "block";
            
            container.appendChild(img);
            $page.variables.flagPageLoading = false;
            resolve({ "url": fileUrl, "tipo": "img" });

          } else if (mimeType === "text/plain") {
            fileBlob.text().then(text => {
              container.style.whiteSpace = "pre-wrap"; // Para mantener formato de texto
              container.innerHTML = text;
              $page.variables.flagPageLoading = false;
              resolve({ "data": text });
            });

          } else {
            // Descarga automática para otros formatos
            const link = document.createElement('a');
            link.href = fileUrl;
            link.download = nombreArchivo;
            link.click();
            $page.variables.flagPageLoading = false;
            resolve({ "descarga": true });
          }

        } catch (error) {
          console.error("Error en previewComprobante:", error);
          $page.variables.flagPageLoading = false;
          reject(error);
        }
      });

    }
  }

  return listaArchivosSeleccionadosComprobanteListener;
});
