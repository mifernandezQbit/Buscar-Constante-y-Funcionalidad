define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnGuardar extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $variables } = context;

      $page.variables.flagPageLoading = true;

      $page.variables.flagGuardar = false; //deshabilito btnGuardar hasta que termine la action

      const guardarLogGuardar = await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          funcionalidad: $page.variables.paramFuncionalidadMenu,
          accion: 'GUARDAR',
          pagina: $flow.currentPage,
          proveedor: $application.variables.user.esProveedor,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          numeroAn8: $application.variables.user.numeroAn8,
          roles: $application.variables.userRoles.userRolesSt,
          observaciones: $variables.paramModoCRU === "C" ? "AltaVoucherSinMatching" : "ActualizarVoucher",
        },
      });

      let responseQ71PO_AltaVoucherSinMatching;
      let responseQ71PO_ActualizarVoucher;

      let altaOActualizarOK; // = false;

      //limpio fragemento errores para no acumular errores que puedan estar ya solucionados entre guardar y guardar
      $page.variables.erroresJDE = [];

      //si requiere adjuntar poliza de caucion y no lo hizo aún disparar mensaje provisorio
      if (
        ($page.variables.paramFuncionalidadMenu === "INGRESAR_FACTURA_ANTICIPO_100" || $page.variables.paramFuncionalidadMenu === "INGRESAR_FACTURA_ANTICIPO")
        &&
        (
          ($page.variables.montoTotalComprobanteControlCaucion > $page.variables.consMontoCaucion) &&
          $page.variables.listaArchivosSeleccionadosCaucion.length <= 0
        )
        &&
        ($page.variables.paramModoCRU === 'C')
      ) {

        const notificarError4 = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            codigo: 'adjuntar-poliza-caucion',
          },
        });

      } else {

        let mailProveedor = $application.variables.user.esProveedor ? $application.variables.user.email : ($page.variables.datosProveedorLight.data.email || '');

        //================================================================================================
        //INICIO llamar a web service de afip para constatar el comprobante (CAE) si está activa la constante
        //================================================================================================
        if ($page.variables.paramModoCRU === 'C' && $page.variables.uniqueVoucherMatrizFn?.validarCAE) {
          const fecha = await $application.functions.formatDateString($variables.requestQ71PO_AltaVoucherSinMatching.fechaFactura, 'yyyymmdd');

          const responseComprobanteConstatar = await Actions.callRest(context, {
            endpoint: 'GatewayPortal2/postQ71PO_ComprobanteConstatar',
            body: {
              token: $application.variables.token,
              CompanyKey: $application.variables.selectedCompany.company,
              cuit: $application.variables.selectedCompany.cuit,
              puntoVenta: $variables.requestQ71PO_AltaVoucherSinMatching.nroFactura.substring(0, 5),
              tipoCbte: $variables.requestQ71PO_AltaVoucherSinMatching.tipoDocumentoTransaccionAFIP.replace(/^0+/, ''),
              nroCbte: $variables.requestQ71PO_AltaVoucherSinMatching.nroFactura.substring(5),
              cbteModo: $variables.CAEoCAEA,
              cuitEmisor: $page.variables.datosProveedorLight.data.idFiscal,
              codAutorizacion: $variables.requestQ71PO_AltaVoucherSinMatching.nroCAI,
              cbteFecha: fecha,
              importeTotal: $variables.totalComprobanteCabecera,
              docTipoReceptor: '80',
              docNroReceptor: $application.variables.selectedCompany.cuit,
            },
          });

          await Actions.callChain(context, {
            chain: 'application:verificar_respuesta_jdeError',
            params: {
              error: !responseComprobanteConstatar.ok,
              funcion: 'ComprobanteConstatar',
              funcionalidad: $page.variables.paramFuncionalidadMenu,
              tokenExpirado: responseComprobanteConstatar.body.tokenExpirado !== undefined ? responseComprobanteConstatar.body.tokenExpirado : false,
              status: responseComprobanteConstatar.status,
            },
          });

          if (!responseComprobanteConstatar.ok || responseComprobanteConstatar.body.errorJde) {
            // si hubo un error de api, no permitir ingresar el comprobante
            altaOActualizarOK = false;

            const notificarError = await Actions.callChain(context, {
              chain: 'application:notificar_error',
              params: {
                codigo: 'comprobante-constatacion-error',
                modoVisualizacion: '',
              },
            });

            const guardarLog2 = await Actions.callChain(context, {
              chain: 'application:guardar_log',
              params: {
                accion: 'CONSTATAR_CAE',
                funcionalidad: $variables.paramFuncionalidadMenu,
                numeroAn8: $application.variables.user.numeroAn8,
                observaciones: 'Error de servidor al constatar el comprobante',
                pagina: $application.currentPage.id,
                proveedor: $application.variables.user.esProveedor,
                roles: $application.variables.userRoles.userRolesSt,
                suscriptorId: $application.variables.suscriptor.id,
                usuario: $application.variables.user.ociUser,
                transaccion: $variables.requestQ71PO_AltaVoucherSinMatching.nroFactura
              },
            });
          } else {
            // ver si hubo error de constatacion
            if (responseComprobanteConstatar.body.data !== "A") {
              altaOActualizarOK = false;
              const notificarError = await Actions.callChain(context, {
                chain: 'application:notificar_error',
                params: {
                  codigo: 'comprobante-constatacion-error',
                  modoVisualizacion: '',
                },
              });
              const guardarLog3 = await Actions.callChain(context, {
                chain: 'application:guardar_log',
                params: {
                  accion: 'GUARDAR',
                  funcionalidad: $variables.paramFuncionalidadMenu,
                  numeroAn8: $application.variables.user.numeroAn8,
                  observaciones: 'No superó constatación de comprobante',
                  pagina: $application.currentPage.id,
                  proveedor: $application.variables.user.esProveedor,
                  roles: $application.variables.userRoles.userRolesSt,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  transaccion: $variables.requestQ71PO_AltaVoucherSinMatching.nroFactura
                },
              });
            } else {
              const notificarError = await Actions.callChain(context, {
                chain: 'application:notificar_error',
                params: {
                  codigo: 'comprobante-constatacion-ok',
                  modoVisualizacion: '',
                },
              });

            }
          }
        }
        //================================================================================================
        //FIN llamar a web service de afip para constatar el comprobante (CAE) si está activa la constante
        //================================================================================================
        if (altaOActualizarOK === undefined || altaOActualizarOK !== false) {
          //modoCRU C CREATE AltaVoucher
          if ($page.variables.paramModoCRU === 'C') {

            //revisar que condicionPago y condicionesPago en GridIn_1_2 si no están seteados viajen por default en ""
            if (typeof $page.variables.requestQ71PO_AltaVoucherSinMatching.condicionPago === 'undefined') {
              $page.variables.requestQ71PO_AltaVoucherSinMatching.condicionPago = " ";
            }
            // Validar el array gridin_1_2
            if (Array.isArray($page.variables.requestQ71PO_AltaVoucherSinMatching.GridIn_1_2)) {
              $page.variables.requestQ71PO_AltaVoucherSinMatching.GridIn_1_2.forEach(item => {
                if (typeof item.condicionesPago === 'undefined') {
                  item.condicionesPago = " ";
                }
              });
            }

            //si primer item de gridin_1_2 tiene vacio areaimpuesto tipoimpuesto e importebruto en "" descarto el item 0 que es el que use de referencia para el resto
            if (
              $page.variables.requestQ71PO_AltaVoucherSinMatching.GridIn_1_2.length > 1 &&
              $page.variables.requestQ71PO_AltaVoucherSinMatching.GridIn_1_2[0].areaImpuesto === "" &&
              $page.variables.requestQ71PO_AltaVoucherSinMatching.GridIn_1_2[0].tipoImpuesto === "" &&
              $page.variables.requestQ71PO_AltaVoucherSinMatching.GridIn_1_2[0].importeBruto === ""
            ) {

              $page.variables.requestQ71PO_AltaVoucherSinMatching.GridIn_1_2.shift();  // Elimina el primer elemento (posición 0) descartable y que se uso de referencia para el resto
              $page.variables.requestQ71PO_AltaVoucherSinMatching.GridIn_1_6.shift();  // Elimina el primer elemento (posición 0) descartable y que se uso de referencia para el resto

            }

            //CHEQUEO QUE GRIDIN_1_2 ESTÉ CONSISTENTE CON AREA Y TIPO DE IMPUESTO CARGADO POR ITEM
            //a su vez, en caso de venir en voucherMatrizFn la opción de invertirSigno, aplicar sobre los importes de GridIn_1_2

            const integridadAltaVoucherGridIn_1_2 = await ActionUtils.forEach($page.variables.requestQ71PO_AltaVoucherSinMatching.GridIn_1_2, async (itemIntegridadAltaVoucherGridIn_1_2, indexIntegridadAltaVoucherGridIn_1_2) => {

              if (itemIntegridadAltaVoucherGridIn_1_2.areaImpuesto === undefined || itemIntegridadAltaVoucherGridIn_1_2.tipoImpuesto === undefined || itemIntegridadAltaVoucherGridIn_1_2.areaImpuesto === '' || itemIntegridadAltaVoucherGridIn_1_2.tipoImpuesto === '') {
                altaOActualizarOK = false;

                const notificarErrorIntegridadAltaVoucherGridIn_1_2 = await Actions.callChain(context, {
                  chain: 'application:notificar_error',
                  params: {
                    codigo: 'falta-configuracion-areas-fiscales',
                    modoVisualizacion: 'persist',
                  },
                });

                const notificarError2 = await Actions.callChain(context, {
                  chain: 'application:notificar_error',
                  params: {
                    descripcion: 'Revise Comprobante Item con Importes' + itemIntegridadAltaVoucherGridIn_1_2.importeBruto + ' ' + itemIntegridadAltaVoucherGridIn_1_2.importeFiscal + ' ' + itemIntegridadAltaVoucherGridIn_1_2.importeImponible,
                    titulo: 'Atención! Falta configuración de impuestos. Datos Adicionales',
                    tipoNotificacion: 'error',
                    modoVisualizacion: 'persist',
                  },
                });
              }

              //este invertir signo inicialmente es para Notas de Crédito, pero viene definido por voucherMatrizFn según funcionalidad y tipoDocARCA
              //basicamente si tiene este flag se invierte el signo hacia Jde en el Alta del Voucher, de todos los importes
              if ($page.variables.uniqueVoucherMatrizFn.invertirSigno) {

                if ($page.functions.parseFormattedNumber(itemIntegridadAltaVoucherGridIn_1_2.importeBruto || "0") !== 0) {
                  itemIntegridadAltaVoucherGridIn_1_2.importeBruto = $page.functions.formatNumberToStringAuto(
                    $page.functions.parseFormattedNumber(itemIntegridadAltaVoucherGridIn_1_2.importeBruto) * -1,
                    $application.variables.preferenciasUsuarioJde.decimalFormat
                  );
                }

                if ($page.functions.parseFormattedNumber(itemIntegridadAltaVoucherGridIn_1_2.importeFiscal || "0") !== 0) {
                  itemIntegridadAltaVoucherGridIn_1_2.importeFiscal = $page.functions.formatNumberToStringAuto(
                    $page.functions.parseFormattedNumber(itemIntegridadAltaVoucherGridIn_1_2.importeFiscal) * -1,
                    $application.variables.preferenciasUsuarioJde.decimalFormat
                  );
                }

                if ($page.functions.parseFormattedNumber(itemIntegridadAltaVoucherGridIn_1_2.importeImponible || "0") !== 0) {
                  itemIntegridadAltaVoucherGridIn_1_2.importeImponible = $page.functions.formatNumberToStringAuto(
                    $page.functions.parseFormattedNumber(itemIntegridadAltaVoucherGridIn_1_2.importeImponible) * -1,
                    $application.variables.preferenciasUsuarioJde.decimalFormat
                  );
                }

              }


            });

            //20250929 jmp mif forzar que vayan vacíos "" los conceptos de retencion
            //ya que JDE por defecto si no ponés nada en los conceptos toma los del proveedor. 
            //Es decir nosotros estabamos duplicando esa lógica que ya x defecto hace JDE.            
            if ($page.variables.paramModoCRU === 'C' && $page.variables.uniqueVoucherMatrizFn?.usaMatrizRetenciones === false) {
              $page.variables.requestQ71PO_AltaVoucherSinMatching.GridIn_1_6.forEach(item => {
                item.conceptoIVA = "";
                item.conceptoGanancias = "";
                item.conceptoOriIIBB = "";
                item.conceptoDstIIBB = "";
                item.conceptoContratistas = "";
                item.conceptoSUSS = "";
                item.condGanancias = "";
                item.convenioIIBB = "";
              });
            }

            if (altaOActualizarOK === undefined || altaOActualizarOK !== false) {
              $page.variables.requestQ71PO_AltaVoucherSinMatching.token = $application.variables.token;
              responseQ71PO_AltaVoucherSinMatching = await Actions.callRest(context, {
                endpoint: 'GatewayPortal/postQ71PO_AltaVoucherSinMatching',
                body: $page.variables.requestQ71PO_AltaVoucherSinMatching,
              });
              await Actions.callChain(context, {
                chain: 'application:verificar_respuesta_jdeError',
                params: {
                  error: !responseQ71PO_AltaVoucherSinMatching.ok,
                  funcion: 'AltaVoucherSinMatching',
                  funcionalidad: $page.variables.paramFuncionalidadMenu,
                  tokenExpirado: responseQ71PO_AltaVoucherSinMatching.body.tokenExpirado !== undefined ? responseQ71PO_AltaVoucherSinMatching.body.tokenExpirado : false,
                  status: responseQ71PO_AltaVoucherSinMatching.status,
                },
              });
            }
            if ((altaOActualizarOK === undefined || altaOActualizarOK !== false) && responseQ71PO_AltaVoucherSinMatching.ok && responseQ71PO_AltaVoucherSinMatching.body.success === true) {

              $page.variables.erroresJDE = responseQ71PO_AltaVoucherSinMatching &&
                responseQ71PO_AltaVoucherSinMatching.body &&
                Array.isArray(responseQ71PO_AltaVoucherSinMatching.body.errorsList) &&
                responseQ71PO_AltaVoucherSinMatching.body.errorsList.length > 0 ?
                responseQ71PO_AltaVoucherSinMatching.body.errorsList : [];

              if (responseQ71PO_AltaVoucherSinMatching?.body?.errorJde === true
                && (
                  !responseQ71PO_AltaVoucherSinMatching.body ||
                  !responseQ71PO_AltaVoucherSinMatching.body.data ||
                  !responseQ71PO_AltaVoucherSinMatching.body.data.tipoDocumento ||
                  responseQ71PO_AltaVoucherSinMatching.body.data.tipoDocumento.toString().trim() === '' ||
                  !responseQ71PO_AltaVoucherSinMatching.body.data.nroDocumento ||
                  responseQ71PO_AltaVoucherSinMatching.body.data.nroDocumento.toString().trim() === ''
                )
              ) {
                const guardarLog = await Actions.callChain(context, {
                  chain: 'application:guardar_log',
                  params: {
                    funcionalidad: $page.variables.paramFuncionalidadMenu,
                    accion: 'ERROR_VALIDACION',
                    pagina: $flow.currentPage,
                    proveedor: $application.variables.user.esProveedor,
                    suscriptorId: $application.variables.suscriptor.id,
                    usuario: $application.variables.user.ociUser,
                    numeroAn8: $application.variables.user.numeroAn8,
                    roles: $application.variables.userRoles.userRolesSt,
                    observaciones: "AltaVoucherSinMatching",
                    transaccion: $page.variables.requestQ71PO_AltaVoucherSinMatching.tipoDocumentoTransaccionAFIP + '-'
                      + $page.variables.requestQ71PO_AltaVoucherSinMatching.letraFactura + '-'
                      + $page.variables.requestQ71PO_AltaVoucherSinMatching.nroFactura,
                  },
                });
              }
              else {

                altaOActualizarOK = true;
                //datos para mostrar en dlgConfirmacionAlta
                $page.variables.responseReducidoQ71PO_AltaVoucherSinMatching.ciaDocumento = $page.variables.requestQ71PO_AltaVoucherSinMatching.compania;
                $page.variables.responseReducidoQ71PO_AltaVoucherSinMatching.tipoDocumento = responseQ71PO_AltaVoucherSinMatching.body.data.tipoDocumento;
                $page.variables.responseReducidoQ71PO_AltaVoucherSinMatching.nroDocumento = responseQ71PO_AltaVoucherSinMatching.body.data.nroDocumento.toString();
                $page.variables.responseReducidoQ71PO_AltaVoucherSinMatching.nroFactura = responseQ71PO_AltaVoucherSinMatching.body.data.nroFactura;


                try {
                  //iniciarWF
                  const buscarConstanteP0006_Version = await Actions.callChain(context, {
                    chain: 'application:buscar_constante',
                    params: {
                      constante: 'P0006_Version'
                    },
                  });
                  if (buscarConstanteP0006_Version.existe === true) {
                    $page.variables.consP0006_Version = buscarConstanteP0006_Version.valor;
                  }

                  const buscarConstanteAP_AUTORIZANTE_NRO_CC = await Actions.callChain(context, {
                    chain: 'application:buscar_constante',
                    params: {
                      constante: 'AP_AUTORIZANTE_NRO_CC'
                    },
                  });
                  if (buscarConstanteAP_AUTORIZANTE_NRO_CC.existe === true) {
                    $page.variables.consAP_AUTORIZANTE_NRO_CC = buscarConstanteAP_AUTORIZANTE_NRO_CC.valor;
                  }

                  //buscoUbicaciones y obtengo valor para luego utilizar en WF
                  //Inicio override seguridad activada y roles
                  let seguridadCC = $application.variables.seguridadCCActivada;
                  let rolesJDEcc = $application.variables.userRoles.rolesJDE;

                  if (seguridadCC && $application.variables.seguridadCCItemsDD.MCU !== undefined && $application.variables.seguridadCCItemsDD.MCU !== "Y") {
                    seguridadCC = false;
                    rolesJDEcc = [];
                  }
                  //Fin override seguridad activada y roles
                  const responseQ71PO_BuscarUbicaciones = await Actions.callRest(context, {
                    endpoint: 'GatewayPortal/postQ71PO_BuscarUbicaciones',
                    body: {
                      "token": $application.variables.token,
                      "P0006_Version": $page.variables.consP0006_Version,
                      "company": $page.variables.requestQ71PO_AltaVoucherSinMatching.compania,
                      "description": "",
                      "businessUnitType": "",
                      "businessUnit": ($page.variables.requestQ71PO_AltaVoucherSinMatching.GridData.length === 1) ? $page.variables.requestQ71PO_AltaVoucherSinMatching.GridData[0].nroCuenta.split('.')[0] : $page.variables.datosProveedorLight.data.cuentaGastoDefault.split('.')[0],

                      "rolesJDE": rolesJDEcc,
                      "seguridadInclusiva": $application.variables.seguridadCCInclusiva,
                      "seguridadCCActivada": seguridadCC
                    }
                  });
                  await Actions.callChain(context, {
                    chain: 'application:verificar_respuesta_jdeError',
                    params: {
                      error: !responseQ71PO_BuscarUbicaciones.ok,
                      funcion: 'BuscarUbicaciones',
                      funcionalidad: $page.variables.paramFuncionalidadMenu,
                      tokenExpirado: responseQ71PO_BuscarUbicaciones.body.tokenExpirado !== undefined ? responseQ71PO_BuscarUbicaciones.body.tokenExpirado : false,
                      status: responseQ71PO_BuscarUbicaciones.status,
                    },
                  });
                  if (responseQ71PO_BuscarUbicaciones.body.success === true) {

                    $page.variables.autorizanteWF = responseQ71PO_BuscarUbicaciones.body?.rowset?.[0]?.categoryCode?.[$page.variables.consAP_AUTORIZANTE_NRO_CC] ?? '';

                  }
                  else {

                    const guardarLog = await Actions.callChain(context, {
                      chain: 'application:guardar_log',
                      params: {
                        funcionalidad: $page.variables.paramFuncionalidadMenu,
                        accion: 'FALLA_FUNCION',
                        pagina: $application.currentPage.id,
                        proveedor: $application.variables.user.esProveedor,
                        suscriptorId: $application.variables.suscriptor.id,
                        usuario: $application.variables.user.ociUser,
                        numeroAn8: $application.variables.user.numeroAn8,
                        roles: $application.variables.userRoles.userRolesSt,
                        observaciones: 'Q71PO_BuscarUbicaciones',
                      },
                    });
                  }


                  //gmonto en usd
                  let montoTotalComprobanteEnUSD = 0;
                  if ($page.variables.requestQ71PO_AltaVoucherSinMatching.codigoMoneda === $page.variables.consMonedaCaucion) {
                    montoTotalComprobanteEnUSD = $page.variables.totalComprobanteDetalle;
                  } else {

                    //según tipo moneda <> ARS entonces seteo tipo de cambio acorde a usd destino para el control de caution
                    // Obtener la fecha actual y setearla por default para pedir tipo de cambio
                    const fechaActual = new Date();
                    // Formatear la fecha actual en formato ISO "yyyy-MM-dd"
                    const anio = fechaActual.getFullYear();
                    const mes = String(fechaActual.getMonth() + 1).padStart(2, '0'); // Mes empieza en 0, por eso sumamos 1
                    const dia = String(fechaActual.getDate()).padStart(2, '0');

                    const responseQ71PO_BuscarTipoCambio = await Actions.callRest(context, {
                      endpoint: 'GatewayPortal2/postQ71PO_BuscarTipoCambio',
                      body: {
                        "token": $application.variables.token,
                        "monedaOrigen": $page.variables.requestQ71PO_AltaVoucherSinMatching.codigoMoneda, //"ARS",
                        "monedaDestino": $page.variables.consMonedaCaucion, //"USD",
                        "fecha": $page.functions.formatDateString($page.variables.requestQ71PO_AltaVoucherSinMatching.fechaFactura, $application.variables.preferenciasUsuarioJde.simpleDateFormat)

                      },
                    });
                    await Actions.callChain(context, {
                      chain: 'application:verificar_respuesta_jdeError',
                      params: {
                        error: !responseQ71PO_BuscarTipoCambio.ok,
                        funcion: 'BuscarTipoCambio',
                        funcionalidad: $page.variables.paramFuncionalidadMenu || '',
                        tokenExpirado: responseQ71PO_BuscarTipoCambio.body.tokenExpirado !== undefined ? responseQ71PO_BuscarTipoCambio.body.tokenExpirado : false,
                        status: responseQ71PO_BuscarTipoCambio.status,
                      },
                    });
                    if (responseQ71PO_BuscarTipoCambio.body.success === true) {

                      //si metodoConv = Y
                      //  importe transacción = importe ingresado  X tcMultiplicador
                      //sino 
                      //  importe transaccion = importe ingresado / tcMultiplicador
                      if (responseQ71PO_BuscarTipoCambio.body.rowset[0].metodoConv === 'Y') {
                        //calculo el valor al cambio si tipo cambio es mayor a 0 y si no mantengo el mismo valor multiplicando por 1
                        montoTotalComprobanteEnUSD = $page.variables.totalComprobanteDetalle * responseQ71PO_BuscarTipoCambio.body.rowset[0].tcMultiplicador;
                      } else {
                        //calculo el valor al cambio si tipo cambio es mayor a 0 y si no mantengo el mismo valor dividiendolo por 1
                        montoTotalComprobanteEnUSD = $page.variables.totalComprobanteDetalle / (responseQ71PO_BuscarTipoCambio.body.rowset[0].tcMultiplicador !== 0 ? responseQ71PO_BuscarTipoCambio.body.rowset[0].tcMultiplicador : 1);
                      }
                    }

                  }

                  await Actions.callChain(context, {
                    chain: 'application:iniciar_wf',
                    params: {
                      accionJDE: 'A',
                      accionWF: 'A',
                      ciaDocumento: $page.variables.requestQ71PO_AltaVoucherSinMatching.compania,
                      funcionalidadPortal: $page.variables.paramFuncionalidadMenu,
                      importeTotal: $page.variables.requestQ71PO_AltaVoucherSinMatching.codigoMoneda === $application.variables.selectedCompany.moneda ? $page.variables.totalComprobanteDetalle : 0, //20260618 jmp sacar hardcoded //'ARS' ? $page.variables.totalComprobanteDetalle : 0,
                      importeMonedaExtranjera: $page.variables.requestQ71PO_AltaVoucherSinMatching.codigoMoneda !== $application.variables.selectedCompany.moneda ? $page.variables.totalComprobanteDetalle : 0, //20260618 jmp sacar hardcoded //'ARS' ? $page.variables.totalComprobanteDetalle : 0,
                      importeTotalDolares: montoTotalComprobanteEnUSD,
                      mailProveedor: mailProveedor,
                      modulo: '04',
                      nroAprobador: '',
                      nroDocumento: responseQ71PO_AltaVoucherSinMatching.body.data.nroDocumento,
                      nroProveedor: $page.variables.requestQ71PO_AltaVoucherSinMatching.nroProveedor,
                      tipoDocumento: responseQ71PO_AltaVoucherSinMatching.body.data.tipoDocumento,
                      usuarioOriginadorTR: $application.variables.user.numeroAn8,
                      usuarioOriginadorWF: $application.variables.user.numeroAn8,
                      usuarioSolicitante: $page.variables.requestQ71PO_AltaVoucherSinMatching.aprobador,
                      cdCatMaestro: $page.variables.autorizanteWF,
                      ruteoVoucher: $page.variables.wfRuteoVoucher,
                      flag01: '1',
                      flag02: '1',
                      flag03: '1',
                      flag04: '0',
                      flag06: $page.variables.flagDetalleGuardar.includes('R_W') ? '1' : '0',
                    },
                  });
                }
                catch (error) {
                  $page.variables.flagConsoleLog && $page.variables.flagConsoleLog && console.log('logjmp', 'frag-cru-detalle-voucher actRecalculaTotalesDetalleComprobanteMatching error', error.message);
                }

              } //errorJde false y nro nuevo voucher generado

            }

          }
          //modoCRU U Update ActualizarVoucher
          else if (['U', 'P'].includes($page.variables.paramModoCRU)) {

            //CHEQUEO QUE GRIDIN_1_2 ESTÉ CONSISTENTE CON AREA Y TIPO DE IMPUESTO CARGADO POR ITEM
            const integridadActualizarVoucherGridIn_1_2 = await ActionUtils.forEach($page.variables.requestQ71PO_ActualizarVoucher.GridIn_1_2, async (itemIntegridadActualizarVoucherGridIn_1_2, indexIntegridadActualizarVoucherGridIn_1_2) => {

              if (itemIntegridadActualizarVoucherGridIn_1_2.areaImpuesto === undefined || itemIntegridadActualizarVoucherGridIn_1_2.tipoImpuesto === undefined || itemIntegridadActualizarVoucherGridIn_1_2.areaImpuesto === '' || itemIntegridadActualizarVoucherGridIn_1_2.tipoImpuesto === '') {
                altaOActualizarOK = false;

                const notificarErrorIntegridadActualizarVoucherGridIn_1_2 = await Actions.callChain(context, {
                  chain: 'application:notificar_error',
                  params: {
                    codigo: 'falta-configuracion-areas-fiscales',
                    modoVisualizacion: 'persist',
                  },
                });

                const notificarError3 = await Actions.callChain(context, {
                  chain: 'application:notificar_error',
                  params: {
                    titulo: 'Atención! Falta configuración de impuestos. Datos Adicionales',
                    descripcion: 'Revise Comprobante Item con Importes' + itemIntegridadActualizarVoucherGridIn_1_2.importeBruto + ' ' + itemIntegridadActualizarVoucherGridIn_1_2.importeFiscal + ' ' + itemIntegridadActualizarVoucherGridIn_1_2.importeImponible,
                    tipoNotificacion: 'error',
                    modoVisualizacion: 'persist',
                  },
                });


              }

            });

            if (altaOActualizarOK === undefined || altaOActualizarOK !== false) {

              $page.variables.requestQ71PO_ActualizarVoucher.actualizarTodo = ($page.variables.requestQ71PO_ActualizarVoucher.actualizarTodo && $page.variables.requestQ71PO_ActualizarVoucher.actualizarGL) ? true : false; //true si actualizarTodo en true (cambios en determinados lados de cabecera) y actualizarGL en true (aplica cambios en items contable)

              $page.variables.requestQ71PO_ActualizarVoucher.token = $application.variables.token;
              responseQ71PO_ActualizarVoucher = await Actions.callRest(context, {
                endpoint: 'GatewayPortal/postQ71PO_ActualizarVoucher',
                body: $page.variables.requestQ71PO_ActualizarVoucher,
              });
              await Actions.callChain(context, {
                chain: 'application:verificar_respuesta_jdeError',
                params: {
                  error: !responseQ71PO_ActualizarVoucher.ok,
                  funcion: 'ActualizarVoucher',
                  funcionalidad: $page.variables.paramFuncionalidadMenu,
                  tokenExpirado: responseQ71PO_ActualizarVoucher.body.tokenExpirado !== undefined ? responseQ71PO_ActualizarVoucher.body.tokenExpirado : false,
                  status: responseQ71PO_ActualizarVoucher.status,
                },
              });

            }

            if ((altaOActualizarOK === undefined || altaOActualizarOK !== false) && responseQ71PO_ActualizarVoucher.body.success === true) {

              $page.variables.erroresJDE = responseQ71PO_ActualizarVoucher &&
                responseQ71PO_ActualizarVoucher.body &&
                Array.isArray(responseQ71PO_ActualizarVoucher.body.errorsList) &&
                responseQ71PO_ActualizarVoucher.body.errorsList.length > 0 ?
                responseQ71PO_ActualizarVoucher.body.errorsList : [];

              if (responseQ71PO_ActualizarVoucher?.body?.errorJde === true
                && (
                  !responseQ71PO_ActualizarVoucher.body ||
                  !responseQ71PO_ActualizarVoucher.body.data ||
                  !responseQ71PO_ActualizarVoucher.body.data.tipoDocumento ||
                  responseQ71PO_ActualizarVoucher.body.data.tipoDocumento.toString().trim() === '' ||
                  !responseQ71PO_ActualizarVoucher.body.data.nroDocumento ||
                  responseQ71PO_ActualizarVoucher.body.data.nroDocumento.toString().trim() === ''
                )
              ) {
                const guardarLog = await Actions.callChain(context, {
                  chain: 'application:guardar_log',
                  params: {
                    funcionalidad: $page.variables.paramFuncionalidadMenu,
                    accion: 'ERROR_VALIDACION',
                    pagina: $flow.currentPage,
                    proveedor: $application.variables.user.esProveedor,
                    suscriptorId: $application.variables.suscriptor.id,
                    usuario: $application.variables.user.ociUser,
                    numeroAn8: $application.variables.user.numeroAn8,
                    roles: $application.variables.userRoles.userRolesSt,
                    observaciones: "ActualizarVoucher",
                    transaccion: $page.variables.requestQ71PO_ActualizarVoucher.ciaDocumento + '-'
                      + $page.variables.requestQ71PO_ActualizarVoucher.tipoDocumento + '-'
                      + $page.variables.requestQ71PO_ActualizarVoucher.nroDocumento.toString(),
                  },
                });
              }
              else {

                //si luego tiene que hacer un volver a actualizar lo revalua
                altaOActualizarOK = true;

                /*
                a) solo matriz, no items no tax area
                pusieron modelo
  
                actualiza contabilidad
                actualizarTodo false
                actualizarGl true
  
                actualiza datos voucher que no impactan en distribución contable
                actualizarTodo false
                acautlizarGL false
  
  
                b) sin asiento modelo
  
                actualiza datos voucher que no impactan en distribución contable
                actualizarTodo false
                acautlizarGL false
  
                c) cambian algo en items que impacta en importe a distribuir
                actualizarTodo true
                actualizarGL false
  
                actualizarTodo false
                actualizarGl true
                */

                if (altaOActualizarOK) {
                  //datos para mostrar en dlgConfirmacionAltaOActualizar
                  $page.variables.responseReducidoQ71PO_AltaVoucherSinMatching.ciaDocumento = $page.variables.requestQ71PO_ActualizarVoucher.ciaDocumento; //20250728 jmp mif modi forzada  responseQ71PO_ActualizarVoucher.body.data.ciaDocumento;
                  $page.variables.responseReducidoQ71PO_AltaVoucherSinMatching.tipoDocumento = responseQ71PO_ActualizarVoucher.body.data.tipoDocumento;
                  $page.variables.responseReducidoQ71PO_AltaVoucherSinMatching.nroDocumento = responseQ71PO_ActualizarVoucher.body.data.nroDocumento.toString();
                  $page.variables.responseReducidoQ71PO_AltaVoucherSinMatching.nroFactura = responseQ71PO_ActualizarVoucher.body.data.nroFactura;

                  //reseteo flag de modificacion / impacta sobre btn aprobar de  accionar wf en principio
                  $page.variables.flagModified = false;

                }
              } //errorJde false y nro voucher generado

            }
          }

          //realizar resto de pasos según sea Alta o Update respecto de adjuntar archivos e informar lo realizado
          if (altaOActualizarOK === true) { //realizar resto de pasos según sea Alta o Update respecto de adjuntar archivos e informar lo realizado
            //Subir pdf de la factura (función Q71PO_SubirAdjunto)
            //Si es anticipo subir pdf póliza de caución (función Q71PO_SubirAdjunto) si la hubiera
            //subir a jde archivos seleccionados como adjuntos

            $page.variables.requestQ71PO_SubirAdjunto.tipoDocumento = $page.variables.paramModoCRU === 'C' ? responseQ71PO_AltaVoucherSinMatching.body.data.tipoDocumento : responseQ71PO_ActualizarVoucher.body.data.tipoDocumento;
            $page.variables.requestQ71PO_SubirAdjunto.nroDocumento = $page.variables.paramModoCRU === 'C' ? responseQ71PO_AltaVoucherSinMatching.body.data.nroDocumento : responseQ71PO_ActualizarVoucher.body.data.nroDocumento;;
            $page.variables.requestQ71PO_SubirAdjunto.incluirMetadatos = true;
            $page.variables.requestQ71PO_SubirAdjunto.itemPagoDocumento = '001'; //sfxOrden; //es itempagodocumento pero no viene en response
            $page.variables.requestQ71PO_SubirAdjunto.ciaDocumento = $page.variables.paramModoCRU === 'C' ? $page.variables.requestQ71PO_AltaVoucherSinMatching.compania : $page.variables.requestQ71PO_ActualizarVoucher.ciaDocumento;
            $page.variables.requestQ71PO_SubirAdjunto.numeroProveedor = $page.variables.paramModoCRU === 'C' ? $page.variables.requestQ71PO_AltaVoucherSinMatching.nroProveedor : responseQ71PO_ActualizarVoucher.body.data.nroProveedor;
            $page.variables.requestQ71PO_SubirAdjunto.token = $application.variables.token;

            $page.variables.requestQ71PO_SubirAdjunto.metadatos.estadoObjeto = '';
            $page.variables.requestQ71PO_SubirAdjunto.metadatos.fechaVigenciaDesde = '';
            $page.variables.requestQ71PO_SubirAdjunto.metadatos.fechaVigenciaHasta = '';
            $page.variables.requestQ71PO_SubirAdjunto.metadatos.nroVehiculo = '';
            $page.variables.requestQ71PO_SubirAdjunto.metadatos.descripcion = '';
            $page.variables.requestQ71PO_SubirAdjunto.metadatos.codigosCategoria = [
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              ""
            ];
            $page.variables.requestQ71PO_SubirAdjunto.tipoObjeto = $page.variables.consVisualizarAdjuntosTipoObjeto;

            const buscarConstanteADJUNTOS_VISIBLES_PORTAL_CC = await Actions.callChain(context, {
              chain: 'application:buscar_constante',
              params: {
                constante: 'ADJUNTOS_VISIBLES_PORTAL_CC',
              },
            });
            if (buscarConstanteADJUNTOS_VISIBLES_PORTAL_CC.existe === true) {

              $page.variables.consADJUNTOS_VISIBLES_PORTAL_CC = buscarConstanteADJUNTOS_VISIBLES_PORTAL_CC.valor;


              //como ya obtuve la posición del array de códigosCategoria ahora busco el valor a setear
              const buscarConstanteADJUNTOS_VISIBLES_PORTAL_COD = await Actions.callChain(context, {
                chain: 'application:buscar_constante',
                params: {
                  constante: 'ADJUNTOS_VISIBLES_PORTAL_COD',
                },
              });
              if (buscarConstanteADJUNTOS_VISIBLES_PORTAL_COD.existe === true) {

                $page.variables.consADJUNTOS_VISIBLES_PORTAL_COD = buscarConstanteADJUNTOS_VISIBLES_PORTAL_COD.valor;

                //asigno en la posición del Array CC, el valor de COD
                $page.variables.requestQ71PO_SubirAdjunto.metadatos.codigosCategoria[$page.variables.consADJUNTOS_VISIBLES_PORTAL_CC] = $page.variables.consADJUNTOS_VISIBLES_PORTAL_COD;
              }

            } else {

              const notificarError5 = await Actions.callChain(context, {
                chain: 'application:notificar_error',
                params: {
                  codigo: 'constantes-adjuntos-not-found',
                },
              });

            }

            const buscarConstanteADJUNTOS_AP_TIPO_CC = await Actions.callChain(context, {
              chain: 'application:buscar_constante',
              params: {
                constante: 'ADJUNTOS_AP_TIPO_CC',
              },
            });
            if (buscarConstanteADJUNTOS_AP_TIPO_CC.existe === true) {

              $page.variables.consADJUNTOS_AP_TIPO_CC = buscarConstanteADJUNTOS_AP_TIPO_CC.valor;

            }

            $page.variables.requestQ71PO_SubirAdjunto.metadatos.mokey = $page.variables.requestQ71PO_AltaVoucherSinMatching.compania + '|' + $page.variables.responseReducidoQ71PO_AltaVoucherSinMatching.tipoDocumento + '|' + $page.variables.responseReducidoQ71PO_AltaVoucherSinMatching.nroDocumento + '|' + '001'; //20250728 jmp mif modi forzada  $page.variables.responseReducidoQ71PO_AltaVoucherSinMatching.ciaDocumento + '|' + $page.variables.responseReducidoQ71PO_AltaVoucherSinMatching.tipoDocumento + '|' + $page.variables.responseReducidoQ71PO_AltaVoucherSinMatching.nroDocumento + '|' + '001';

            if ($page.variables.listaArchivosSeleccionadosComprobante.length > 0) {
              //PRIMERO SUBIR ADJUNTO COMPMROBANTE VOUCHER
              //asigno en la posición del Array CC, el valor de TIPO 'VOUCHER'
              $page.variables.requestQ71PO_SubirAdjunto.metadatos.codigosCategoria[$page.variables.consADJUNTOS_AP_TIPO_CC] = 'VOUCHER';

              const resultSubirArchivosComprobanteConfirmarDespacho = await Actions.callChain(context, {
                chain: 'application:subir_archivos',
                params: {
                  inParamListaArchivos: $page.variables.listaArchivosSeleccionadosComprobante,
                  inParamRequestSubirAdjunto: $page.variables.requestQ71PO_SubirAdjunto,
                },
              }, { id: 'actSubirArchivosComprobanteConfirmarDespacho' });
              if (resultSubirArchivosComprobanteConfirmarDespacho.error === true) {
                $page.variables.flagConsoleLog && console.log('logjmp', 'action application:subir_archivos VOUCHER falló', $page.variables.requestQ71PO_SubirAdjunto);
              }
            }
            if ($page.variables.listaArchivosSeleccionadosCaucion.length > 0) {
              //AHORA SUBIR ADJUNTO COMPMROBANTE CAUCION si hay
              //asigno en la posición del Array CC, el valor de TIPO 'CAUCION'
              $page.variables.requestQ71PO_SubirAdjunto.metadatos.codigosCategoria[$page.variables.consADJUNTOS_AP_TIPO_CC] = 'CAUCION';

              const resultSubirArchivosCaucionConfirmarDespacho = await Actions.callChain(context, {
                chain: 'application:subir_archivos',
                params: {
                  inParamListaArchivos: $page.variables.listaArchivosSeleccionadosCaucion,
                  inParamRequestSubirAdjunto: $page.variables.requestQ71PO_SubirAdjunto,
                },
              }, { id: 'actSubirArchivosCaucionConfirmarDespacho' });
              if (resultSubirArchivosCaucionConfirmarDespacho.error === true) {
                $page.variables.flagConsoleLog && console.log('logjmp', 'action application:subir_archivos CAUCION falló', $page.variables.requestQ71PO_SubirAdjunto);
              }
            }
            if ($page.variables.listaArchivosSeleccionadosOtros.length > 0) {
              //AHORA SUBIR ADJUNTO COMPMROBANTE OTROS si hay
              //asigno en la posición del Array CC, el valor de TIPO 'OTROS'
              $page.variables.requestQ71PO_SubirAdjunto.metadatos.codigosCategoria[$page.variables.consADJUNTOS_AP_TIPO_CC] = 'OTROS';

              const resultSubirArchivosOtrosConfirmarDespacho = await Actions.callChain(context, {
                chain: 'application:subir_archivos',
                params: {
                  inParamListaArchivos: $page.variables.listaArchivosSeleccionadosOtros,
                  inParamRequestSubirAdjunto: $page.variables.requestQ71PO_SubirAdjunto,
                },
              }, { id: 'actSubirArchivosOtrosConfirmarDespacho' });
              if (resultSubirArchivosOtrosConfirmarDespacho.error === true) {
                $page.variables.flagConsoleLog && console.log('logjmp', 'action application:subir_archivos OTROS falló', $page.variables.requestQ71PO_SubirAdjunto);

              }
            }

            $page.variables.listaArchivosSeleccionadosComprobante = [];
            $page.variables.listaArchivosSeleccionadosCaucion = [];
            $page.variables.listaArchivosSeleccionadosOtros = [];

            //Notificar que hay una nueva factura para revisar al solicitante (función Q71PO_EnviarMail)

            //guarda en tabla log (cadena acción global guardar-log)
            //LOG success AltaVoucherSinMatching o ActualizarVoucher
            const guardarLog = await Actions.callChain(context, {
              chain: 'application:guardar_log',
              params: {
                funcionalidad: $page.variables.paramFuncionalidadMenu,
                accion: 'SUCCESS_FUNCION',
                pagina: $flow.currentPage,
                proveedor: $application.variables.user.esProveedor,
                suscriptorId: $application.variables.suscriptor.id,
                usuario: $application.variables.user.ociUser,
                numeroAn8: $application.variables.user.numeroAn8,
                roles: $application.variables.userRoles.userRolesSt,
                observaciones: $variables.paramModoCRU === "C" ? "AltaVoucherSinMatching" : "ActualizarVoucher",
                transaccion: $page.variables.responseReducidoQ71PO_AltaVoucherSinMatching.ciaDocumento + '-' + $page.variables.responseReducidoQ71PO_AltaVoucherSinMatching.tipoDocumento + '-' + $page.variables.responseReducidoQ71PO_AltaVoucherSinMatching.nroDocumento,
              },
            });

            //dialog de despachos confirmados y navigate to pur-consultar-despachos-pendientes
            await Actions.callComponentMethod(context, {
              selector: '#dlgAltaVoucherConfirmado',
              method: 'open',
            });

          } else {

            const notificarErrorFalloAltaActualizarVoucher = await Actions.callChain(context, {
              chain: 'application:notificar_error',
              params: {
                codigo: 'fallo-alta-actualizar-voucher',
                modoVisualizacion: 'persist',
              },
            });

            $page.variables.erroresJDE = ($page.variables.paramModoCRU === 'C') ? responseQ71PO_AltaVoucherSinMatching?.body?.errorsList : responseQ71PO_ActualizarVoucher?.body?.errorsList;

            //LOG falla 
            const guardarLog = await Actions.callChain(context, {
              chain: 'application:guardar_log',
              params: {
                funcionalidad: $page.variables.paramFuncionalidadMenu,
                accion: 'FALLA_FUNCION',
                pagina: $flow.currentPage,
                proveedor: $application.variables.user.esProveedor,
                suscriptorId: $application.variables.suscriptor.id,
                usuario: $application.variables.user.ociUser,
                numeroAn8: $application.variables.user.numeroAn8,
                roles: $application.variables.userRoles.userRolesSt,
                observaciones: $variables.paramModoCRU === "C" ? "AltaVoucherSinMatching" : "ActualizarVoucher",
              },
            });
          }
        }
      }

      $page.variables.flagGuardar = true;
      $page.variables.flagPageLoading = false;

    }

  }

  return actBtnGuardar;
});