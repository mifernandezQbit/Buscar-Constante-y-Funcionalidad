define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class flagDetalleGuardarListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:string,value:string}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      //'A_E' Alicuotas sin configurar en item de iva credito fiscal
      //'P_E' Error Matriz de Percepción
      //'R_W' Warning Matriz Retenciones
      $page.variables.flagBooleanDetalleGuardar = ( event.value.includes('P_E') || (['U', 'P'].includes($page.variables.paramModoCRU) && event.value.includes('R_W')) || event.value.includes('A_E') ) ? false : true;

    }
  }

  return flagDetalleGuardarListener;
});
