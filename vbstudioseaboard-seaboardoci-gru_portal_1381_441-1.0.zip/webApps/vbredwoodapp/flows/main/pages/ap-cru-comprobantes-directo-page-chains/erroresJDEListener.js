define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class erroresJDEListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:object[],value:object[]}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      //marco modificacion / se sale esta marca con el Guardar en modoCRU U
      //evalua que el array erroresJDE se haya modificado pero que además no esté vacío y... que haga falta cambiar flagModified
      if ( event.value !== undefined && event.value.length > 0 && !$page.variables.flagModified && ['U', 'P'].includes($page.variables.paramModoCRU) ){ 
        $page.variables.flagModified = true;
      }

    }
  }

  return erroresJDEListener;
});
