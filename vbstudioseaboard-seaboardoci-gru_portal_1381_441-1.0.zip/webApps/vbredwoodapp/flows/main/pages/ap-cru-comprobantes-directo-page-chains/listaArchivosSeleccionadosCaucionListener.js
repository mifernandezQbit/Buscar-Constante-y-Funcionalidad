define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class listaArchivosSeleccionadosCaucionListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:application:archivoAdjunto[],value:application:archivoAdjunto[]}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;


    }
  }

  return listaArchivosSeleccionadosCaucionListener;
});
