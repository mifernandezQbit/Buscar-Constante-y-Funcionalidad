define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class totalComprobanteDetalleListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:number,value:number}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application } = context;

      //Aviso si el Comprobante a Cargar o Editar es una Nota de Crédito

      if ($page.variables.paramModoCRU !== 'R' && $page.variables.paramFuncionalidadMenu.includes("NC") && !isNaN(event.value) && event.value >= 0) {

        const notificarError = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            codigo: 'montos-negativos',
          },
        });

      }



      /*
      ##### Tipo de cambio para monto de caución

      Tipo de cambio para calcular monto de caución si se ingresa en moneda diferente a USD (tomar código de moneda dolar de una constante, no hard codear)
      - buscar tipo de cambio
        - Origen moneda dólar
        - Destino moneda transacción
      - Si metodoConv = Y
            importe transacción = importe ingresado  X tcMultiplicador
        sino 
            importe transaccion = importe ingresado / tcMultiplicador
      */

      //si el valor de totalComprobanteDetalle es mayor a 0 y es igual a totalComprobanteCabecera
      //debo en base al codigoMoneda y el tipo de cambio, calcular el valor de la variable auxiliar para saber si tengo o no que requerir o no el adjunto de poliza de caucion
      //si codigo moneda es usd entonces grabo valor de totalComprobante en variable montototalComprobanteControlCaucion
      //si codigo moneda es <> usd entonces debo cargarle el valor valor totalcomprobante segun tipocambio

      if ($page.variables.paramModoCRU !== 'R' && !isNaN(event.value) && event.value > 0) {
        //grabo el monto en usd
        if ($page.variables.requestQ71PO_AltaVoucherSinMatching.codigoMoneda === $page.variables.consMonedaCaucion) { //'USD') {
          $page.variables.montoTotalComprobanteControlCaucion = event.value; //$page.variables.totalComprobanteDetalle;
        } else {

          //según tipo moneda <> ARS entonces seteo tipo de cambio acorde a usd destino para el control de caution
          // Obtener la fecha actual y setearla por default para pedir tipo de cambio
          const fechaActual = new Date();
          // Formatear la fecha actual en formato ISO "yyyy-MM-dd"
          const anio = fechaActual.getFullYear();
          const mes = String(fechaActual.getMonth() + 1).padStart(2, '0'); // Mes empieza en 0, por eso sumamos 1
          const dia = String(fechaActual.getDate()).padStart(2, '0');

          const responseQ71PO_BuscarTipoCambio = await Actions.callRest(context, {
            endpoint: 'GatewayPortal2/postQ71PO_BuscarTipoCambio',
            body: {
              "token": $application.variables.token,
              "monedaOrigen": $page.variables.requestQ71PO_AltaVoucherSinMatching.codigoMoneda, //"ARS",
              "monedaDestino": $page.variables.consMonedaCaucion, //"USD",
              "fecha": $page.functions.formatDateString($page.variables.requestQ71PO_AltaVoucherSinMatching.fechaFactura, $application.variables.preferenciasUsuarioJde.simpleDateFormat)

            },
          });
          await Actions.callChain(context, {
            chain: 'application:verificar_respuesta_jdeError',
            params: {
              error: !responseQ71PO_BuscarTipoCambio.ok,
              funcion: 'BuscarTipoCambio',
              funcionalidad: $page.variables.paramFuncionalidadMenu || '',
              tokenExpirado: responseQ71PO_BuscarTipoCambio.body.tokenExpirado !== undefined ? responseQ71PO_BuscarTipoCambio.body.tokenExpirado : false,
              status:responseQ71PO_BuscarTipoCambio.status,
            },
          });
          if (responseQ71PO_BuscarTipoCambio.body.success === true) {

            //si metodoConv = Y
            //  importe transacción = importe ingresado  X tcMultiplicador
            //sino 
            //  importe transaccion = importe ingresado / tcMultiplicador
            if (responseQ71PO_BuscarTipoCambio.body.rowset[0].metodoConv === 'Y') {
              //calculo el valor al cambio si tipo cambio es mayor a 0 y si no mantengo el mismo valor multiplicando por 1
              $page.variables.montoTotalComprobanteControlCaucion = event.value * responseQ71PO_BuscarTipoCambio.body.rowset[0].tcMultiplicador; 

            } else {
              //calculo el valor al cambio si tipo cambio es mayor a 0 y si no mantengo el mismo valor dividiendolo por 1
              $page.variables.montoTotalComprobanteControlCaucion = event.value / (responseQ71PO_BuscarTipoCambio.body.rowset[0].tcMultiplicador !== 0 ? responseQ71PO_BuscarTipoCambio.body.rowset[0].tcMultiplicador : 1); 
            }
          }

        }

      }

    }
  }

  return totalComprobanteDetalleListener;
});
