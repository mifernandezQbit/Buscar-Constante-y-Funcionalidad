define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class requestQ71PO_AltaVoucherSinMatching_compareListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:typRequestQ71PO_AltaVoucherSinMatching,value:typRequestQ71PO_AltaVoucherSinMatching}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;

     
    }
  }

  return requestQ71PO_AltaVoucherSinMatching_compareListener;
});
