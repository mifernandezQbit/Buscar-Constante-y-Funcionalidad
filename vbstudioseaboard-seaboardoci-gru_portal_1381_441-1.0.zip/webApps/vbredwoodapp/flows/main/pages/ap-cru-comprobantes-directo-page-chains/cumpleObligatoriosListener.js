define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class cumpleObligatoriosListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:boolean,value:boolean}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application } = context;

    }
  }

  return cumpleObligatoriosListener;
});
