define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class totalComprobanteCabeceraListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:number,value:number}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const raw = event?.value;
      const num = (typeof raw === 'string')
        ? (raw.trim() === '' ? NaN : Number(raw))
        : (typeof raw === 'number' ? raw : NaN);

      if (!Number.isNaN(num) && num === 0) {
        $page.variables.totalComprobanteDetalle = 0;
      }

    }
  }

  return totalComprobanteCabeceraListener;
});
