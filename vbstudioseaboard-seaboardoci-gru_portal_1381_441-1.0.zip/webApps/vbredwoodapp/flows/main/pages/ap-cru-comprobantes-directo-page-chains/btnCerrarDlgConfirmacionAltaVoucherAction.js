define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class btnCerrarDlgConfirmacionAltaVoucherAction extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      $page.variables.resetear = true;

      //si suben OK entonces
      //dialog de despachos confirmados y navigate to pur-consultar-despachos-pendientes
      const dlgAltaVoucherConfirmadoClose = await Actions.callComponentMethod(context, {
        selector: '#dlgAltaVoucherConfirmado',
        method: 'close',
      });

      //vuelvo a pantalla anterior generalmente a home, pero si es modo Create, dependerá del menú WF para ver a donde va
      if ($page.variables.paramModoCRU === 'C') {
        //Una vez ingresado el voucher, si lo ingresó el usuario y es él mismo el solicitante que lo va a revisar que automáticamente redireccione a trabajar solicitudes wf.
        //Para saber si es usuario ver variable global user y comparar numeroAn8 del user con el numero del solicitante elegido. 
        if ($application.variables.user.esProveedor === false && $page.variables.requestQ71PO_AltaVoucherSinMatching.aprobador === $application.variables.user.numeroAn8) {

          // NAVIGATE TO trabajar solicitudes wf
          const toTrabajarSolicitudesWf = await Actions.navigateToPage(context, {
            page: 'trabajar-solicitudes-wf',
            params: {
              funcionalidad: 'TRABAJAR_WF',
            },
          });

        } else {

          if ($application.variables.user.esProveedor === true) {
            // NAVIGATE TO trabajar solicitudes wf
            const toConsultarFacturas = await Actions.navigateToPage(context, {
              page: 'ap-consultar-facturas',
              params: {
                paramTipoObjetoChat: $page.variables.paramTipoObjetoChat,
                paramVersionJDE: $page.variables.paramVersionJDE,
                //paramTitulo : 'Consultar Facturas',
              },
            });

          } else {

            //vuelvo a la page desde donde accedí
            await Actions.navigateBack(context, {
            });

          }

        }
      }

    }
  }

  return btnCerrarDlgConfirmacionAltaVoucherAction;
});
