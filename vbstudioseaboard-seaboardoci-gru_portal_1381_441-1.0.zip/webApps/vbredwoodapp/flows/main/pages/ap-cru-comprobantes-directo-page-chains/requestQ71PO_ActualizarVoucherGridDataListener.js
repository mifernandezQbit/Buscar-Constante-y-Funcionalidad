define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class requestQ71PO_ActualizarVoucherGridDataListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:typRequestQ71PO_ActualizarVoucherItemGridData[],value:typRequestQ71PO_ActualizarVoucherItemGridData[]}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      //marco modificacion / se sale esta marca con el Guardar en modoCRU U
      if (!$page.variables.flagPageLoading && !$page.variables.flagModified && ['U', 'P'].includes($page.variables.paramModoCRU)) {
        $page.variables.flagModified = true;
      }

    }
  }

  return requestQ71PO_ActualizarVoucherGridDataListener;
});
