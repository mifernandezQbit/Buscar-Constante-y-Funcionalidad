define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class cabeceraFlagListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:boolean,value:boolean}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      //si frag cabecera se terminó de cargar el flagCabecera se pone en true, y en consecuencia hay que desactivar progressbar de pageLoading
      if (event.value === true) {
          $page.variables.flagPageLoading = false; //desactiva progressbar

      }
    }
  }

  return cabeceraFlagListener;
});
