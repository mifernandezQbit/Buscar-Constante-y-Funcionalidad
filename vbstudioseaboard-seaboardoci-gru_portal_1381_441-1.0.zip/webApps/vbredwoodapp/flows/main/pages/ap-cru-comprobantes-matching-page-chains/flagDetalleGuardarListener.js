define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class flagDetalleGuardarListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:string,value:string}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $page.variables.flagBooleanDetalleGuardar = ( event.value.includes('P_E') || event.value.includes('A_E') ) ? false : true; //|| event.value.includes('R_W')) ? false : true;
      $page.variables.flagModified = ( event.value.includes('P_E') || event.value.includes('R_W')) ? true : false;

    }
  }

  return flagDetalleGuardarListener;
});
