define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class menuOpcionesActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.menuId 
     */
    async run(context, { menuId }) {
      const { $page, $flow, $application } = context;

      switch (menuId) {

        case 'ADJUNTAR_ARCHIVOS':

          const callFunctionMostrarDrawerAdjuntarArchivosOtros = await this.generarRandomOtros(context);
          $page.variables.mostrarDrawerAdjuntarArchivosOtros = callFunctionMostrarDrawerAdjuntarArchivosOtros; //$page.variables.mostrarDrawerAdjuntarArchivosOtros = callFunctionMostrarDrawerAdjuntarArchivosOtros;

          //const guardarLog = 
          await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              funcionalidad: $page.variables.paramFuncionalidadMenu,
              accion: 'ADJUNTAR_ARCHIVOS',
              pagina: $flow.currentPage,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
              transaccion: '', 
              roles: $application.variables.userRoles.userRolesSt,
            },
          });
          break;

        case 'VER_MENSAJES':

          //reseteo el condicional que despliega o no el drawer de visualizar adjuntos
          await Actions.resetVariables(context, {
            variables: [
              '$page.variables.mostrarDrawerMensajes',
            ],
          });

          const callFunctionMostrarDrawerMensajes = await this.generarRandomMensajes(context);
          $page.variables.mostrarDrawerMensajes = callFunctionMostrarDrawerMensajes;

          //const guardarLog = 
          await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              funcionalidad: $page.variables.paramFuncionalidadMenu,
              accion: 'VER_MENSAJES',
              pagina: $flow.currentPage,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
              transaccion: [[$page.variables.responseQ71PO_BuscarVoucher.data.ciaDocumento]] + '|' + [[$page.variables.responseQ71PO_BuscarVoucher.data.tipoDocumento]] + '|' + [[$page.variables.responseQ71PO_BuscarVoucher.data.nroDocumento]] + '|' + '001',
              roles: $application.variables.userRoles.userRolesSt,
            },
          });

          break;

        case 'VER_ADJUNTOS':

          const buscarConstanteADJUNTOS_VISIBLES_PORTAL_CC = await Actions.callChain(context, {
            chain: 'application:buscar_constante',
            params: {
              constante: 'ADJUNTOS_VISIBLES_PORTAL_CC',
            },
          });
          if (buscarConstanteADJUNTOS_VISIBLES_PORTAL_CC.existe === true) {

            $page.variables.consADJUNTOS_VISIBLES_PORTAL_CC = buscarConstanteADJUNTOS_VISIBLES_PORTAL_CC.valor;

            //como ya obtuve la posición del array de códigosCategoria ahora busco el valor a setear
            const buscarConstanteADJUNTOS_VISIBLES_PORTAL_COD = await Actions.callChain(context, {
              chain: 'application:buscar_constante',
              params: {
                constante: 'ADJUNTOS_VISIBLES_PORTAL_COD',
              },
            });
            if (buscarConstanteADJUNTOS_VISIBLES_PORTAL_COD.existe === true) {

              $page.variables.consADJUNTOS_VISIBLES_PORTAL_COD = buscarConstanteADJUNTOS_VISIBLES_PORTAL_COD.valor;
            
              //asigno en la posición del Array CC, el valor de COD
              $page.variables.visualizarAdjuntosCodigosCategoria[$page.variables.consADJUNTOS_VISIBLES_PORTAL_CC] = $page.variables.consADJUNTOS_VISIBLES_PORTAL_COD;

              $page.variables.visualizarAdjuntosCodigosCategoria[6] = 'OTROS';             
             
            } 

          } else {

            const notificarError = await Actions.callChain(context, {
              chain: 'application:notificar_error',
              params: {
                codigo: 'constantes-adjuntos-not-found',
              },
            });

          } 

          $page.variables.visualizarAdjuntosMoKey = $page.variables.responseQ71PO_BuscarVoucher.data.ciaDocumento + '|' + $page.variables.responseQ71PO_BuscarVoucher.data.tipoDocumento + '|' + $page.variables.responseQ71PO_BuscarVoucher.data.nroDocumento + '|' + '001';

          //reseteo el condicional que despliega o no el drawer de visualizar adjuntos
          await Actions.resetVariables(context, {
            variables: [
              '$page.variables.mostrarDrawerVerAdjuntos',
            ],
          });
          
          //activa el despliegue del drawer de visualizar adjuntos
          const callFunctionMostrarDrawerVerAdjuntos = await this.generarRandomVerAdjuntos(context);
          $page.variables.mostrarDrawerVerAdjuntos = callFunctionMostrarDrawerVerAdjuntos;

          //log
          const guardarLogVerAdjuntos = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              funcionalidad: $page.variables.paramFuncionalidadMenu,
              accion: 'VER_ADJUNTOS',
              pagina: $flow.currentPage,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
              transaccion: '', //TODO: agregar lo necesario para que ande [[$ page. variables.responseQ71PO_BuscarVoucherSinMatching.data.ciaDocumento]]+'|'+[[$ page. variables.responseQ71PO_BuscarVoucherSinMatching.data.tipoDocumento]]+'|'+[[$ page. variables.responseQ71PO_BuscarVoucherSinMatching.data.nroDocumento]]+'|'+'001',
              roles: $application.variables.userRoles.userRolesSt,
            },
          });
                     
          break;
      }
    }

    /**
    * @param {Object} context
    */
    async generarRandomOtros(context) {
      const { $page, $flow, $application } = context;
      let random = Math.random(1, 10);
      return random;
    }
    async generarRandomVerAdjuntos(context) {
      const { $page, $flow, $application } = context;
      let random = Math.random(1, 10);
      return random;
    }
    async generarRandomMensajes(context) {
      const { $page, $flow, $application } = context;
      let random = Math.random(1, 10);
      return random;
    }

  }

  return menuOpcionesActionChain;
});