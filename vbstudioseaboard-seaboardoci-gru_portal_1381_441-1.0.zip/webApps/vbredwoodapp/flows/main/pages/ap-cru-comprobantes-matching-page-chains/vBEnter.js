define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vBEnter extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const buscarConstanteLOG_ON = await Actions.callChain(context, {
        chain: 'application:buscar_constante',
        params: {
          constante: 'LOG_ON'
        },
      });
      if (buscarConstanteLOG_ON.existe === true) {
        $page.variables.flagConsoleLog = buscarConstanteLOG_ON.valor === "1";
      }

      $page.variables.flagPageLoading = true;

      $page.variables.flagVBEnter = false;


//verifico permiso funcionalidad si parámetro no indica permitido
if ($page.variables.paramUsoPermitido) {
   $page.variables.permisoFuncionalidad.existe = true;
   $page.variables.permisoFuncionalidad.tipoObjetoChat = "FC";
}
else {
      $page.variables.permisoFuncionalidad = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: $page.variables.paramFuncionalidadMenu,
        },
      });
};

      if ($page.variables.permisoFuncionalidad.existe === false) {
        //entra si NO tienen permisos a ej. "INGRESAR_FACTURA_DIRECTA" ...pueden ser varias las opciones de comprobantes
        // Guardar Log de Acceso Restrigido y Notificación Visual

        const guardarLog = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'INTENTO_INGRESO_NH',
            funcionalidad: $page.variables.paramFuncionalidadMenu,
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
          },
        });

        await Actions.navigateToPage(context, {
          page: 'acceso-no-autorizado',
        });
        // prevenir la navegación
        event.preventDefault();

      } else {

        const guardarLog = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'INGRESA',
            funcionalidad: $page.variables.paramFuncionalidadMenu,
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
          },
        });

        //busco VoucherMatrizFn para la funcionalidad seleccionada
        //filtro por funcionaidad descripcion para encontrar id funcionalidad
        const responseGetAllFuncionalidad = await Actions.callRest(context, {
          endpoint: 'businessObjects/getall_Funcionalidad',
          uriParams: {
            q: "funcionalidad ='" + $page.variables.paramFuncionalidadMenu + "' and suscriptorID = '" + $application.variables.suscriptor.id + "'",
          },

        });

        if (responseGetAllFuncionalidad.body.count !== 0) {

          //filtro por funcionaidad
          const responseGetAllVoucherMatrizFn = await Actions.callRest(context, {
            endpoint: 'businessObjects/getall_VoucherMatrizFn',
            uriParams: {
              q: "funcionalidadPortal ='" + responseGetAllFuncionalidad.body.items[0].id + "' and suscriptorID = '" + $application.variables.suscriptor.id + "'",
              limit: 1000,
            },
          });

          if (responseGetAllVoucherMatrizFn.body.count !== 0) {

            $page.variables.voucherMatrizFn = responseGetAllVoucherMatrizFn.body.items;

          }
        }

        const buscarConstanteP0411_Version = await Actions.callChain(context, {
          chain: 'application:buscar_constante',
          params: {
            constante: 'P0411_VersionMatch'
          },
        });
        if (buscarConstanteP0411_Version.existe === true) {
          $page.variables.consP0411_Version = buscarConstanteP0411_Version.valor;
        }


        //modoCRU CREATE o READ forzada
        switch ($page.variables.paramModoCRU) {
          case 'C':
            //Create

            if (!$application.variables.user.ciaDefault || $application.variables.user.ciaDefault === "") {
              const buscarConstanteCia = await Actions.callChain(context, {
                chain: 'application:buscar_constante',
                params: {
                  constante: 'DEFAULT_CO'
                },
              });
              if (buscarConstanteCia.existe === true) {
                $application.variables.selectedCompany.company = buscarConstanteCia.valor;
                $page.variables.requestQ71PO_AltaVoucherConMatchOC.compania = buscarConstanteCia.valor;
              }
            }

            //tomo el valor que viene por parametro de la page y si no el de la constante de bo
            $page.variables.requestQ71PO_AltaVoucherConMatchOC.P0411_Version = $page.variables.paramVersionJDE;


            $page.variables.requestQ71PO_AltaVoucherConMatchOC.recepcion = ($page.variables.paramFuncionalidadMenu === 'INGRESAR_FACTURA_MATCH_OC' || $page.variables.paramFuncionalidadMenu === 'INGRESAR_FACTURA_MATCH_OS') ? '1' : '';

            $page.variables.requestQ71PO_AltaVoucherConMatchOC.totalFactura = '0';

            let auxOrdenMatchSelected = {
              nroProveedor: '',
              ciaOrden: '',
              nroOrden: '',
              tipoOrden: '',
              jurisdiccionOrigen: '',
              conceptoFacturado: '',

            };
            $page.variables.ordenMatchSelected = auxOrdenMatchSelected;

            break;

          case 'P':
          case 'R':
          case 'U':

            const buscarConstanteP0911_Version = await Actions.callChain(context, {
              chain: 'application:buscar_constante',
              params: {
                constante: 'P0911_Version'
              },
            });
            if (buscarConstanteP0911_Version.existe === true) { 
              $page.variables.consP0911_Version = buscarConstanteP0911_Version.valor;
            }

            $page.variables.uniqueVoucherMatrizFn = $page.variables.voucherMatrizFn.filter(item => item.tipoDocARCA === $page.variables.paramTipoComprobante)[0];

            //uniqueWorkflowMatriz
            //filtro por suscriptorID, funcionalidadPortal, accionJDE y accionWF

            const responseGetUniqueWorkflowMatriz = await Actions.callRest(context, {
              endpoint: 'businessObjects/getall_WorkflowMatriz',
              uriParams: {
                q: "funcionalidadPortal ='" + ($page.variables.uniqueVoucherMatrizFn?.funcionalidadPortal || 0) + "' and suscriptorID = '" + $application.variables.suscriptor.id + "' and accionJDE = '" + $page.variables.paramModoCRU + "' and accionWF = '" + $page.variables.actionWf + "'",
                limit: 1000,
              },
            });

            if (responseGetUniqueWorkflowMatriz.body.count !== 0) {

              $page.variables.uniqueWorkflowMatriz = responseGetUniqueWorkflowMatriz.body.items;

            }

            //Inicio overrride seguridad activada y roles
            let seguridadCC = $application.variables.seguridadCCActivada;
            let rolesJDECC = $application.variables.userRoles.rolesJDE;
            if (seguridadCC && $application.variables.seguridadCCItemsDD.MCU !== undefined && $application.variables.seguridadCCItemsDD.MCU !=='Y'){
              seguridadCC = false;
              rolesJDECC = [];
            }

            const responseQ71PO_BuscarVoucher = await Actions.callRest(context, {
              endpoint: 'GatewayPortal/postQ71PO_BuscarVoucher',
              body:
              {
                "ciaDocumento": $page.variables.paramCiaDocumento,
                "nroDocumento": $page.variables.paramNroDocumento,
                "nroProveedor": $page.variables.paramNroProveedor,
                "P0911_Version": $page.variables.consP0911_Version,
                "P0411_Version": (
                  $page.variables.uniqueVoucherMatrizFn && $page.variables.uniqueVoucherMatrizFn.versionP0411.trim() !== ""
                    ? $page.variables.uniqueVoucherMatrizFn.versionP0411
                    : $page.variables.consP0411_Version
                ),
                "tipoDocumento": $page.variables.paramTipoDocumento,
                "creadoDesde": "M", //lo necesita Matching

                "rolesJDE": rolesJDECC,
                "seguridadInclusiva": $application.variables.seguridadCCInclusiva,
                "seguridadCCActivada": seguridadCC,

                "token": $application.variables.token
              }
            });

            await Actions.callChain(context, {
              chain: 'application:verificar_respuesta_jdeError',
              params: {
                error: !responseQ71PO_BuscarVoucher.ok,
                funcion: 'BuscarVoucher',
                funcionalidad: $page.variables.paramFuncionalidadMenu,
                tokenExpirado: responseQ71PO_BuscarVoucher.body.tokenExpirado !== undefined ? responseQ71PO_BuscarVoucher.body.tokenExpirado : false,
               status:responseQ71PO_BuscarVoucher.status,
              },
            });

            //frag errores aún con response sucess si hay errores + fuerza disabled frag wf devolver y aprobar si corresponde
            $page.variables.erroresJDE = responseQ71PO_BuscarVoucher?.body?.errorsList;
            if ( $page.variables.erroresJDE !== undefined && $page.variables.erroresJDE.length > 0 ){ 
              $page.variables.flagModified = true;
            }

            //20260708 jmp levanto seguridadOK
            $page.variables.seguridadOK = (!$application.variables.user.esProveedor && $application.variables.seguridadCCActivada) ? responseQ71PO_BuscarVoucher.body?.seguridadOK : true ;
            $page.variables.seguridadOKGuardar = $page.variables.seguridadOK;
            $page.variables.flagPageLoading = $page.variables.seguridadOK ? true : false; //termina el progress porque la seguridadOK está en false y no va a dejar avanzar en la carga

            if ($page.variables.seguridadOK && responseQ71PO_BuscarVoucher.ok && responseQ71PO_BuscarVoucher.body.success === true) {

              //datos para mostrar response BuscarVoucherSinMatching
              //ASIGNO COMPLETO, CONTIENE DATA Y ROWSET (AÚN SIN USO)
              $page.variables.responseQ71PO_BuscarVoucher = responseQ71PO_BuscarVoucher.body;

              $page.variables.totalComprobanteCabecera = $page.variables.responseQ71PO_BuscarVoucher.data.totalImputable;

              if ($page.variables.paramModoCRU === 'U' || $page.variables.paramModoCRU === 'P') {
                //20260707 jmp agrega control de Seguridad por Centro de Costos
                if (!!$page.variables.responseQ71PO_BuscarVoucher.data?.nroProveedor
                    && !$application.variables.user.esProveedor ){
                  $page.variables.seguridadOKGuardar = await Actions.callChain(context, {
                    chain: 'application:validar_seguridad',
                    params: {
                      accionJDE: 'C', //como paramModoCRU es U o P, entonces accionJDE lo seteo en 'C' hange
                      funcionalidad: $page.variables.paramFuncionalidadMenu,
                      //funcionalidadID: undefined,
                      valor: $page.variables.responseQ71PO_BuscarVoucher.data?.unidadNegocio,
                      nroProveedor: $page.variables.responseQ71PO_BuscarVoucher.data?.nroProveedor,
                    },
                  });
                }
              }

              //jmp 20251118 se cargan los datos básicos requeridos para hacer el ActualizarVoucherMatching, asociado con lo requerido para el avance de wf para FL
              if ($page.variables.paramModoCRU === 'U') {

                $page.variables.requestQ71PO_ActualizarVoucherMatching = {
                  token: $application.variables.token,
                  aprobador: $page.variables.responseQ71PO_BuscarVoucher.data.aprobador,
                  ciaDocumento: $page.variables.responseQ71PO_BuscarVoucher.data.ciaDocumento,
                  nroDocumento: $page.variables.responseQ71PO_BuscarVoucher.data.nroDocumento,
                  tipoDocumento: $page.variables.responseQ71PO_BuscarVoucher.data.tipoDocumento,

                  clasif01: $page.variables.responseQ71PO_BuscarVoucher.data.codClasificacion01,
                  clasif02: $page.variables.responseQ71PO_BuscarVoucher.data.codClasificacion02,
                  clasif03: $page.variables.responseQ71PO_BuscarVoucher.data.codClasificacion03,
                  clasif04: $page.variables.responseQ71PO_BuscarVoucher.data.codClasificacion04,
                  clasif05: $page.variables.responseQ71PO_BuscarVoucher.data.codClasificacion05,

                  flagActCodigos: '0', //por default cuando solo se pueda llegar a actualizar jurisdiccion cabecera en matching actuaizando gridin_1_6, si se modificar algo de gridin_1_2 tomará valor '1'
                };

                $page.variables.requestQ71PO_ActualizarVoucherMatching.GridIn_1_2 = [];
                $page.variables.requestQ71PO_ActualizarVoucherMatching.GridIn_1_6 = [];
                $page.variables.responseQ71PO_BuscarVoucher.rowset.forEach((item, index) => {
                  let newRequestQ71PO_ActualizarVoucherMatchingItemGridIn_1_2 = {
                    claseLM: "", //lo paso vacio para que no se actualice
                    conidicionesPago: "", //OJO!!!! es conidicionesPagos... mal escrito en el request
                    observacion: item.observaciones,
                  };
                  $page.variables.requestQ71PO_ActualizarVoucherMatching.GridIn_1_2.push(newRequestQ71PO_ActualizarVoucherMatchingItemGridIn_1_2);
                  let newRequestQ71PO_ActualizarVoucherMatchingItemGridIn_1_6 = {
                    sfxDocumento: item.detalleLocalizacion.sfxDocumento,
                    jurisdDstIIBB: item.detalleLocalizacion.jurisdiccionIIBBDestino, 
                    jurisdOriIIBB: item.detalleLocalizacion.jurisdiccionIIBBOrigen, 
                  };
                  $page.variables.requestQ71PO_ActualizarVoucherMatching.GridIn_1_6.push(newRequestQ71PO_ActualizarVoucherMatchingItemGridIn_1_6);
                });

                $page.variables.auxRequestQ71PO_ActualizarVoucherMatching = { ...$page.variables.requestQ71PO_ActualizarVoucherMatching };

              }

              //PRIMERO BUSCO EL ADJUNTO COMPROBANTE ASOCIADO EN PDF Y PREVISUALIZO... Y SI ESO OK, ASIGNO Y DESPLIEGO CABECERA Y LUEGO DETALLE
              $page.variables.requestQ71PO_BuscarAdjuntos.token = $application.variables.token;
              $page.variables.requestQ71PO_BuscarAdjuntos.ciaDocumento = $page.variables.paramCiaDocumento;
              $page.variables.requestQ71PO_BuscarAdjuntos.depositoPlanif = '';
              $page.variables.requestQ71PO_BuscarAdjuntos.descripcion = '';
              $page.variables.requestQ71PO_BuscarAdjuntos.estadoObjeto = '';
              $page.variables.requestQ71PO_BuscarAdjuntos.fechaVigenciaDesde = '';
              $page.variables.requestQ71PO_BuscarAdjuntos.fechaVigenciaHasta = '';
              $page.variables.requestQ71PO_BuscarAdjuntos.idPago = '';
              $page.variables.requestQ71PO_BuscarAdjuntos.incluirMetadatos = true;
              $page.variables.requestQ71PO_BuscarAdjuntos.itermPagoDocumento = '001'; 
              $page.variables.requestQ71PO_BuscarAdjuntos.moKey = $page.variables.paramCiaDocumento + '|' + $page.variables.paramTipoDocumento + '|' + $page.variables.paramNroDocumento + '|' + '001';
              $page.variables.requestQ71PO_BuscarAdjuntos.nroCarga = '';
              $page.variables.requestQ71PO_BuscarAdjuntos.nroDocumento = $page.variables.paramNroDocumento;
              $page.variables.requestQ71PO_BuscarAdjuntos.nroLinea = '';
              $page.variables.requestQ71PO_BuscarAdjuntos.nroVehiculo = '';
              $page.variables.requestQ71PO_BuscarAdjuntos.numeroProveedor = $page.variables.paramNroProveedor;
              $page.variables.requestQ71PO_BuscarAdjuntos.secuencia = ''; 
              $page.variables.requestQ71PO_BuscarAdjuntos.tipoDocumento = $page.variables.paramTipoDocumento;
              $page.variables.requestQ71PO_BuscarAdjuntos.tipoObjeto = $page.variables.consVisualizarAdjuntosTipoObjeto;

              $page.variables.requestQ71PO_BuscarAdjuntos.codigosCategoria = [
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                ""
              ];
              const buscarConstanteADJUNTOS_VISIBLES_PORTAL_CC = await Actions.callChain(context, {
                chain: 'application:buscar_constante',
                params: {
                  constante: 'ADJUNTOS_VISIBLES_PORTAL_CC',
                },
              });
              if (buscarConstanteADJUNTOS_VISIBLES_PORTAL_CC.count !== 0) {

                $page.variables.consADJUNTOS_VISIBLES_PORTAL_CC = buscarConstanteADJUNTOS_VISIBLES_PORTAL_CC.valor;

                //como ya obtuve la posición del array de códigosCategoria ahora busco el valor a setear
                const buscarConstanteADJUNTOS_VISIBLES_PORTAL_COD = await Actions.callChain(context, {
                  chain: 'application:buscar_constante',
                  params: {
                    constante: 'ADJUNTOS_VISIBLES_PORTAL_COD',
                  },
                });
                if (buscarConstanteADJUNTOS_VISIBLES_PORTAL_COD.count !== 0) {

                  $page.variables.consADJUNTOS_VISIBLES_PORTAL_COD = buscarConstanteADJUNTOS_VISIBLES_PORTAL_COD.valor;

                  //asigno en la posición del Array CC, el valor de COD
                  $page.variables.requestQ71PO_BuscarAdjuntos.codigosCategoria[$page.variables.consADJUNTOS_VISIBLES_PORTAL_CC] = $page.variables.consADJUNTOS_VISIBLES_PORTAL_COD;
                }

              } else {

                const notificarError = await Actions.callChain(context, {
                  chain: 'application:notificar_error',
                  params: {
                    codigo: 'constantes-adjuntos-not-found',
                  },
                });

              }

              const buscarConstanteADJUNTOS_AP_TIPO_CC = await Actions.callChain(context, {
                chain: 'application:buscar_constante',
                params: {
                  constante: 'ADJUNTOS_AP_TIPO_CC',
                },
              });
              if (buscarConstanteADJUNTOS_AP_TIPO_CC.count !== 0) {

                $page.variables.consADJUNTOS_AP_TIPO_CC = buscarConstanteADJUNTOS_AP_TIPO_CC.valor;

              }

              //PARA PODER DIFERENCIAR Y PODER BUSCAR ADJUNTOS LUEGO AL MOMENTO DE CONSULTAR UN VOUCHER DETERMINADO
              //asigno en la posición del Array CC, el valor de TIPO 'VOUCHER'
              $page.variables.requestQ71PO_BuscarAdjuntos.codigosCategoria[$page.variables.consADJUNTOS_AP_TIPO_CC] = 'VOUCHER';

              const responseQ71PO_BuscarAdjuntos = await Actions.callRest(context, {
                endpoint: 'GatewayPortal/postQ71PO_BuscarAdjuntos',
                body: $page.variables.requestQ71PO_BuscarAdjuntos,
              });
              await Actions.callChain(context, {
                chain: 'application:verificar_respuesta_jdeError',
                params: {
                  error: !responseQ71PO_BuscarAdjuntos.ok,
                  funcion: 'BuscarAdjuntos',
                  funcionalidad: $page.variables.paramFuncionalidadMenu,
                  tokenExpirado: responseQ71PO_BuscarAdjuntos.body.tokenExpirado !== undefined ? responseQ71PO_BuscarAdjuntos.body.tokenExpirado : false,
                   status:responseQ71PO_BuscarAdjuntos.status,
                },
              });
              if (responseQ71PO_BuscarAdjuntos.ok && responseQ71PO_BuscarAdjuntos.body.message.success === true) {
                /*     
                //LOG success postQ71PO_BuscarAdjuntos
                const guardarLog = await Actions.callChain(context, {
                  chain: 'application:guardar_log',
                  params: {
                    funcionalidad: $page.variables.paramFuncionalidadMenu,
                    accion: 'SUCCESS_FUNCION',
                    pagina: $flow.currentPage,
                    proveedor: $application.variables.user.esProveedor,
                    suscriptorId: $application.variables.suscriptor.id,
                    usuario: $application.variables.user.ociUser,
                    numeroAn8: $application.variables.user.numeroAn8,
                    roles: $application.variables.userRoles.userRolesSt,
                    observaciones: 'BuscarAdjuntos Voucher',
                  },
                });
                */

                //descargo adjunto voucher si lo trae si no marco log y continuo
                if (responseQ71PO_BuscarAdjuntos.body.message.rowset.length > 0) {
                  const responseQ71PO_DescargarAdjunto = await Actions.callRest(context, {
                    endpoint: 'GatewayPortal/postQ71PO_DescargarAdjunto',
                    body: {
                      "token": $application.variables.token,
                      "moType": responseQ71PO_BuscarAdjuntos.body.message.rowset[0].moType,
                      "sequence": responseQ71PO_BuscarAdjuntos.body.message.rowset[0].secuencia,
                      "objectName": responseQ71PO_BuscarAdjuntos.body.message.rowset[0].nombreObjeto,
                      "moKey": [responseQ71PO_BuscarAdjuntos.body.message.rowset[0].clave], //["00001|PV|1605|001"], 
                      "formName": "",
                      "version": ""
                    },
                  });
                  await Actions.callChain(context, {
                    chain: 'application:verificar_respuesta_jdeError',
                    params: {
                      error: !responseQ71PO_DescargarAdjunto.ok,
                      funcion: 'DescargarAdjunto',
                      funcionalidad: $page.variables.paramFuncionalidadMenu,
                      tokenExpirado: responseQ71PO_DescargarAdjunto.body.tokenExpirado !== undefined ? responseQ71PO_DescargarAdjunto.body.tokenExpirado : false,
                        status:responseQ71PO_DescargarAdjunto.status,
                    },
                  });
                  if (responseQ71PO_DescargarAdjunto.body !== "") {

                    //LOG success postQ71PO_DescargarAdjunto
                    const guardarLogDescargarAdjunto = await Actions.callChain(context, {
                      chain: 'application:guardar_log',
                      params: {
                        funcionalidad: $page.variables.paramFuncionalidadMenu,
                        accion: 'SUCCESS_FUNCION',
                        pagina: $flow.currentPage,
                        proveedor: $application.variables.user.esProveedor,
                        suscriptorId: $application.variables.suscriptor.id,
                        usuario: $application.variables.user.ociUser,
                        numeroAn8: $application.variables.user.numeroAn8,
                        roles: $application.variables.userRoles.userRolesSt,
                        observaciones: 'DescargarAdjunto Voucher',
                      },
                    });

                    //vuelvo contenido del metadato del archivo descargado en la variable para utilizar en el preview del voucher
                    //uso variable auxiliar para setear los 2 valores necesarios y que no salte el evento del chain cuando no termina de setearse el archivo y nombre
                    let auxArchivoAdjuntoVOUCHER = {
                      "archivo": responseQ71PO_DescargarAdjunto.body,
                      "nombreArchivo": responseQ71PO_BuscarAdjuntos.body.message.rowset[0].nombreArchivo,
                      "tipoAdjunto": "application/pdf",
                    };
                    $page.variables.archivoAdjuntoVOUCHER = auxArchivoAdjuntoVOUCHER;

                  } else {

                    //LOG success postQ71PO_DescargarAdjunto
                    const guardarLogDescargarAdjunto = await Actions.callChain(context, {
                      chain: 'application:guardar_log',
                      params: {
                        funcionalidad: $page.variables.paramFuncionalidadMenu,
                        accion: 'FALLA_FUNCION',
                        pagina: $flow.currentPage,
                        proveedor: $application.variables.user.esProveedor,
                        suscriptorId: $application.variables.suscriptor.id,
                        usuario: $application.variables.user.ociUser,
                        numeroAn8: $application.variables.user.numeroAn8,
                        roles: $application.variables.userRoles.userRolesSt,
                        observaciones: 'DescargarAdjunto Voucher',
                      },
                    });
                  }

                } else {
                  //falla Buscar Adjuntos porque no trae adjuntos aunque no es sucess el response
                  $page.variables.archivoAdjuntoVOUCHER = '';

                  //LOG falla BuscarAdjuntos
                  const guardarLogBuscarAdjuntos = await Actions.callChain(context, {
                    chain: 'application:guardar_log',
                    params: {
                      funcionalidad: $page.variables.paramFuncionalidadMenu,
                      accion: 'FALLA_FUNCION',
                      pagina: $flow.currentPage,
                      proveedor: $application.variables.user.esProveedor,
                      suscriptorId: $application.variables.suscriptor.id,
                      usuario: $application.variables.user.ociUser,
                      numeroAn8: $application.variables.user.numeroAn8,
                      roles: $application.variables.userRoles.userRolesSt,
                      observaciones: 'BuscarAdjuntos Voucher rowset vacio',
                    },
                  });
                }
              } else {

                //LOG success BuscarAdjuntos
                const guardarLogBuscarAdjuntos = await Actions.callChain(context, {
                  chain: 'application:guardar_log',
                  params: {
                    funcionalidad: $page.variables.paramFuncionalidadMenu,
                    accion: 'FALLA_FUNCION',
                    pagina: $flow.currentPage,
                    proveedor: $application.variables.user.esProveedor,
                    suscriptorId: $application.variables.suscriptor.id,
                    usuario: $application.variables.user.ociUser,
                    numeroAn8: $application.variables.user.numeroAn8,
                    roles: $application.variables.userRoles.userRolesSt,
                    observaciones: 'BuscarAdjuntos Voucher',
                  },
                });

              }

              //LOG success BuscarVoucherSinMatching
              const guardarLog = await Actions.callChain(context, {
                chain: 'application:guardar_log',
                params: {
                  funcionalidad: $page.variables.paramFuncionalidadMenu,
                  accion: 'SUCCESS_FUNCION',
                  pagina: $flow.currentPage,
                  proveedor: $application.variables.user.esProveedor,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  numeroAn8: $application.variables.user.numeroAn8,
                  roles: $application.variables.userRoles.userRolesSt,
                  observaciones: 'BuscarVoucher',
                },
              });

            } else {

              /*
              //LOG success BuscarVoucherSinMatching
              const guardarLog = await Actions.callChain(context, {
                chain: 'application:guardar_log',
                params: {
                  funcionalidad: $page.variables.paramFuncionalidadMenu,
                  accion: 'FALLA_FUNCION',
                  pagina: $flow.currentPage,
                  proveedor: $application.variables.user.esProveedor,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  numeroAn8: $application.variables.user.numeroAn8,
                  roles: $application.variables.userRoles.userRolesSt,
                  observaciones: 'BuscarVoucher',
                },
              });
              */

              const notificarErrorBuscarVoucherSinMatching = await Actions.callChain(context, {
                chain: 'application:notificar_error',
                params: {
                  codigo: 'consulta-sin-datos',
                },
              });

            }

            break;

          default:
            // Código para cualquier otro caso (opcional)
            break;
        }

      }

      $page.variables.flagModified = false;

      $page.variables.flagPageLoading = false;

      $page.variables.flagVBEnter = true;


    }
  }

  return vBEnter;
});