define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnBuscarOrdenRecepcionMatch extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

          const callFunctionMostrarDrawerBuscarRecepcionesMatch = await this.generarRandomBuscarRecepcionesMatch(context);
          $page.variables.mostrarDrawerBuscarRecepcionesMatch = callFunctionMostrarDrawerBuscarRecepcionesMatch;

    }

    /**
    * @param {Object} context
    */
    async generarRandomBuscarRecepcionesMatch(context) {
      const { $page, $flow, $application } = context;
      let random = Math.random(1, 10);
      return random;
    }

  }

  return actBtnBuscarOrdenRecepcionMatch;
});
