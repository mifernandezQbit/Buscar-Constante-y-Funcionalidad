define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class datosProveedorLightListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:typResponseDatosProveedorLightCustom,value:typResponseDatosProveedorLightCustom}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;

            //Control de Seguridad por Centro de Costos
            //seguridadOK boolean valor default !$application.variables.user.esProveedor && $application.variables.seguridadCCActivada
            if (!!event.value?.data?.nroProveedor
                && !$application.variables.user.esProveedor 
                && $page.variables.paramModoCRU === 'C' ){
                //&& ["C", "U"].indexOf($page.variables.paramModoCRU) !== -1 ){
              $page.variables.seguridadOK = await Actions.callChain(context, {
                chain: 'application:validar_seguridad',
                params: {
                  accionJDE: 'A', //$page.variables.paramModoCRU === "C" ? "A" : "C", //accionJde A lta equivalente a modoCRU C
                  funcionalidad: $page.variables.paramFuncionalidadMenu,
                  //funcionalidadID: undefined,
                  valor: event.value.data.unidadNegocio,
                  nroProveedor: event.value.data?.nroProveedor,
                },
              });

              $page.variables.seguridadOKGuardar = $page.variables.seguridadOK;

              if (!$page.variables.seguridadOK){
                $page.variables.datosProveedorLight = { data: null };
              }

            }

    }
  }

  return datosProveedorLightListener;
});
