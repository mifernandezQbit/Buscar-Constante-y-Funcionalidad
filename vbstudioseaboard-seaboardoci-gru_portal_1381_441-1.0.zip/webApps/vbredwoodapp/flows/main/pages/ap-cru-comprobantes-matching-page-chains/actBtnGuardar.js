define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnGuardar extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $page.variables.flagPageLoading = true;

      /*
      // FORZAR COMMIT DE CELDA DE TABLA O INPUT ACTIVO (en edición)
      // Quita el foco del elemento en edición y aguarda un ciclo para que JET
      // consolide el valor en las variables de la página antes de armar los payloads.
*/
      if (document.activeElement && typeof document.activeElement.blur === 'function') {
        document.activeElement.blur();
      }
      await new Promise(resolve => setTimeout(resolve, 50));


      $page.variables.flagGuardar = false; //deshabilito btnGuardar hasta que termine la action

      const guardarLogGuardar = await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          funcionalidad: $page.variables.paramFuncionalidadMenu,
          accion: 'GUARDAR',
          pagina: $flow.currentPage,
          proveedor: $application.variables.user.esProveedor,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          numeroAn8: $application.variables.user.numeroAn8,
          roles: $application.variables.userRoles.userRolesSt,
          observaciones: $variables.paramModoCRU === "C" ? "AltaVoucherConMatch" : "",
        },
      });

      let altaOActualizarOK;

      let responseQ71PO_AltaVoucherConMatchOC;
      let responseQ71PO_ActualizarVoucherMatching;

      //limpio fragemento errores para no acumular errores que puedan estar ya solucionados entre guardar y guardar
      $page.variables.erroresJDE = [];

      let mailProveedor = $application.variables.user.esProveedor ? $application.variables.user.email : ($page.variables.datosProveedorLight.data.email || '');

      //modoCRU C CREATE AltaVoucher
      if ($page.variables.paramModoCRU === 'C') {

        //CHEQUEO QUE GRIDIN_1_2 ESTÉ CONSISTENTE CON AREA Y TIPO DE IMPUESTO CARGADO POR ITEM
        const integridadAltaVoucherGridIn_1_2 = await ActionUtils.forEach($page.variables.requestQ71PO_AltaVoucherConMatchOC.GridIn_1_2, async (itemIntegridadAltaVoucherGridIn_1_2, indexIntegridadAltaVoucherGridIn_1_2) => {

          if (itemIntegridadAltaVoucherGridIn_1_2.areaImpuesto === undefined || itemIntegridadAltaVoucherGridIn_1_2.tipoImpuesto === undefined || itemIntegridadAltaVoucherGridIn_1_2.areaImpuesto === '' || itemIntegridadAltaVoucherGridIn_1_2.tipoImpuesto === '') {
            altaOActualizarOK = false;

            const notificarErrorIntegridadAltaVoucherGridIn_1_2 = await Actions.callChain(context, {
              chain: 'application:notificar_error',
              params: {
                codigo: 'falta-configuracion-areas-fiscales',
                modoVisualizacion: 'persist',
              },
            });

            const notificarError2 = await Actions.callChain(context, {
              chain: 'application:notificar_error',
              params: {
                descripcion: 'Revise Comprobante Item con Importes' + itemIntegridadAltaVoucherGridIn_1_2.importeFiscal + ' ' + itemIntegridadAltaVoucherGridIn_1_2.importeImponible,
                titulo: 'Atención! Falta configuración de impuestos. Datos Adicionales',
                modoVisualizacion: 'persist',
                tipoNotificacion: 'error',
              },
            });


          }

        });


        //================================================================================================
        //INICIO llamar a web service de afip para constatar el comprobante (CAE) si está activa la constante
        //================================================================================================
        const fecha = await $application.functions.formatDateString($variables.requestQ71PO_AltaVoucherConMatchOC.fechaFactura, 'yyyymmdd');

        const transaccionTexto = [
          $application.variables.selectedCompany.company,
          $application.variables.selectedCompany.cuit,
          $variables.requestQ71PO_AltaVoucherConMatchOC.nroFactura.substring(0, 5),
          $variables.requestQ71PO_AltaVoucherConMatchOC.tipoDocumentoTransaccionAFIP.replace(/^0+/, ''),
          $variables.requestQ71PO_AltaVoucherConMatchOC.nroFactura.substring(5),
          $variables.CAEoCAEA,
          $page.variables.datosProveedorLight.data.idFiscal,
          $variables.requestQ71PO_AltaVoucherConMatchOC.nroCAI,
          fecha,
          $variables.totalComprobanteCabecera,
          $variables.totalComprobanteDetalle,
          '80',
          $application.variables.selectedCompany.cuit
        ].join(' - ');

        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'GUARDAR',
            funcionalidad: $variables.paramFuncionalidadMenu,
            numeroAn8: $application.variables.user.numeroAn8,
            observaciones: 'Constatar Comprobante ' + ($page.variables.uniqueVoucherMatrizFn?.validarCAE ? 'SI' : 'NO'),
            pagina: $application.currentPage.id,
            proveedor: false,
            roles: $application.variables.userRoles.userRolesSt,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            transaccion: transaccionTexto
          },
        });

        if ($page.variables.paramModoCRU === 'C' && $page.variables.uniqueVoucherMatrizFn?.validarCAE) {

          const responseComprobanteConstatar = await Actions.callRest(context, {
            endpoint: 'GatewayPortal2/postQ71PO_ComprobanteConstatar',
            body: {
              token: $application.variables.token,
              CompanyKey: $application.variables.selectedCompany.company,
              cuit: $application.variables.selectedCompany.cuit,
              puntoVenta: $variables.requestQ71PO_AltaVoucherConMatchOC.nroFactura.substring(0, 5),
              tipoCbte: $variables.requestQ71PO_AltaVoucherConMatchOC.tipoDocumentoTransaccionAFIP.replace(/^0+/, ''),
              nroCbte: $variables.requestQ71PO_AltaVoucherConMatchOC.nroFactura.substring(5),
              cbteModo: $variables.CAEoCAEA, //'CAE',
              cuitEmisor: $page.variables.datosProveedorLight.data.idFiscal, //responseObtenerDatosProveedor.body.data.idFiscal,
              codAutorizacion: $variables.requestQ71PO_AltaVoucherConMatchOC.nroCAI,
              cbteFecha: fecha,
              importeTotal: $variables.totalComprobanteCabecera,
              docTipoReceptor: '80',
              docNroReceptor: $application.variables.selectedCompany.cuit,
            },
          });

          await Actions.callChain(context, {
            chain: 'application:verificar_respuesta_jdeError',
            params: {
              error: !responseComprobanteConstatar.ok,
              funcion: 'ComprobanteConstatar',
              funcionalidad: $page.variables.paramFuncionalidadMenu,
              tokenExpirado: responseComprobanteConstatar.body.tokenExpirado !== undefined ? responseComprobanteConstatar.body.tokenExpirado : false,
              status: responseComprobanteConstatar.status,
            },
          });

          if (!responseComprobanteConstatar.ok || responseComprobanteConstatar.body.errorJde) {
            // si hubo un error de api, no permitir ingresar el comprobante
            altaOActualizarOK = false;//comprobante-error-constatacion

            const guardarLog2 = await Actions.callChain(context, {
              chain: 'application:guardar_log',
              params: {
                accion: 'GUARDAR',
                funcionalidad: $variables.paramFuncionalidadMenu,
                numeroAn8: $application.variables.user.numeroAn8,
                observaciones: 'Error de servidor al constatar el comprobante',
                pagina: $application.currentPage.id,
                proveedor: false,
                roles: $application.variables.userRoles.userRolesSt,
                suscriptorId: $application.variables.suscriptor.id,
                usuario: $application.variables.user.ociUser,
                transaccion: transaccionTexto
              },
            });

            const notificarError = await Actions.callChain(context, {
              chain: 'application:notificar_error',
              params: {
                codigo: 'comprobante-constatacion-error',
                modoVisualizacion: '',
              },
            });

          } else {
            // ver si hubo error de constatacion
            if (responseComprobanteConstatar.body.data !== "A") {

              altaOActualizarOK = false;
              await Actions.callChain(context, {
                chain: 'application:guardar_log',
                params: {
                  accion: 'GUARDAR',
                  funcionalidad: $variables.paramFuncionalidadMenu,
                  numeroAn8: $application.variables.user.numeroAn8,
                  observaciones: 'NO superó constatación de comprobante: ' || responseComprobanteConstatar?.body?.data,
                  pagina: $application.currentPage.id,
                  proveedor: false,
                  roles: $application.variables.userRoles.userRolesSt,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  transaccion: transaccionTexto
                },
              });

              const notificarError = await Actions.callChain(context, {
                chain: 'application:notificar_error',
                params: {
                  codigo: 'comprobante-constatacion-error',
                  modoVisualizacion: '',
                },
              });

            } else {

              await Actions.callChain(context, {
                chain: 'application:guardar_log',
                params: {
                  accion: 'GUARDAR',
                  funcionalidad: $variables.paramFuncionalidadMenu,
                  numeroAn8: $application.variables.user.numeroAn8,
                  observaciones: 'SI superó constatación de comprobante: ' || responseComprobanteConstatar?.body?.data,
                  pagina: $application.currentPage.id,
                  proveedor: false,
                  roles: $application.variables.userRoles.userRolesSt,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  transaccion: transaccionTexto
                },
              });

              const notificarError = await Actions.callChain(context, {
                chain: 'application:notificar_error',
                params: {
                  codigo: 'comprobante-constatacion-ok',
                  modoVisualizacion: '',
                },
              });

            }
          }
        }
        //================================================================================================
        //FIN llamar a web service de afip para constatar el comprobante (CAE) si está activa la constante
        //================================================================================================

        if (altaOActualizarOK === undefined || altaOActualizarOK !== false) {

          //limpieza de campos que se utilizaron temporalmente con otra funcion
          $page.variables.requestQ71PO_AltaVoucherConMatchOC.controladorFiscal = "";

          //jmp revisar que condicionesPago en GridIn_1_2 si no están seteados viajen por default en ""
          // Validar el array gridin_1_2
          if (Array.isArray($page.variables.requestQ71PO_AltaVoucherConMatchOC.GridIn_1_2)) {
            $page.variables.requestQ71PO_AltaVoucherConMatchOC.GridIn_1_2.forEach(item => {
              if (typeof item.condicionesPago === 'undefined') {
                item.condicionesPago = " ";
              }
            });
          }

          let listaGridIn_1_6 = $page.variables.requestQ71PO_AltaVoucherConMatchOC.GridIn_1_6;
          if (listaGridIn_1_6 && listaGridIn_1_6.length > 0) {
            const item0 = listaGridIn_1_6[0];
            const valorFila0 = item0.actualizarFila ? item0.actualizarFila.trim() : "";
            //Condición: El valor está vacío o son solo espacios
            const estaVacio = valorFila0 === "";
            //Condición: El valor del item 0 existe en el resto del array (del índice 1 en adelante)
            const estaRepetido = listaGridIn_1_6.slice(1).some(item =>
              item.actualizarFila && item.actualizarFila.trim() === valorFila0
            );
            // Si se cumple, eliminamos el primer elemento
            if (estaVacio || estaRepetido) {
              listaGridIn_1_6.shift(); // Elimina el primer elemento (índice 0)
            }
            // Actualizo GridIn_1_6
            $page.variables.requestQ71PO_AltaVoucherConMatchOC.GridIn_1_6 = [...listaGridIn_1_6];
          }

          //forzar que vayan vacíos "" los conceptos de retencion
          //ya que JDE por defecto si no ponés nada en los conceptos toma los del proveedor. 
          //Es decir nosotros estabamos duplicando esa lógica que ya x defecto hace JDE.            
          if ($page.variables.paramModoCRU === 'C' && $page.variables.uniqueVoucherMatrizFn?.usaMatrizRetenciones === false) {
            $page.variables.requestQ71PO_AltaVoucherConMatchOC.GridIn_1_6.forEach(item => {
              item.conceptoIVA = "";
              item.conceptoGanancias = "";
              item.conceptoOriIIBB = "";
              item.conceptoDstIIBB = "";
              item.conceptoContratistas = "";
              item.conceptoSUSS = "";
              item.condGanancias = "";
              item.convenioIIBB = "";
            });
          }

          //agregado en branch julian-20250505
          // Reordenar reindexando GridIn_1_2 con forEach
          let contador_1_2 = 1;
          $page.variables.requestQ71PO_AltaVoucherConMatchOC.GridIn_1_2.forEach(item => {
            item.actualizarFilaGrid = contador_1_2.toString();
            contador_1_2++;
          });
          // Reordenar reindexando GridIn_1_6 con forEach
          let contador_1_6 = 1;
          $page.variables.requestQ71PO_AltaVoucherConMatchOC.GridIn_1_6.forEach(item => {
            item.actualizarFila = contador_1_6.toString();
            contador_1_6++;
          });
          $page.variables.requestQ71PO_AltaVoucherConMatchOC.token = $application.variables.token;

          responseQ71PO_AltaVoucherConMatchOC = await Actions.callRest(context, {
            endpoint: 'GatewayPortal2/postQ71PO_AltaVoucherConMatchOC',
            body: $page.variables.requestQ71PO_AltaVoucherConMatchOC,
          });
          await Actions.callChain(context, {
            chain: 'application:verificar_respuesta_jdeError',
            params: {
              error: !responseQ71PO_AltaVoucherConMatchOC.ok,
              funcion: 'AltaVoucherConMatchOC',
              funcionalidad: $page.variables.paramFuncionalidadMenu,
              tokenExpirado: responseQ71PO_AltaVoucherConMatchOC.body.tokenExpirado !== undefined ? responseQ71PO_AltaVoucherConMatchOC.body.tokenExpirado : false,
              status: responseQ71PO_AltaVoucherConMatchOC.status,
            },
          });
        }
        if ((altaOActualizarOK === undefined || altaOActualizarOK !== false) && responseQ71PO_AltaVoucherConMatchOC.ok && responseQ71PO_AltaVoucherConMatchOC.body.success === true) {

          $page.variables.erroresJDE = responseQ71PO_AltaVoucherConMatchOC &&
            responseQ71PO_AltaVoucherConMatchOC.body &&
            Array.isArray(responseQ71PO_AltaVoucherConMatchOC.body.errorsList) &&
            responseQ71PO_AltaVoucherConMatchOC.body.errorsList.length > 0 ?
            responseQ71PO_AltaVoucherConMatchOC.body.errorsList : [];

          if (responseQ71PO_AltaVoucherConMatchOC?.body?.errorJde === true
            && (
              !responseQ71PO_AltaVoucherConMatchOC.body ||
              !responseQ71PO_AltaVoucherConMatchOC.body.data ||
              !responseQ71PO_AltaVoucherConMatchOC.body.data.tipoDocumento ||
              responseQ71PO_AltaVoucherConMatchOC.body.data.tipoDocumento.toString().trim() === '' ||
              !responseQ71PO_AltaVoucherConMatchOC.body.data.nroDocumento ||
              responseQ71PO_AltaVoucherConMatchOC.body.data.nroDocumento.toString().trim() === ''
            )
          ) {
            const guardarLog = await Actions.callChain(context, {
              chain: 'application:guardar_log',
              params: {
                funcionalidad: $page.variables.paramFuncionalidadMenu,
                accion: 'ERROR_VALIDACION',
                pagina: $flow.currentPage,
                proveedor: $application.variables.user.esProveedor,
                suscriptorId: $application.variables.suscriptor.id,
                usuario: $application.variables.user.ociUser,
                numeroAn8: $application.variables.user.numeroAn8,
                roles: $application.variables.userRoles.userRolesSt,
                observaciones: "AltaVoucherSinMatching",
                transaccion: $page.variables.requestQ71PO_AltaVoucherConMatchOC.tipoDocumentoTransaccionAFIP + '-'
                  + $page.variables.requestQ71PO_AltaVoucherConMatchOC.letraFactura + '-'
                  + $page.variables.requestQ71PO_AltaVoucherConMatchOC.nroFactura,
              },
            });
          }
          else {

            altaOActualizarOK = true;
            //datos para mostrar en dlgConfirmacionAlta
            $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.ciaDocumento = responseQ71PO_AltaVoucherConMatchOC.body.data.ciaDocumento;
            $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.tipoDocumento = responseQ71PO_AltaVoucherConMatchOC.body.data.tipoDocumento;
            $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.nroDocumento = responseQ71PO_AltaVoucherConMatchOC.body.data.nroDocumento.toString();
            $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.nroProveedor = responseQ71PO_AltaVoucherConMatchOC.body.data.nroProveedor;
            $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.nroFactura = responseQ71PO_AltaVoucherConMatchOC.body.data.nroFactura;

            //gmonto en usd
            let montoTotalComprobanteEnUSD = 0;
            if ($page.variables.requestQ71PO_AltaVoucherConMatchOC.codigoMoneda === $page.variables.consMonedaCaucion) { //'USD') {
              montoTotalComprobanteEnUSD = $page.variables.totalComprobanteDetalle;
            } else {

              //según tipo moneda <> ARS entonces seteo tipo de cambio acorde a usd destino para el control de caution
              // Obtener la fecha actual y setearla por default para pedir tipo de cambio
              const fechaActual = new Date();
              // Formatear la fecha actual en formato ISO "yyyy-MM-dd"
              const anio = fechaActual.getFullYear();
              const mes = String(fechaActual.getMonth() + 1).padStart(2, '0'); // Mes empieza en 0, por eso sumamos 1
              const dia = String(fechaActual.getDate()).padStart(2, '0');

              const responseQ71PO_BuscarTipoCambio = await Actions.callRest(context, {
                endpoint: 'GatewayPortal2/postQ71PO_BuscarTipoCambio',
                body: {
                  "token": $application.variables.token,
                  "monedaOrigen": $page.variables.requestQ71PO_AltaVoucherConMatchOC.codigoMoneda, //"ARS",
                  "monedaDestino": $page.variables.consMonedaCaucion, //"USD",
                  "fecha": $page.functions.formatDateString($page.variables.requestQ71PO_AltaVoucherConMatchOC.fechaFactura, $application.variables.preferenciasUsuarioJde.simpleDateFormat)

                },
              });
              await Actions.callChain(context, {
                chain: 'application:verificar_respuesta_jdeError',
                params: {
                  error: !responseQ71PO_BuscarTipoCambio.ok,
                  funcion: 'BuscarTipoCambio',
                  funcionalidad: $page.variables.paramFuncionalidadMenu || '',
                  tokenExpirado: responseQ71PO_BuscarTipoCambio.body.tokenExpirado !== undefined ? responseQ71PO_BuscarTipoCambio.body.tokenExpirado : false,
                  status: responseQ71PO_BuscarTipoCambio.status,
                },
              });
              if (responseQ71PO_BuscarTipoCambio.body.success === true) {

                $page.variables.flagConsoleLog && console.log('logjmp', 'actBtnGuardar postQ71PO_BuscarTipoCambio iniciar-wf montoTotalComprobanteEnUSD', responseQ71PO_BuscarTipoCambio.body);

                //si metodoConv = Y
                //  importe transacción = importe ingresado  X tcMultiplicador
                //sino 
                //  importe transaccion = importe ingresado / tcMultiplicador
                if (responseQ71PO_BuscarTipoCambio.body.rowset[0].metodoConv === 'Y') {
                  //calculo el valor al cambio si tipo cambio es mayor a 0 y si no mantengo el mismo valor multiplicando por 1
                  montoTotalComprobanteEnUSD = $page.variables.totalComprobanteDetalle * responseQ71PO_BuscarTipoCambio.body.rowset[0].tcMultiplicador;

                } else {
                  //calculo el valor al cambio si tipo cambio es mayor a 0 y si no mantengo el mismo valor dividiendolo por 1
                  montoTotalComprobanteEnUSD = $page.variables.totalComprobanteDetalle / (responseQ71PO_BuscarTipoCambio.body.rowset[0].tcMultiplicador !== 0 ? responseQ71PO_BuscarTipoCambio.body.rowset[0].tcMultiplicador : 1);
                }
              }

            }

            await Actions.callChain(context, {
              chain: 'application:iniciar_wf',
              params: {
                accionJDE: 'A',
                accionWF: 'A',
                ciaDocumento: $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.ciaDocumento,
                funcionalidadPortal: $page.variables.paramFuncionalidadMenu,
                importeTotal: $page.variables.requestQ71PO_AltaVoucherConMatchOC.codigoMoneda === $application.variables.selectedCompany.moneda ? $page.variables.totalComprobanteDetalle : 0, //20260618 jmp sacar hardcoded //'ARS' ? $page.variables.totalComprobanteDetalle : 0,
                importeMonedaExtranjera: $page.variables.requestQ71PO_AltaVoucherConMatchOC.codigoMoneda !== $application.variables.selectedCompany.moneda ? $page.variables.totalComprobanteDetalle : 0, //20260618 jmp sacar hardcoded //'ARS' ? $page.variables.totalComprobanteDetalle : 0,
                importeTotalDolares: montoTotalComprobanteEnUSD,
                mailProveedor: mailProveedor,
                modulo: '04',
                nroAprobador: '',
                nroDocumento: $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.nroDocumento,
                nroProveedor: parseInt($page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.nroProveedor, 10),
                tipoDocumento: $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.tipoDocumento,
                usuarioOriginadorTR: $application.variables.user.numeroAn8,
                usuarioOriginadorWF: $application.variables.user.numeroAn8,
                usuarioSolicitante: Number($page.variables.requestQ71PO_AltaVoucherConMatchOC.aprobador || 0),
                cdCatMaestro: $page.variables.autorizanteWF || '',
                ruteoVoucher: $page.variables.wfRuteoVoucher,
                flag01: '1', //fijo en 1 para que habilite el actualizarVoucherMatching ($page.variables.paramFuncionalidadMenu === 'INGRESAR_FACTURA_MATCH_FL') ? '1' : '0',
                flag02: '1',
                flag03: '1',
                flag04: '0',
                flag06: $page.variables.flagDetalleGuardar.includes('R_W') ? '1' : '0',

              },
            });
            //*/
          }
        }

      }
      else if ($page.variables.paramModoCRU === 'U') { //queda habilitado el update especial para matching y no solo es caso FL

        responseQ71PO_ActualizarVoucherMatching = await Actions.callRest(context, {
          endpoint: 'GatewayPortal3/postQ71PO_ActualizarVoucherMatching',
          body: $page.variables.requestQ71PO_ActualizarVoucherMatching,
        });
        await Actions.callChain(context, {
          chain: 'application:verificar_respuesta_jdeError',
          params: {
            error: !responseQ71PO_ActualizarVoucherMatching.ok,
            funcion: 'ActualizarVoucherMatching',
            funcionalidad: $page.variables.paramFuncionalidadMenu,
            tokenExpirado: responseQ71PO_ActualizarVoucherMatching.body.tokenExpirado !== undefined ? responseQ71PO_ActualizarVoucherMatching.body.tokenExpirado : false,
            status: responseQ71PO_ActualizarVoucherMatching.status,
          },
        });

        if ((altaOActualizarOK === undefined || altaOActualizarOK !== false) && responseQ71PO_ActualizarVoucherMatching.body.success === true) {

          $page.variables.erroresJDE = responseQ71PO_ActualizarVoucherMatching &&
            responseQ71PO_ActualizarVoucherMatching.body &&
            Array.isArray(responseQ71PO_ActualizarVoucherMatching.body.errorsList) &&
            responseQ71PO_ActualizarVoucherMatching.body.errorsList.length > 0 ?
            responseQ71PO_ActualizarVoucherMatching.body.errorsList : [];

          if (responseQ71PO_ActualizarVoucherMatching?.body?.errorJde === true
            && (
              !responseQ71PO_ActualizarVoucherMatching.body ||
              !responseQ71PO_ActualizarVoucherMatching.body.data ||
              !responseQ71PO_ActualizarVoucherMatching.body.data.tipoDocumento ||
              responseQ71PO_ActualizarVoucherMatching.body.data.tipoDocumento.toString().trim() === '' ||
              !responseQ71PO_ActualizarVoucherMatching.body.data.nroDocumento ||
              responseQ71PO_ActualizarVoucherMatching.body.data.nroDocumento.toString().trim() === ''
            )
          ) {
            const guardarLog = await Actions.callChain(context, {
              chain: 'application:guardar_log',
              params: {
                funcionalidad: $page.variables.paramFuncionalidadMenu,
                accion: 'ERROR_VALIDACION',
                pagina: $flow.currentPage,
                proveedor: $application.variables.user.esProveedor,
                suscriptorId: $application.variables.suscriptor.id,
                usuario: $application.variables.user.ociUser,
                numeroAn8: $application.variables.user.numeroAn8,
                roles: $application.variables.userRoles.userRolesSt,
                observaciones: "ActualizarVoucher",
                transaccion: $page.variables.requestQ71PO_ActualizarVoucherMatching.ciaDocumento + '-'
                  + $page.variables.requestQ71PO_ActualizarVoucherMatching.tipoDocumento + '-'
                  + $page.variables.requestQ71PO_ActualizarVoucherMatching.nroDocumento.toString(),
              },
            });
          }
          else {

            altaOActualizarOK = true;
            //datos para mostrar en dlgConfirmacionAltaOActualizar
            $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.ciaDocumento = $page.variables.requestQ71PO_ActualizarVoucherMatching.ciaDocumento;
            $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.tipoDocumento = $page.variables.requestQ71PO_ActualizarVoucherMatching.tipoDocumento;
            $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.nroDocumento = $page.variables.requestQ71PO_ActualizarVoucherMatching.nroDocumento;
            $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.nroFactura = $page.variables.responseQ71PO_BuscarVoucher.data.nroFactura || "";

            //reseteo flag de modificacion / impacta sobre btn aprobar de  accionar wf en principio
            $page.variables.flagModified = ($page.variables.flagDetalleGuardar.includes('P_E') || $page.variables.flagDetalleGuardar.includes('R_W')) ? true : false;

          }
        }


      } else if ($page.variables.paramModoCRU === 'P') {
        altaOActualizarOK = true;
        //datos para mostrar en dlgConfirmacionAltaOActualizar
        $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.ciaDocumento = $page.variables.responseQ71PO_BuscarVoucher.data.ciaDocumento;
        $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.tipoDocumento = $page.variables.responseQ71PO_BuscarVoucher.data.tipoDocumento;
        $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.nroDocumento = $page.variables.responseQ71PO_BuscarVoucher.data.nroDocumento;
        $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.nroFactura = $page.variables.responseQ71PO_BuscarVoucher.data.nroFactura || "";

        //reseteo flag de modificacion / impacta sobre btn aprobar de  accionar wf en principio
        $page.variables.flagModified = ($page.variables.flagDetalleGuardar.includes('P_E') || $page.variables.flagDetalleGuardar.includes('R_W')) ? true : false;
      }

      ///*
      if (altaOActualizarOK === true) { //realizar resto de pasos según sea Alta o Update respecto de adjuntar archivos e informar lo realizado
        //Subir pdf de la factura (función Q71PO_SubirAdjunto)
        //Si es anticipo subir pdf póliza de caución (función Q71PO_SubirAdjunto) si la hubiera
        //subir a jde archivos seleccionados como adjuntos

        //agrego este if de CREATE para que solo se suban archivos etc en ese modo y no en el actualizar especial por el momento
        //permito que se suba un adjunto tanto en C como U, como P 
        $page.variables.requestQ71PO_SubirAdjunto.tipoDocumento = $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.tipoDocumento; //responseQ71PO_AltaVoucherConMatchOC.body.data.tipoDocumento;
        $page.variables.requestQ71PO_SubirAdjunto.nroDocumento = $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.nroDocumento; //responseQ71PO_AltaVoucherConMatchOC.body.data.nroDocumento;
        $page.variables.requestQ71PO_SubirAdjunto.incluirMetadatos = true;
        $page.variables.requestQ71PO_SubirAdjunto.itemPagoDocumento = '001'; //sfxOrden; 
        $page.variables.requestQ71PO_SubirAdjunto.ciaDocumento = $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.ciaDocumento; //responseQ71PO_AltaVoucherConMatchOC.body.data.ciaDocumento;
        $page.variables.requestQ71PO_SubirAdjunto.numeroProveedor = $page.variables.paramModoCRU === 'C' ? $page.variables.requestQ71PO_AltaVoucherConMatchOC.nroProveedor : $page.variables.responseQ71PO_BuscarVoucher.data.nroProveedor;
        $page.variables.requestQ71PO_SubirAdjunto.token = $application.variables.token;

        $page.variables.requestQ71PO_SubirAdjunto.metadatos.estadoObjeto = '';
        $page.variables.requestQ71PO_SubirAdjunto.metadatos.fechaVigenciaDesde = '';
        $page.variables.requestQ71PO_SubirAdjunto.metadatos.fechaVigenciaHasta = '';
        $page.variables.requestQ71PO_SubirAdjunto.metadatos.nroVehiculo = '';
        $page.variables.requestQ71PO_SubirAdjunto.metadatos.descripcion = '';
        $page.variables.requestQ71PO_SubirAdjunto.metadatos.codigosCategoria = [
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          ""
        ];
        $page.variables.requestQ71PO_SubirAdjunto.tipoObjeto = $page.variables.consVisualizarAdjuntosTipoObjeto;

        const buscarConstanteADJUNTOS_VISIBLES_PORTAL_CC = await Actions.callChain(context, {
          chain: 'application:buscar_constante',
          params: {
            constante: 'ADJUNTOS_VISIBLES_PORTAL_CC',
          },
        });
        if (buscarConstanteADJUNTOS_VISIBLES_PORTAL_CC.existe === true) {

          $page.variables.consADJUNTOS_VISIBLES_PORTAL_CC = buscarConstanteADJUNTOS_VISIBLES_PORTAL_CC.valor;

          //como ya obtuve la posición del array de códigosCategoria ahora busco el valor a setear
          const buscarConstanteADJUNTOS_VISIBLES_PORTAL_COD = await Actions.callChain(context, {
            chain: 'application:buscar_constante',
            params: {
              constante: 'ADJUNTOS_VISIBLES_PORTAL_COD',
            },
          });
          if (buscarConstanteADJUNTOS_VISIBLES_PORTAL_COD.existe === true) {

            $page.variables.consADJUNTOS_VISIBLES_PORTAL_COD = buscarConstanteADJUNTOS_VISIBLES_PORTAL_COD.valor;

            //asigno en la posición del Array CC, el valor de COD
            $page.variables.requestQ71PO_SubirAdjunto.metadatos.codigosCategoria[$page.variables.consADJUNTOS_VISIBLES_PORTAL_CC] = $page.variables.consADJUNTOS_VISIBLES_PORTAL_COD;
          }

        } else {

          const notificarError3 = await Actions.callChain(context, {
            chain: 'application:notificar_error',
            params: {
              codigo: 'constantes-adjuntos-not-found',
            },
          });

        }

        const buscarConstanteADJUNTOS_AP_TIPO_CC = await Actions.callChain(context, {
          chain: 'application:buscar_constante',
          params: {
            constante: 'ADJUNTOS_AP_TIPO_CC',
          },
        });
        if (buscarConstanteADJUNTOS_AP_TIPO_CC.existe === true) {

          $page.variables.consADJUNTOS_AP_TIPO_CC = buscarConstanteADJUNTOS_AP_TIPO_CC.valor;

        }

        $page.variables.requestQ71PO_SubirAdjunto.metadatos.mokey = $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.ciaDocumento + '|' + $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.tipoDocumento + '|' + $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.nroDocumento + '|' + '001';

        //responseQ71PO_AltaVoucherSinMatching.body.data.ciaDocumento + '|' + responseQ71PO_AltaVoucherSinMatching.body.data.tipoDocumento + '|' + responseQ71PO_AltaVoucherSinMatching.body.data.nroDocumento + '|' + '001';

        //$page.variables.requestQ71PO_SubirAdjunto.idUnicoTareaWorkflow = '';

        //PARA PODER DIFERENCIAR Y PODER BUSCAR ADJUNTOS LUEGO AL MOMENTO DE CONSULTAR UN VOUCHER DETERMINADO
        if ($page.variables.listaArchivosSeleccionadosComprobante.length > 0) {
          //PRIMERO SUBIR ADJUNTO COMPMROBANTE VOUCHER
          //asigno en la posición del Array CC, el valor de TIPO 'VOUCHER'
          $page.variables.requestQ71PO_SubirAdjunto.metadatos.codigosCategoria[$page.variables.consADJUNTOS_AP_TIPO_CC] = 'VOUCHER';

          const resultSubirArchivosComprobanteConfirmarDespacho = await Actions.callChain(context, {
            chain: 'application:subir_archivos',
            params: {
              inParamListaArchivos: $page.variables.listaArchivosSeleccionadosComprobante,
              inParamRequestSubirAdjunto: $page.variables.requestQ71PO_SubirAdjunto,
            },
          }, { id: 'actSubirArchivosComprobanteConfirmarDespacho' });
          if (resultSubirArchivosComprobanteConfirmarDespacho.error === true) {
            $page.variables.flagConsoleLog && console.log('logjmp', 'action application:subir_archivos VOUCHER falló', $page.variables.requestQ71PO_SubirAdjunto);
          }
        }

        if ($page.variables.listaArchivosSeleccionadosOtros.length > 0) {
          //AHORA SUBIR ADJUNTO COMPMROBANTE OTROS si hay
          //asigno en la posición del Array CC, el valor de TIPO 'OTROS'
          $page.variables.requestQ71PO_SubirAdjunto.metadatos.codigosCategoria[$page.variables.consADJUNTOS_AP_TIPO_CC] = 'OTROS';

          const resultSubirArchivosOtrosConfirmarDespacho = await Actions.callChain(context, {
            chain: 'application:subir_archivos',
            params: {
              inParamListaArchivos: $page.variables.listaArchivosSeleccionadosOtros,
              inParamRequestSubirAdjunto: $page.variables.requestQ71PO_SubirAdjunto,
            },
          }, { id: 'actSubirArchivosOtrosConfirmarDespacho' });
          if (resultSubirArchivosOtrosConfirmarDespacho.error === true) {
            $page.variables.flagConsoleLog && console.log('logjmp', 'action application:subir_archivos OTROS falló', $page.variables.requestQ71PO_SubirAdjunto);
          }
        }

        //20260619 jmp se agrega limpieza de listaArchivosSeleccionados subidos... para que si se hace de nuevo Guardar, no duplique los archivos subidos
        $page.variables.listaArchivosSeleccionadosComprobante = [];
        $page.variables.listaArchivosSeleccionadosOtros = [];

        //guarda en tabla log (cadena acción global guardar-log)
        //LOG success AltaVoucherSinMatching o ActualizarVoucher
        const guardarLog = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            funcionalidad: $page.variables.paramFuncionalidadMenu,
            accion: 'SUCCESS_FUNCION',
            pagina: $flow.currentPage,
            proveedor: $application.variables.user.esProveedor,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            numeroAn8: $application.variables.user.numeroAn8,
            roles: $application.variables.userRoles.userRolesSt,
            observaciones: "AltaVoucherConMatchOC",
            transaccion: $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.ciaDocumento + '-' + $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.tipoDocumento + '-' + $page.variables.responseReducidoQ71PO_AltaVoucherConMatchOC.nroDocumento,
          },
        });

        //dialog de despachos confirmados y navigate to pur-consultar-despachos-pendientes
        await Actions.callComponentMethod(context, {
          selector: '#dlgAltaVoucherConfirmado',
          method: 'open',
        });
      } else {

        //si falla JDE asigna errores a frag errores-validacion
        if (responseQ71PO_AltaVoucherConMatchOC?.ok) {

          $page.variables.erroresJDE = responseQ71PO_AltaVoucherConMatchOC.body.errorsList;
        } else {
          $page.variables.flagConsoleLog && console.log('logjmp', 'errorJde response sin body', responseQ71PO_AltaVoucherConMatchOC);
        }

        const notificarErrorFalloAltaActualizarVoucher = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            codigo: 'fallo-alta-actualizar-voucher',
            modoVisualizacion: 'persist',
          },
        });

        //LOG falla 
        const guardarLog = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            funcionalidad: $page.variables.paramFuncionalidadMenu,
            accion: 'FALLA_FUNCION',
            pagina: $flow.currentPage,
            proveedor: $application.variables.user.esProveedor,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            numeroAn8: $application.variables.user.numeroAn8,
            roles: $application.variables.userRoles.userRolesSt,
            observaciones: 'AltaVoucherConMatch',
          },
        });
      }

      $page.variables.flagGuardar = true;

      $page.variables.flagPageLoading = false;

    }
  }

  return actBtnGuardar;
});