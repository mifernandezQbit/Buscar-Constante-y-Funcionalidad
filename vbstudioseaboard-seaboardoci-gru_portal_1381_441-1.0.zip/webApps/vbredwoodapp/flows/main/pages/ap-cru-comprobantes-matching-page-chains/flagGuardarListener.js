define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class flagGuardarListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      //$page.variables.flagConsoleLog && console.log('logjmp', 'ap-cru-comprobantes-matching flagGuardarListener', event.value);

    }
  }

  return flagGuardarListener;
});
