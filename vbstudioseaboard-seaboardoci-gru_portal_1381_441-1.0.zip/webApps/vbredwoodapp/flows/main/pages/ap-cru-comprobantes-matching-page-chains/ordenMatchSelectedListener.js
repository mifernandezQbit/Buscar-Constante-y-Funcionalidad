define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ordenMatchSelectedListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:{ciaOrden:string,nroOrden:string,nroProveedor:string,tipoOrden:string},value:{ciaOrden:string,nroOrden:string,nroProveedor:string,tipoOrden:string},diff:object}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;


    }
  }

  return ordenMatchSelectedListener;
});
