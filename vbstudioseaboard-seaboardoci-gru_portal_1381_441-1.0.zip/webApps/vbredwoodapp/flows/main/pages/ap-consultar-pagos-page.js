define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    transformDateInArray(array) {
     let transformed = [];
     let long = array.length;
      
      for (let index = 0; index < long; index++) {
      let item = array[index];
      let partes = item.fechaVto.split('-'); 
      array[index].fechaVto = `${partes[2]}-${partes[1]}-${partes[0]}`;
      
    }
    
   return array;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    transformFechaDesde(fecha) {
      const partes = fecha.split('/'); 
      const nuevaFechaDesde = `${partes[2]}-${partes[1]}-${partes[0]}`;
      

      return nuevaFechaDesde;
 
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    completarNro(numero) {
      let numeroStr = numero.toString();
      return numeroStr.padStart(8, '0');
    }
  }
  
  return PageModule;
});
