define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actElegirSolicitanteCancelar extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
            const ojDialogSolicitanteClose = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-solicitante',
        method: 'close',
      });
    }
  }

  return actElegirSolicitanteCancelar;
});
