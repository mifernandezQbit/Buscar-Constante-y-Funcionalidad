define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actInicioPagina extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $variables.buscando = true;
      const verificarPermisosFuncionalidadCONSULTAR_PROVEEDOR = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: 'CONSULTAR_PROVEEDOR',
        },
      });

      if (verificarPermisosFuncionalidadCONSULTAR_PROVEEDOR.existe === false) {
        await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'INTENTO_INGRESO_NH',
          funcionalidad: 'CONSULTAR_PROVEEDOR',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          suscriptorId: $application.variables.user.suscriptorID,
          usuario: $application.variables.user.ociUser,
          transaccion: $variables.nroProveedor.toString().padStart(8,'0'),
        },
      });
      
        const toAccesoNoAutorizado = await Actions.navigateToPage(context, {
          page: 'acceso-no-autorizado',
        });
      }

      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'INGRESA',
          funcionalidad: 'CONSULTAR_PROVEEDOR',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          suscriptorId: $application.variables.user.suscriptorID,
          usuario: $application.variables.user.ociUser,
          transaccion: $variables.nroProveedor.toString().padStart(8,'0'),
        },
      });

      // VERIFICAR permiso a editar proveedor para saber si muestra o no botón editar
      const permisoEditar = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: 'MODIFICAR_PROVEEDOR',
        },

      });
      // verifico si tiene permiso para ver los mensajes 
      $page.variables.permisoChat = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: 'CHAT_PROVEEDOR',
        },
      });
      // verificar si proveedor no está en WF activo
      //20251218 P160 se pasa por parametro paramTipoBusqueda que viene a su vez por parametro desde ab-consultar-proveedores
      const proveedorOk = await Actions.callChain(context, {
        chain: 'application:verificar_proveedor',
        params: {
          paramAccion: 'editar',
          paramNroProveedor: $variables.nroProveedor,
          paramTipoBusqueda: $variables.paramTipoBusqueda,
        },
      });

      $page.variables.wfActivo = proveedorOk.wfActivo;
      $page.variables.badgeMsg = $page.variables.badgeMsg + " " + proveedorOk.wfNombre + " - " + proveedorOk.wfInstancia;
      $page.variables.editarOk = proveedorOk.proveedorOk;

      $page.variables.flagHabilitaEditar = proveedorOk.proveedorOK  && permisoEditar.existe;

//MIF si tiene permitido editar busco solicitantes
if ( $page.variables.flagHabilitaEditar) {
      // Si es proveedor buscar lista de usuarios solicitantes
      const revisores = await Actions.callChain(context, {
        chain: 'application:buscar_revisores_voucher',
        params: {
          paramConstante: 'SOLICITADOR_PROVEEDORES_ID',
        },
      });

      $variables.solicitantes = revisores.listaSolicitadores;
      } 
      else {
        $variables.solicitantes=[];
      }

      $variables.buscando = false;


    }
  }

  return actInicioPagina;
});
