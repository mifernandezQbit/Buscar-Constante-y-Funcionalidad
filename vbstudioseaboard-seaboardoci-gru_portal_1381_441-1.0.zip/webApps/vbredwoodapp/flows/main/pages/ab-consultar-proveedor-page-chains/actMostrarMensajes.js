define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actMostrarMensajes extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $page.variables.mostrarDrawerMensajes = await this.generarRandom(context);
    }
  /**
    * @param {Object} context
    */
    async generarRandom(context) {
      const { $page, $flow, $application } = context;
      
      const guardarLog = await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'VER_MENSAJES',
          suscriptorId: $application.variables.suscriptor.id,
          numeroAn8: $application.variables.user.numeroAn8,
          proveedor: $application.variables.user.esProveedor,
          funcionalidad: 'CONSULTAR_PROVEEDOR',
          pagina: $application.currentPage.id,
          roles: $application.variables.userRoles.userRolesSt,
          usuario: $application.variables.user.ociUser,
          transaccion: $page.variables.nroProveedor.toString().padStart(8,'0'),
        },
      });

      let random = Math.random(1, 10);
      return random;
    }
  }

  return actMostrarMensajes;
});
