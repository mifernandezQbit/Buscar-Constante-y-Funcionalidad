define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actElegirSolicitanteConfirmar extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Es obligatorio elegir solicitante
      if ($variables.nroSolicitante === undefined || $variables.nroSolicitante === null || $variables.nroSolicitante === 0) {

        const notificarError = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            codigo: 'sin-usuario-revisor',
          },
        });

      }

      else {
        // guardar log 

        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'EDITAR',
            funcionalidad: 'MODIFICAR_PROVEEDOR',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            suscriptorId: $application.variables.user.suscriptorID,
            usuario: $application.variables.user.ociUser,
            observaciones: 'Solicitante: ' + $variables.nroSolicitante,
          },
        });

        // proceder a habilitar modo edición
        await this.ocultarBoton(context);

        $variables.actionJDE = 'C';
        $variables.actionWF = 'C';
        $variables.readFrom = 'LD';
        $variables.updateTo = 'EDI';
        $variables.firstTime = true;
        $variables.seccionOFAC = $application.variables.user.esProveedor ? false : true;
          $variables.seccionTesoreria = $application.variables.user.esProveedor ? false : true;
          $variables.seccionContabilidad = $application.variables.user.esProveedor ? false : true;
  $variables.seccionGral = true;
  $variables.seccionContactos = true;
  $variables.seccionImpuestos = true;
  
        if (await Actions.callComponentMethod(context, {
          selector: '#oj-dialog-solicitante',
          method: 'isOpen',
        })) {
          await Actions.callComponentMethod(context, {
            selector: '#oj-dialog-solicitante',
            method: 'close',
          });
        }
      }
    }

    /**
     * @param {Object} context
     */
    async ocultarBoton(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      let elem = document.getElementById('editarButton');
      elem.hidden = true;
    }
  }

  return actElegirSolicitanteConfirmar;
});
