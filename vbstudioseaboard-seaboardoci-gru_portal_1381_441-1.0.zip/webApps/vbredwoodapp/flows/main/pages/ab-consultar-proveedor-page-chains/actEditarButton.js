define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actEditarButton extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const guardarLog = await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'EDITAR',
          suscriptorId: $application.variables.suscriptor.id,
          numeroAn8: $application.variables.user.numeroAn8,
          proveedor: $application.variables.user.esProveedor,
          funcionalidad: 'CONSULTAR_PROVEEDOR',
          pagina: $application.currentPage.id,
          roles: $application.variables.userRoles.userRolesSt,
          usuario: $application.variables.user.ociUser,
          transaccion: $page.variables.nroProveedor.toString().padStart(8,'0'),
        },
      });

      // MIF validar seguridad si tiene permiso a editar para ese centro de costos.
      let seguridadOK = $application.variables.user.esProveedor ? true : false;
      if (!$application.variables.user.esProveedor) {
       seguridadOK = await Actions.callChain(context, {
        chain: 'application:validar_seguridad',
        params: {
          accionJDE: 'C',
          funcionalidad: 'MODIFICAR_PROVEEDOR',
          nroProveedor: $variables.nroProveedor,
          valor: $variables.paramUnidadNegocio,
        },
      });
      }
    if (seguridadOK) {
    // Si es proveedor elige solicitante, si es usuario el solicitante es él mismo
    if ($application.variables.user.esProveedor) {
        const ojDialogSolicitanteOpen = await Actions.callComponentMethod(context, {
          selector: '#oj-dialog-solicitante',
          method: 'open',
        });

    } 
    else {
      
$variables.nroSolicitante= $application.variables.user.numeroAn8;

        await Actions.callChain(context, {
          chain: 'actElegirSolicitanteConfirmar',
        });
    }
    }

    }

    /**
     * @param {Object} context
     */
    async ocultarBoton(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
    let elem = document.getElementById('editarButton');
    elem.hidden = true;
    }
  }

  return actEditarButton;
});
