define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actInicio extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const toApCruComprobantesDirecto = await Actions.navigateToPage(context, {
        page: 'ap-cru-comprobantes-directo',
        params: {
          paramMatching: $variables.paramMatching,
          paramTipoObjetoChat: $variables.paramTipoObjetoChat,
          paramFuncionalidadMenu: $variables.paramFuncionalidadMenu,
          paramModoCRU: $variables.paramModoCRU,
          paramTitulo: $variables.paramTitulo,
          paramVersionJDE: $variables.paramVersionJDE,
          paramNroProveedor: $variables.paramNroProveedor,
        },
      });
    }
  }

  return actInicio;
});
