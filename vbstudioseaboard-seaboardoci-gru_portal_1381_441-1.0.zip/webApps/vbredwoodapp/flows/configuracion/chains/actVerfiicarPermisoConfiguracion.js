define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actVerfiicarPermisoConfiguracion extends ActionChain {

    /**
     * Verifica si tiene permiso a las páginas de configuración
     * @param {Object} context
     */
    async run(context) {
      const { $flow, $application } = context;

      let verificarPermisosFuncionalidad = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'ADMINISTRAR_CONFIGURACION',
        },
      });

      $flow.variables.permisoOK = verificarPermisosFuncionalidad;
            if ($flow.variables.permisoOK === false) {
        await Actions.fireNotificationEvent(context, {
          summary: $application.variables.mensajesError[0],
        });

      }
    }
  }

  return actVerfiicarPermisoConfiguracion;
});
