define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class createUsuarioChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      // Sets the progress variable to true
      $page.variables.createUsuarioChainInProgress = true;
     
      try {
        // Validates Usuario form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'validation-group',
          },
        }, { id: 'validateUsuario' });

        if (!validateFormResult) {
          return;
        }

        const response = await Actions.callRest(context, {
          endpoint: 'businessObjects/getall_Usuario',
          uriParams: {
            q: "ociUser='" + $page.variables.usuario.ociUser + "' and suscriptorID='" + $application.variables.suscriptor.id + "'",
          },
        });

        if (response.body.count > 0) {
          await Actions.fireNotificationEvent(context, {
            message: 'Ya existe un usuario registrado con ese OCI User.',
            summary: 'Usuario Duplicado',
          });

   // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'CREAR_ERROR',
            funcionalidad: 'CONFIGURAR_USUARIO',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            transaccion: ($page.variables.usuario.nombre ?? "") + "|" +
              ($page.variables.usuario.email ?? "") + "|" +
              ($page.variables.usuario.ociUser ?? "") + "|" +
              ($page.variables.usuario.numeroAn8 ?? "") + "|" +
              ($page.variables.usuario.ciaDefault ?? "") + "|" +
              ($page.variables.usuario.estaActivo ?? "") + "|" +
              ($page.variables.usuario.esProveedor ?? "") + "|" +
              ($page.variables.usuario.aprobado ?? ""),
            observaciones: 'Usuario ya existe, no se crea.',
          },
        });

          return;
        }

        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/create_Usuario',
          body: $page.variables.usuario,
        }, { id: 'createUsuario' });
        
        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not create new Usuario: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
              summary: 'Save failed',
              message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }
        
        // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'CREAR_OK',
            funcionalidad: 'CONFIGURAR_USUARIO',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            transaccion:callRestResult.body.id + "|" +
              ($page.variables.usuario.nombre ?? "") + "|" +
              ($page.variables.usuario.email ?? "") + "|" +
              ($page.variables.usuario.ociUser ?? "") + "|" +
              ($page.variables.usuario.numeroAn8 ?? "") + "|" +
              ($page.variables.usuario.ciaDefault ?? "") + "|" +
              ($page.variables.usuario.estaActivo ?? "") + "|" +
              ($page.variables.usuario.esProveedor ?? "") + "|" +
              ($page.variables.usuario.aprobado ?? ""),
          },
        });

        await Actions.fireNotificationEvent(context, {
          summary: 'Usuario guardado',
          message: 'Registro creado correctamente',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        await Actions.navigateBack(context, {}, { id: 'navigateBack' });
      } finally {
        // Sets the progress variable to false
        $page.variables.createUsuarioChainInProgress = false;
      }
     
    }
  }

  return createUsuarioChain;
});
