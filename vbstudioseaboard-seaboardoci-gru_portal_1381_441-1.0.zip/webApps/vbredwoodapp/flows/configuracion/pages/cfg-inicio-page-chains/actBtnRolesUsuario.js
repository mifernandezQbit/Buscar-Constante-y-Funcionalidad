define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnRolesUsuario extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const toCfgRolUsuarioConsultar = await Actions.navigateToPage(context, {
        page: 'cfg-rol-usuario-consultar',
      });
    }
  }

  return actBtnRolesUsuario;
});
