define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnTipoChat extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const toCfgTipoChatConsultar = await Actions.navigateToPage(context, {
        page: 'cfg-tipo-chat-consultar',
      });
    }
  }

  return actBtnTipoChat;
});
