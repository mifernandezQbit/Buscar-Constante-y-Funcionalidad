define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnWorkflowMatriz extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application } = context;

      const toCfgWorkflowMatrizConsultar = await Actions.navigateToPage(context, {
        page: 'cfg-workflow-matriz-consultar',
      });
    }
  }

  return actBtnWorkflowMatriz;
});
