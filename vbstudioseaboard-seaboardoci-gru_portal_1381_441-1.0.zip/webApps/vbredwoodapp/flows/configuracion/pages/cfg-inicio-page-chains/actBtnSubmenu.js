define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnSubmenu extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const toCfgSumenuConsultar = await Actions.navigateToPage(context, {
        page: 'cfg-sumenu-consultar',
      });
    }
  }

  return actBtnSubmenu;
});
