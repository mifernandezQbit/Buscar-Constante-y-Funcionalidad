define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnPermisoFuncionalidad extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const toCfgPermisoFuncionalidadConsultar = await Actions.navigateToPage(context, {
        page: 'cfg-permiso-funcionalidad-consultar',
      });
    }
  }

  return actBtnPermisoFuncionalidad;
});
