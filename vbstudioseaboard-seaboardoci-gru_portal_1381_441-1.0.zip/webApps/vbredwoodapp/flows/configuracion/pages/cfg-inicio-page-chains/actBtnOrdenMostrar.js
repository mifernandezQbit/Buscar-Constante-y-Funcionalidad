define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnOrdenMostrar extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const toCfgOrdenAMostrarConsultar = await Actions.navigateToPage(context, {
        page: 'cfg-orden-a-mostrar-consultar',
      });
    }
  }

  return actBtnOrdenMostrar;
});
