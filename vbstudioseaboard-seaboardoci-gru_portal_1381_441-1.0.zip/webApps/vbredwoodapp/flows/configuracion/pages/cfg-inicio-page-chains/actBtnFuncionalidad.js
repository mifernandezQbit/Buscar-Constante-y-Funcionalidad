define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnFuncionalidad extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const toCfgFuncionalidadConsultar = await Actions.navigateToPage(context, {
        page: 'cfg-funcionalidad-consultar',
      });
    }
  }

  return actBtnFuncionalidad;
});
