define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnSuscriptor extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const toSuscriptorConsultar = await Actions.navigateToPage(context, {
        page: 'cfg-suscriptor-consultar',
      });
    }
  }

  return actBtnSuscriptor;
});
