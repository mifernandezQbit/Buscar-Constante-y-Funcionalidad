define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actEvtEnter extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {

      const { $page, $flow, $application, $constants, $variables, $eq, $co } = context;
      
    $flow.variables.permisoOK = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'ADMINISTRAR_CONFIGURACION',
        },
      });

      if ($flow.variables.permisoOK) {

        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'INGRESA',
            funcionalidad: 'ADMINISTRAR_CONFIGURACION',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
          },
        });

      $variables.menu = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONFIGURAR_MENU',
        },
      });
      $variables.rol =  await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONFIGURAR_ROL',
        },
      });
      $variables.permisosFuncionalidad =  await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONFIGURAR_PERMISO_FUNCIONALIDAD',
        },
      });


      $variables.funcionalidad =  await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONFIGURAR_FUNCIONALIDAD',
        },
      });

      $variables.usuarios =  await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONFIGURAR_USUARIO',
        },
      });

      $variables.rolesUsuario =  await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONFIGURAR_ROL_USUARIO',
        },
      });

      $variables.suscriptor =  await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONFIGURAR_SUSCRIPTOR',
        },
      });

      $variables.submenu =  await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONFIGURAR_SUBMENU',
        },
      });

      $variables.tipoChat =  await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONFIGURAR_TIPO_CHAT',
        },
      });
      $variables.ordenesMostrar =  await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONFIGURAR_ORDEN_MOSTRAR',
        },
      });
      $variables.viajesMostrar =  await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONFIGURAR_VIAJES_MOSTRAR',
        },
      });
      $variables.comprobantesMostrar =  await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONFIGURAR_VOUCHER_MOSTRAR',
        },
      });
      $variables.matrizComprobantes =  await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONFIGURAR_VOUCHER_MATRIZ',
        },
      });
      $variables.mensajes =  await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONFIGURAR_DICCIONARIO_MENSAJES',
        },
      });

      $variables.guiausoportal =  await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONFIGURAR_GUIA_USO_PORTAL',
        },
      });

      $variables.constantes =  await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONFIGURAR_CONSTANTE',
        },
      });

      $variables.workflowMatriz =  await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONFIGURAR_WORKFLOW_MATRIZ',
        },
      });

      $variables.workflowNodo =  await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONFIGURAR_WORKFLOW_NODO',
        },
      });

       $variables.log =  await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONSULTAR_ACCIONES',
        },
      });


     // P295: CRUD Pantalla Configurar Seguridad JDE - MN - 03/08/2026
      $variables.configurarSeguridadJDE = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad',
        params: {
          funcionalidad: 'CONFIGURAR_SEGURIDAD_JDE',
        },
      });

    }
    else {
             await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'INTENTO_INGRESO_NH',
            funcionalidad: 'ADMINISTRAR_CONFIGURACION',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
          },
        });

        const toMain = await Actions.navigateToFlow(context, {
          flow: 'main',
          target: 'parent',
          page: 'acceso-no-autorizado',
        });
    }
    }
  }

  return actEvtEnter;
});
