define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnMenu extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const toCfgMenuConsultar = await Actions.navigateToPage(context, {
        page: 'cfg-menu-consultar',
      });
    }
  }

  return actBtnMenu;
});
