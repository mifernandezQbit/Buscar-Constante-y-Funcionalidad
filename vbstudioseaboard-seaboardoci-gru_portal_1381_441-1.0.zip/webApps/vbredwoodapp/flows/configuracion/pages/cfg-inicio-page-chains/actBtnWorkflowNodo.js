define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnWorkflowNodo extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const toCfgConstanteConsultar = await Actions.navigateToPage(context, {
        page: 'cfg-workflow-nodo-consultar',
      });
    }
  }

  return actBtnWorkflowNodo;
});
