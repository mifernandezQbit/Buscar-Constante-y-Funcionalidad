define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnVoucherMostrar extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const toCfgVoucherAMostrarConsultar = await Actions.navigateToPage(context, {
        page: 'cfg-voucher-a-mostrar-consultar',
      });
    }
  }

  return actBtnVoucherMostrar;
});
