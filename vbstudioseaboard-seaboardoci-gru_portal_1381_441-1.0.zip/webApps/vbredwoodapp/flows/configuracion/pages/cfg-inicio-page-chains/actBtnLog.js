define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnLog extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const toCfgLogConsultar = await Actions.navigateToPage(context, {
        page: 'cfg-log-consultar',
      });
    }
  }

  return actBtnLog;
});
