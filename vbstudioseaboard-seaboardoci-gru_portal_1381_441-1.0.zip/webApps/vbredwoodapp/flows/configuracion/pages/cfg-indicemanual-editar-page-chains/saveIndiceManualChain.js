define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class saveIndiceManualChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Sets the progress variable to true
      $variables.saveIndiceManualChainInProgress = true;

      try {
        // Validates IndiceManual form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'validation-group',
          },
        });

        if (!validateFormResult) {
          return;
        }

        const payload = await this.preparePatchPayload(context, {
          updatedRecord: $variables.indiceManual,
          fetchedRecord: $variables.fetchedIndiceManual,
        });

        if (payload === undefined) {
          // Return from the action chain when there are no changes to save
          return;
        }

        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/update_IndiceManual',
          body: payload,
          uriParams: {
            'IndiceManual_Id': $variables.indiceManualId,
          },
        }, { id: 'saveIndiceManual' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not update IndiceManual: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
            summary: 'Falló al guardar',
            message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'EDITAR_OK',
            funcionalidad: 'CONFIGURAR_GUIA_USO_PORTAL',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            transaccion:
              ($variables.indiceManualId ?? "") + "|" +
              ($variables.indiceManual.indiceTab ?? "") + "|" +
              ($variables.indiceManual.indiceTitulo ?? ""),
          },
        });

        await Actions.fireNotificationEvent(context, {
          summary: 'Indice Guia Uso Portal actualizado',
          message: 'El registro fue actualizado exitosamente',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        await Actions.navigateBack(context, {}, { id: 'navigateBack' });
      } finally {
        // Sets the progress variable to false
        $variables.saveIndiceManualChainInProgress = false;
      }
    }

    /**
     * Prepares PATCH endpoint payload, calculates changed fields.
     * @param {any} updatedRecord
     * @param {any} fetchedRecord
     * @return {any} calculated payload
     */
    async preparePatchPayload(context, { updatedRecord, fetchedRecord }) {
      let payload = updatedRecord;
      let hasChanges = true;
      if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
        // filter the object to only those top-level fields that differ from the original fetched record
        payload = Object.fromEntries(Object.entries(payload).filter(([field, value]) =>
          JSON.stringify(value) !== JSON.stringify(fetchedRecord?.[field])
        ));
        hasChanges = Object.keys(payload).length > 0;
      }

      if (!hasChanges) {
        payload = undefined;
      }

      return payload;
    }

  }

  return saveIndiceManualChain;
});
