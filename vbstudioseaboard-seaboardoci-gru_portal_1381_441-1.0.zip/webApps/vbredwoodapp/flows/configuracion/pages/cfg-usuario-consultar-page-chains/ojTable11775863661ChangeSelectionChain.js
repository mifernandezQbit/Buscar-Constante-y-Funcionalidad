define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable11775863661ChangeSelectionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.usuarioId
     * @param {string} params.ociUser
     */
    async run(context, { usuarioId, ociUser }) {
      const { $page, $flow, $application } = context;
      $page.variables.oj_table_1177586366_1SelectedId = usuarioId;
      $page.variables.selectedOciUser = ociUser;
    }
  }

  return ojTable11775863661ChangeSelectionChain;
});