define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $page.variables.criterioBusqueda = [{
          attribute: 'suscriptorID',
          op: '$eq',
          value: $application.variables.suscriptor.id,
      }];
      if (($page.variables.nombre !== undefined) && ($page.variables.nombre !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'nombre',
          op: '$co',
          value: $page.variables.nombre ,
        }); 
      }
      if (($page.variables.email !== undefined) && ($page.variables.email !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'email',
          op: '$co',
          value: $page.variables.email ,
        });
      }
      if (($page.variables.estaActivo !== undefined) && ($page.variables.estaActivo !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'estaActivo',
          op: '$eq',
          value: $page.variables.estaActivo ,
        });
      }
      if (($page.variables.esProveedor !== undefined) && ($page.variables.esProveedor !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'esProveedor',
          op: '$eq',
          value: $page.variables.esProveedor ,
        });
      }
       if (($page.variables.numeroAn8 !== undefined) && ($page.variables.numeroAn8 !== 0)) {
        $page.variables.criterioBusqueda.push({
          attribute: 'numeroAn8',
          op: '$eq',
          value: $page.variables.numeroAn8 ,
        });
      }

      // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'BUSCAR',
          funcionalidad: 'CONFIGURAR_USUARIO',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion:
            ($page.variables.nombre ?? "") + "|" +
            ($page.variables.email ?? "") + "|" +
            ($page.variables.estaActivo ?? "") + "|" +
            ($page.variables.esProveedor ?? "") + "|" +
            ($page.variables.numeroAn8 ?? ""),
        },
      });

    }
  }

  return ButtonActionChain;
});
