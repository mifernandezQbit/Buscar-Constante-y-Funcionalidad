define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditUsuarioChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.usuarioId
     */
    async run(context, { usuarioId }) {
      const { $page, $flow, $application } = context;
      
      const guardarLog2 = await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          funcionalidad: 'CONFIGURAR_USUARIO',
          accion: 'EDITAR',
          pagina: $flow.currentPage,
          proveedor: $application.variables.user.esProveedor,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          numeroAn8: $application.variables.user.numeroAn8,
          transaccion: usuarioId,
          roles: $application.variables.userRoles.userRolesSt,
        },
      });
      
      
      const navigateToPageConfiguracionEditUsuarioResult = await Actions.navigateToPage(context, {
        page: 'cfg-usuario-editar',
        params: {
          usuarioId: usuarioId,
        },
      });
    }
  }

  return navigateToEditUsuarioChain;
});
