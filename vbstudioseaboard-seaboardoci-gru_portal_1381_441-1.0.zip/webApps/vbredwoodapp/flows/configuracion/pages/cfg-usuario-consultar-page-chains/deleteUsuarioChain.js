define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class deleteUsuarioChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.usuarioId
     * @param {string} params.ociUser
     */
    async run(context, { usuarioId, ociUser }) {
      const { $page, $flow, $application, $current } = context;
     

        // ---- Guardar Log de Acceso Restringido ---- //
      
      

          const guardarLog2 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              funcionalidad: 'CONFIGURAR_USUARIO',
              accion: 'ELIMINAR',
              pagina: $flow.currentPage,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
              transaccion: [[ $application.variables.selectedCompany.company ]]
+ '|'
+ [[usuarioId]]
+ '|'
+ [[ociUser]],
              roles: $application.variables.userRoles.userRolesSt,
            },
          });

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/delete_Usuario',
        uriParams: {
          'Usuario_Id': usuarioId,
        },
      }, { id: 'deleteUsuario' });

      if (!callRestResult.ok) {

        await Actions.fireNotificationEvent(context, {
          summary: 'Error al eliminar',
          message: [[ callRestResult.body?.detail ||
           callRestResult.body?.['o:errorDetails']?.[0]?.detail ||
   'No se pudo eliminar el usuario.' ]],
          displayMode: 'persist',
          type: 'error',
        }, { id: 'fireErrorNotification' });

        return;
      }

await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
              funcionalidad: 'CONFIGURAR_USUARIO',
              accion: 'ELIMINAR_OK',
              pagina: $flow.currentPage,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
              transaccion: usuarioId,
              roles: $application.variables.userRoles.userRolesSt,
            },
          });

      // Resets selection variable
      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.oj_table_1177586366_1SelectedId',
        ],
      }, { id: 'resetSelection' });

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.usuarioListSDP,
        refresh: null,
      }, { id: 'refreshDataProvider' });

      await Actions.fireNotificationEvent(context, {
        summary: 'Usuario eliminada',
        message: `Usuario [${usuarioId}] eliminada correctamente`,
        displayMode: 'transient',
        type: 'confirmation',
      }, { id: 'fireSuccessNotification' });
    

    
  }
  }

  return deleteUsuarioChain;
});
