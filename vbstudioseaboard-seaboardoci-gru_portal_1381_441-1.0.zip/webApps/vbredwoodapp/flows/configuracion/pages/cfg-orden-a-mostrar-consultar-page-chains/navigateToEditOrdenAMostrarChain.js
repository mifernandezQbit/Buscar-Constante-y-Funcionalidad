define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditOrdenAMostrarChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.ordenAMostrarId
     */
    async run(context, { ordenAMostrarId }) {
      const { $page, $flow, $application } = context;
         
      const guardarLog2 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
                  funcionalidad: 'CONFIGURAR_ORDEN_MOSTRAR',
                  accion: 'EDITAR', // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
                  pagina: $flow.currentPage,
                  proveedor: $application.variables.user.esProveedor,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  numeroAn8: $application.variables.user.numeroAn8,
                  transaccion: ordenAMostrarId,
                  roles: $application.variables.userRoles.userRolesSt,
                },
          });

      const navigateToPageCfgOrdenAMostrarEditarResult = await Actions.navigateToPage(context, {
        page: 'cfg-orden-a-mostrar-editar',
        params: {
          ordenAMostrarId: ordenAMostrarId,
        },
      });
    }
  }

  return navigateToEditOrdenAMostrarChain;
});
