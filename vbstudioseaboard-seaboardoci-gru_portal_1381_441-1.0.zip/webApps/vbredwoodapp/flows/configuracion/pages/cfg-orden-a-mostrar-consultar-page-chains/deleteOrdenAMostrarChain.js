define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class deleteOrdenAMostrarChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.ordenAMostrarId 
     */
    async run(context, { ordenAMostrarId }) {
      const { $page, $flow, $application } = context;

          const guardarLog2 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
                  funcionalidad: 'CONFIGURAR_ORDEN_MOSTRAR',
                  accion: 'ELIMINAR', // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
                  pagina: $flow.currentPage,
                  proveedor: $application.variables.user.esProveedor,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  numeroAn8: $application.variables.user.numeroAn8,
                  transaccion: ordenAMostrarId,
                  roles: $application.variables.userRoles.userRolesSt,
                },
          });


      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/delete_OrdenAMostrar',
        uriParams: {
          'OrdenAMostrar_Id': ordenAMostrarId,
        },
      }, { id: 'deleteOrdenAMostrar' });

      if (!callRestResult.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Falló al eliminar',
          message: `No pudo eliminar el registro: estado ${callRestResult.status}`,
          displayMode: 'persist',
          type: 'error',
        }, { id: 'fireErrorNotification' });

        return;
      }

      // P286: Ajuste Tabla Historica de Acciones
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'ELIMINAR_OK',
          funcionalidad: 'CONFIGURAR_ORDEN_MOSTRAR',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion: ordenAMostrarId,
        },
      });
      // Resets selection variable
      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.oj_table_992844127_1SelectedId',
        ],
      }, { id: 'resetSelection' });

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.ordenAMostrarListSDP,
        refresh: null,
      }, { id: 'refreshDataProvider' });

      await Actions.fireNotificationEvent(context, {
        summary: 'OrdenAMostrar eliminada',
        message: `OrdenAMostrar [${ordenAMostrarId}] eliminada correctamente`,
        displayMode: 'transient',
        type: 'confirmation',
      }, { id: 'fireSuccessNotification' });
    }
  }

  return deleteOrdenAMostrarChain;
});
