define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable9928441271ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.ordenAMostrarId
     */
    async run(context, { ordenAMostrarId }) {
      const { $page, $flow, $application } = context;
      $page.variables.oj_table_992844127_1SelectedId = ordenAMostrarId;
    }
  }

  return ojTable9928441271ChangeSelectionChain;
});
