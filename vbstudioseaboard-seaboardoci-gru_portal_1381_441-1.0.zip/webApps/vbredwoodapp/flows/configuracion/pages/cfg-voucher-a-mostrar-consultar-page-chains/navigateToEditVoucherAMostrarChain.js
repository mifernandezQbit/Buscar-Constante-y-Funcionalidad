define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditVoucherAMostrarChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.voucherAMostrarId
     */
    async run(context, { voucherAMostrarId }) {
      const { $page, $flow, $application } = context;
        const guardarLog2 = await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
              funcionalidad: 'CONFIGURAR_VOUCHER_MOSTRAR',
              accion: 'EDITAR', // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
              pagina: $flow.currentPage,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
              transaccion: voucherAMostrarId,
              roles: $application.variables.userRoles.userRolesSt,
            },
      });
      const navigateToPageCfgVoucherAMostrarEditarResult = await Actions.navigateToPage(context, {
        page: 'cfg-voucher-a-mostrar-editar',
        params: {
          voucherAMostrarId: voucherAMostrarId,
        },
      });
    }
  }

  return navigateToEditVoucherAMostrarChain;
});
