define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable7881672371ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.voucherAMostrarId
     */
    async run(context, { voucherAMostrarId }) {
      const { $page, $flow, $application } = context;
      $page.variables.oj_table_788167237_1SelectedId = voucherAMostrarId;
    }
  }

  return ojTable7881672371ChangeSelectionChain;
});
