define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class deleteVoucherAMostrarChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.voucherAMostrarId 
     */
    async run(context, { voucherAMostrarId }) {
      const { $page, $flow, $application } = context;

      
      const guardarLog2 = await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          funcionalidad: 'CONFIGURAR_VOUCHER_MOSTRAR',
          accion: 'ELIMINAR',
          pagina: $flow.currentPage,
          proveedor: $application.variables.user.esProveedor,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          numeroAn8: $application.variables.user.numeroAn8,
          transaccion: [[$application.variables.selectedCompany.company]] + '|' + [[voucherAMostrarId]],
          roles: $application.variables.userRoles.userRolesSt,
        },
      });
      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/delete_VoucherAMostrar',
        uriParams: {
          'VoucherAMostrar_Id': voucherAMostrarId,
        },
      }, { id: 'deleteVoucherAMostrar' });

      if (!callRestResult.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Error al eliminar',
          message: `No se pudo eliminar el registro: estado ${callRestResult.status}`,
          displayMode: 'persist',
          type: 'error',
        }, { id: 'fireErrorNotification' });

        return;
      }

 await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          funcionalidad: 'CONFIGURAR_VOUCHER_MOSTRAR',
          accion: 'ELIMINAR_OK',
          pagina: $flow.currentPage,
          proveedor: $application.variables.user.esProveedor,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          numeroAn8: $application.variables.user.numeroAn8,
          transaccion: voucherAMostrarId,
          roles: $application.variables.userRoles.userRolesSt,
        },
      });
      // Resets selection variable
      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.oj_table_788167237_1SelectedId',
        ],
      }, { id: 'resetSelection' });

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.voucherAMostrarListSDP,
        refresh: null,
      }, { id: 'refreshDataProvider' });

      await Actions.fireNotificationEvent(context, {
        summary: 'VoucherAMostrar eliminada',
        message: `VoucherAMostrar [${voucherAMostrarId}] eliminada correctamente`,
        displayMode: 'transient',
        type: 'confirmation',
      }, { id: 'fireSuccessNotification' });
    }
  }

  return deleteVoucherAMostrarChain;
});
