define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class createOrdenAMostrarChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      // Sets the progress variable to true
      $page.variables.createOrdenAMostrarChainInProgress = true;

      try {
        // Validates OrdenAMostrar form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'validation-group',
          },
        }, { id: 'validateOrdenAMostrar' });

        if (!validateFormResult) {
          return;
        }

        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/create_OrdenAMostrar',
          body: $page.variables.ordenAMostrar,
        }, { id: 'createOrdenAMostrar' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not create new OrdenAMostrar: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
              summary: 'Error al guardar',
              message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'CREAR_OK',
            funcionalidad: 'CONFIGURAR_ORDEN_MOSTRAR',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            transaccion:
              (callRestResult.body.id ?? "") + "|" +
              ($page.variables.ordenAMostrar.tipoOrden ?? "") + "|" +
              ($page.variables.ordenAMostrar.estadoSiguiente ?? "") + "|" +
              ($page.variables.ordenAMostrar.descripcionEstado ?? ""),
          },
        });

        await Actions.fireNotificationEvent(context, {
          summary: 'OrdenAMostrar guardada',
          message: 'El registro fue creado exitosamente',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        await Actions.navigateBack(context, {}, { id: 'navigateBack' });
      } finally {
        // Sets the progress variable to false
        $page.variables.createOrdenAMostrarChainInProgress = false;
      }
    }
  }

  return createOrdenAMostrarChain;
});
