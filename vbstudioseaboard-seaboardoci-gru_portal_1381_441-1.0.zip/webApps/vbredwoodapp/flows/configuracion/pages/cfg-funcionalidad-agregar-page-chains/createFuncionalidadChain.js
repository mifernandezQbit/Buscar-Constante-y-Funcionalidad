define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class createFuncionalidadChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      // Sets the progress variable to true
      $page.variables.createFuncionalidadChainInProgress = true;

      try {
        // Validates Funcionalidad form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'validation-group',
          },
        }, { id: 'validateFuncionalidad' });

        if (!validateFormResult) {
          return;
        }

        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/create_Funcionalidad',
          body: $page.variables.funcionalidad,
        }, { id: 'createFuncionalidad' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not create new Funcionalidad: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
              summary: 'Error al guardar',
              message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // P286: Ajuste Tabla Historica de Acciones
        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'CREAR_OK',
            funcionalidad: 'CONFIGURAR_FUNCIONALIDAD',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            transaccion:
              (callRestResult.body.id ?? "") + "|" +
              ($page.variables.funcionalidad.funcionalidad ?? "") + "|" +
              ($page.variables.funcionalidad.descripcion ?? "") + "|" +
              ($page.variables.funcionalidad.usadaPor ?? "") + "|" +
              ($page.variables.funcionalidad.tipoObjetoChat ?? "") + "|" +
              ($page.variables.funcionalidad.incluirEnMenu ?? ""),
          },
        });

        await Actions.fireNotificationEvent(context, {
          summary: 'Funcionalidad creada',
          message: 'El registro fue creado exitosamente',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        await Actions.navigateBack(context, {}, { id: 'navigateBack' });
      } finally {
        // Sets the progress variable to false
        $page.variables.createFuncionalidadChainInProgress = false;
      }
    }
  }

  return createFuncionalidadChain;
});
