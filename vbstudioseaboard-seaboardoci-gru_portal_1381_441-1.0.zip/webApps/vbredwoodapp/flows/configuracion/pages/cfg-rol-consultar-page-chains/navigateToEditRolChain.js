define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditRolChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.rolId
     */
    async run(context, { rolId }) {
      const { $page, $flow, $application } = context;
      
       const guardarLog2 = await Actions.callChain(context, {
         chain: 'application:guardar_log',
         params: {
           funcionalidad: 'CONFIGURAR_ROL',
           accion: 'EDITAR',
           pagina: $flow.currentPage,
           proveedor: $application.variables.user.esProveedor,
           suscriptorId: $application.variables.suscriptor.id,
           usuario: $application.variables.user.ociUser,
           numeroAn8: $application.variables.user.numeroAn8,
           transaccion: rolId,
           roles: $application.variables.userRoles.userRolesSt,
         },
       });
      const navigateToPageCfgRolEditarResult = await Actions.navigateToPage(context, {
        page: 'cfg-rol-editar',
        params: {
          rolId: rolId,
        },
      });
    }
  }

  return navigateToEditRolChain;
});
