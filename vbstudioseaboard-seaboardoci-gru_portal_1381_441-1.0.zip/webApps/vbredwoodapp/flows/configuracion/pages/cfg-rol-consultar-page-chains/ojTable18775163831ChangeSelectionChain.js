define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable18775163831ChangeSelectionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.rolId
     */
    async run(context, { rolId }) {
      const { $page, $flow, $application } = context;
      $page.variables.oj_table_1877516383_1SelectedId = rolId;
    }
  }

  return ojTable18775163831ChangeSelectionChain;
});
