define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnBuscar extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $eq, $ge } = context;

    
      $page.variables.criterioBusqueda = [
  {
    attribute: 'suscriptorID',
    op: '$eq',
    value: $application.variables.suscriptor.id,
  },
];

      if (($page.variables.accion !== undefined) && ($page.variables.accion !== "")) {
        $page.variables.criterioBusqueda.push({
  attribute: 'accion',
  op: '$eq',
  value: $page.variables.accion,
});
      }
            if (($page.variables.fecha !== undefined) && ($page.variables.fecha !== "")) {
        $page.variables.criterioBusqueda.push({
  attribute: 'fechaCreacion',
  op: '$ge',
  value: $page.variables.fecha,
});
      }
            if (($page.variables.nroAn8 !== undefined) && ($page.variables.nroAn8 !== "")) {
        $page.variables.criterioBusqueda.push({
  attribute: 'numeroAn8',
  op: '$eq',
  value: $page.variables.nroAn8,
});
      }
       if (($page.variables.pagina !== undefined) && ($page.variables.pagina !== "")) {
        $page.variables.criterioBusqueda.push({
  attribute: 'pagina',
  op: '$eq',
  value: $page.variables.pagina,
});
      }
                  if (($page.variables.usuario !== undefined) && ($page.variables.usuario !== "")) {
        $page.variables.criterioBusqueda.push({
  attribute: 'usuarioOCI',
  op: '$eq',
  value: $page.variables.usuario,
});
      }

      // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'BUSCAR',
          funcionalidad: 'CONSULTAR_ACCIONES',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion:
            ($page.variables.accion ?? "") + "|" +
            ($page.variables.fecha ?? "") + "|" +
            ($page.variables.nroAn8 ?? "") + "|" +
            ($page.variables.pagina ?? "") + "|" +
            ($page.variables.usuario ?? ""),
        },
      });


    }
  }

  return actBtnBuscar;
});
