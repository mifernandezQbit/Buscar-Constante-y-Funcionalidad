define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable19421095241ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.logId
     */
    async run(context, { logId }) {
      const { $page, $flow, $application } = context;
      $page.variables.oj_table_1942109524_1SelectedId = logId;
    }
  }

  return ojTable19421095241ChangeSelectionChain;
});
