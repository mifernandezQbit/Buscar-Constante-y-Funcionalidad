define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $page.variables.criterioBusqueda = [{
          attribute: 'suscriptorID',
          op: '$eq',
          value: $application.variables.suscriptor.id,
      }];
      if (($page.variables.menu !== undefined) && ($page.variables.menu !== "")) {
        $variables.criterioBusqueda.push({
          attribute: 'menuID',
          op: '$eq',
          value: $page.variables.menu ,
        });
      }
      if (($page.variables.nombreOpcion !== undefined) && ($page.variables.nombreOpcion !== "")) {
        $variables.criterioBusqueda.push({
          attribute: 'nombreOpcion',
          op: '$co',
          value: $page.variables.nombreOpcion ,
        });
      }
      if (($page.variables.funcionalidad !== undefined) && ($page.variables.funcionalidad !== "")) {
        $variables.criterioBusqueda.push({
          attribute: 'funcionalidadID',
          op: '$eq',
          value: $page.variables.funcionalidad ,
        });
      }
       if (($page.variables.versionJDE !== undefined) && ($page.variables.versionJDE !== "")) {
        $variables.criterioBusqueda.push({
          attribute: 'versionJDE',
          op: '$co',
          value: $page.variables.versionJDE ,
        });
      }

      // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'BUSCAR',
          funcionalidad: 'CONFIGURAR_SUBMENU',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion:
            ($page.variables.menu ?? "") + "|" +
            ($page.variables.nombreOpcion ?? "") + "|" +
            ($page.variables.funcionalidad ?? "") + "|" +
            ($page.variables.versionJDE ?? ""),
        },
      });
    }
  }

  return ButtonActionChain;
});
