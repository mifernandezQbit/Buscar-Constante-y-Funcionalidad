define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditSubmenuChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.submenuId
     */
    async run(context, { submenuId }) {
      const { $page, $flow, $application } = context;
      const guardarLog2 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
                  funcionalidad: 'CONFIGURAR_SUBMENU',
                  accion: 'EDITAR', // P286: Ajuste Tabla Historica de Acciones -
                  pagina: $flow.currentPage,
                  proveedor: $application.variables.user.esProveedor,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  numeroAn8: $application.variables.user.numeroAn8,
                  transaccion: submenuId ,
                  roles: $application.variables.userRoles.userRolesSt,
                },
          });

      const navigateToPageCfgSubmenuEditarResult = await Actions.navigateToPage(context, {
        page: 'cfg-submenu-editar',
        params: {
          submenuId: submenuId,
        },
      });
    }
  }

  return navigateToEditSubmenuChain;
});
