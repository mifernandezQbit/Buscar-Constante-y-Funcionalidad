define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class deleteSubmenuChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.submenuId 
     */
    async run(context, { submenuId }) {
      const { $page, $flow, $application } = context;
     const guardarLog2 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
                  funcionalidad: 'CONFIGURAR_SUBMENU',
                  accion: 'ELIMINAR', // P286: Ajuste Tabla Historica de Acciones -
                  pagina: $flow.currentPage,
                  proveedor: $application.variables.user.esProveedor,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  numeroAn8: $application.variables.user.numeroAn8,
                  transaccion: submenuId ,
                  roles: $application.variables.userRoles.userRolesSt,
                },
          });
      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/delete_Submenu',
        uriParams: {
          'Submenu_Id': submenuId,
        },
      }, { id: 'deleteSubmenu' });

      if (!callRestResult.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Error al eliminar',
          message: `No se pudo eliminar el registro: estado ${callRestResult.status}`,
          displayMode: 'persist',
          type: 'error',
        }, { id: 'fireErrorNotification' });

        return;
      }

 await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
                  funcionalidad: 'CONFIGURAR_SUBMENU',
                  accion: 'ELIMINAR_OK', // P286: Ajuste Tabla Historica de Acciones 
                  pagina: $flow.currentPage,
                  proveedor: $application.variables.user.esProveedor,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  numeroAn8: $application.variables.user.numeroAn8,
                  transaccion: submenuId ,
                  roles: $application.variables.userRoles.userRolesSt,
                },
          });
      // Resets selection variable
      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.oj_table_2063306581_1SelectedId',
        ],
      }, { id: 'resetSelection' });

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.submenuListSDP,
        refresh: null,
      }, { id: 'refreshDataProvider' });

      await Actions.fireNotificationEvent(context, {
        summary: 'Submenu eliminada',
        message: `Submenu [${submenuId}] eliminada correctamente`,
        displayMode: 'transient',
        type: 'confirmation',
      }, { id: 'fireSuccessNotification' });
    }
  }

  return deleteSubmenuChain;
});
