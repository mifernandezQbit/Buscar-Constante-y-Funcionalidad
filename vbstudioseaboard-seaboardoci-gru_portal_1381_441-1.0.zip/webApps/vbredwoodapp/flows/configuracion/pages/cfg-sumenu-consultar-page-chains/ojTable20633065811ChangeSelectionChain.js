define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable20633065811ChangeSelectionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.submenuId
     */
    async run(context, { submenuId }) {
      const { $page, $flow, $application } = context;
      $page.variables.oj_table_2063306581_1SelectedId = submenuId;
    }
  }

  return ojTable20633065811ChangeSelectionChain;
});
