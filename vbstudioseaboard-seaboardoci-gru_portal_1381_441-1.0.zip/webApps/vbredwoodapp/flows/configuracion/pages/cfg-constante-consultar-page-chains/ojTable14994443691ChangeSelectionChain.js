define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable14994443691ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.constanteId
     */
    async run(context, { constanteId }) {
      const { $page, $flow, $application } = context;
      $page.variables.oj_table_1499444369_1SelectedId = constanteId;
    }
  }

  return ojTable14994443691ChangeSelectionChain;
});
