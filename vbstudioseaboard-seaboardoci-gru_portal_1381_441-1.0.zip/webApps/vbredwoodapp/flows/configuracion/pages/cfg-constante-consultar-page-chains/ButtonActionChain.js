define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $page.variables.criterioBusqueda = [{
          attribute: 'suscriptorID',
          op: '$eq',
          value: $application.variables.suscriptor.id,
      }];
      if (($page.variables.modulo !== undefined) && ($page.variables.modulo !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'modulo',
          op: '$co',
          value: $page.variables.modulo ,
        });
      }
      if (($page.variables.descripcion !== undefined) && ($page.variables.descripcion !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'descripcion',
          op: '$co',
          value: $page.variables.descripcion ,
        });
      }
      if (($page.variables.clave !== undefined) && ($page.variables.clave !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'clave',
          op: '$co',
          value: $page.variables.clave ,
        });
      }
      // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'BUSCAR',
          funcionalidad: 'CONFIGURAR_CONSTANTE',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion:
            ($page.variables.modulo ?? "") + "|" +
            ($page.variables.clave ?? "") + "|" +
            ($page.variables.descripcion ?? ""),
        },
      });
    }
  }
  
  return ButtonActionChain;
});
