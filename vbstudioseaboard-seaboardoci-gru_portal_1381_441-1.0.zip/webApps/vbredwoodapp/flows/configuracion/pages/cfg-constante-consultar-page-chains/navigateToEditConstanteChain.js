define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditConstanteChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.constanteId
     */
    async run(context, { constanteId }) {
      const { $page, $flow, $application } = context;
      const guardarLog2 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
                  funcionalidad: 'CONFIGURAR_CONSTANTE',
                  accion: 'EDITAR', // P286: Ajuste Tabla Historica de Acciones
                  pagina: $flow.currentPage,
                  proveedor: $application.variables.user.esProveedor,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  numeroAn8: $application.variables.user.numeroAn8,
                  transaccion: constanteId,
                  roles: $application.variables.userRoles.userRolesSt,
                },
          });
      const navigateToPageCfgConstanteEditarResult = await Actions.navigateToPage(context, {
        page: 'cfg-constante-editar',
        params: {
          constanteId: constanteId,
        },
      });
    }
  }

  return navigateToEditConstanteChain;
});
