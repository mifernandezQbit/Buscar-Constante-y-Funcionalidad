define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actValidarNroOrdenCompra extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if (value !== undefined && value.trim() !== "" && value !== "no" && value !== "opcional" && value !== "obligatorio" ) {

        await Actions.fireNotificationEvent(context, {
          summary: 'La opción ingresada para número de orden de compra no es correcta.',
          message: 'Los valores permitidos son: no, opcional y obligatorio.',
        });
        
      }
    }
  }

  return actValidarNroOrdenCompra;
});
