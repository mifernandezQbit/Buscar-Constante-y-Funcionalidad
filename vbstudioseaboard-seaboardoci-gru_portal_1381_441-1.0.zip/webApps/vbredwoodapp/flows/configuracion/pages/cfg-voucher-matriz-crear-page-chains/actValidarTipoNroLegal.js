define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actValidarTipoNroLegal extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      //if (value !== undefined && value.trim() !== "" && value !== "libre" && value !== "automatico" && value !== "legal" ) {
//
      //  await Actions.fireNotificationEvent(context, {
      //    summary: 'Tipo de numeración de comprobante incorrecta.',
      //    message: 'Los valores permitidos son: legal, automatico y libre (en minúsculas y sin acentuación).',
      //  });
      //  
      //}
    }
  }

  return actValidarTipoNroLegal;
});
