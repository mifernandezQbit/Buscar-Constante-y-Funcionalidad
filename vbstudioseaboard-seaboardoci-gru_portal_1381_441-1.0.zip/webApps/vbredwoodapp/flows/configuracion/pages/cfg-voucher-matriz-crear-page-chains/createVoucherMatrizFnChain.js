define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class createVoucherMatrizFnChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      // Sets the progress variable to true
      $variables.createVoucherMatrizFnChainInProgress = true;
      $variables.voucherMatrizFn.tipoNroVoucher =$variables.tipoNroVoucherArr[$variables.voucherMatrizFn.tipoNroVoucher] ?  $variables.tipoNroVoucherArr[$variables.voucherMatrizFn.tipoNroVoucher].data: "legal";
      $variables.voucherMatrizFn.ordenCompra = $variables.ordenCompraArr[$variables.voucherMatrizFn.ordenCompra] ? $variables.ordenCompraArr[$variables.voucherMatrizFn.ordenCompra].data : "no";
      $variables.voucherMatrizFn.tipoBusqConceptos =$variables.tipoBusqConcepto[$variables.voucherMatrizFn.tipoBusqConceptos] ? $variables.tipoBusqConcepto[$variables.voucherMatrizFn.tipoBusqConceptos].data: "";

      if (!($variables.voucherMatrizFn.usaMatrizRetenciones)){
        $variables.voucherMatrizFn.usaMatrizRetenciones = false;
      }

      if (!($variables.voucherMatrizFn.usaMatrizPercepciones)){
        $variables.voucherMatrizFn.usaMatrizPercepciones = false;
      }

      if (!($variables.voucherMatrizFn.validarCAE)){
        $variables.voucherMatrizFn.validarCAE = false;
      }

      if (!($variables.voucherMatrizFn.invertirSigno)){
        $variables.voucherMatrizFn.invertirSigno = false;
      }

      try {
        // Validates VoucherMatrizFn form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'validation-group',
          },
        }, { id: 'validateVoucherMatrizFn' });

        if (!validateFormResult) {
          return;
        }

        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/create_VoucherMatrizFn',
          body: $variables.voucherMatrizFn,
        }, { id: 'createVoucherMatrizFn' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not create new VoucherMatrizFn: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
              summary: 'Error al guardar',
              message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'CREAR_OK',
            funcionalidad: 'CONFIGURAR_VOUCHER_MATRIZ',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            transaccion:
              ($variables.voucherMatrizFn.funcionalidadPortal ?? "") + "|" +
              ($variables.voucherMatrizFn.tipoDocARCA ?? "") + "|" +
              ($variables.voucherMatrizFn.versionP0411 ?? "") + "|" +
              ($variables.voucherMatrizFn.tipoNroVoucher ?? "") + "|" +
              ($variables.voucherMatrizFn.ordenCompra ?? "") + "|" +
              ($variables.voucherMatrizFn.tipoBusqConceptos ?? "") + "|" +
              ($variables.voucherMatrizFn.usaMatrizRetenciones ?? "") + "|" +
              ($variables.voucherMatrizFn.usaMatrizPercepciones ?? "") + "|" +
              ($variables.voucherMatrizFn.validarCAE ?? "") + "|" +
              ($variables.voucherMatrizFn.invertirSigno ?? "")
          },
        });

        await Actions.fireNotificationEvent(context, {
          summary: 'VoucherMatrizFn guardado',
          message: 'Registro creado correctamente',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        await Actions.navigateBack(context, {}, { id: 'navigateBack' });
      } finally {
        // Sets the progress variable to false
        $variables.createVoucherMatrizFnChainInProgress = false;
      }
    }
  }

  return createVoucherMatrizFnChain;
});
