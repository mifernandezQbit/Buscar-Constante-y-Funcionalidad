define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable1194212051ChangeSelectionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.suscriptorId
     */
    async run(context, { suscriptorId }) {
      const { $page, $flow, $application } = context;
      $page.variables.oj_table_119421205_1SelectedId = suscriptorId;
    }
  }

  return ojTable1194212051ChangeSelectionChain;
});
