define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditSuscriptorChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.suscriptorId
     */
    async run(context, { suscriptorId }) {
      const { $page, $flow, $application } = context;
     const guardarLog2 = await Actions.callChain(context, {
       chain: 'application:guardar_log',
       params: {
         funcionalidad: 'CONFIGURAR_SUSCRIPTOR',
         accion: 'EDITAR',
         pagina: $flow.currentPage,
         proveedor: $application.variables.user.esProveedor,
         suscriptorId: $application.variables.suscriptor.id,
         usuario: $application.variables.user.ociUser,
         numeroAn8: $application.variables.user.numeroAn8,
         transaccion: suscriptorId,
         roles: $application.variables.userRoles.userRolesSt,
       },
     });


      const navigateToPageConfiguracionEditarSuscriptorResult = await Actions.navigateToPage(context, {
        page: 'cfg-suscriptor-editar',
        params: {
          suscriptorId: suscriptorId,
        },
      });
    }
  }

  return navigateToEditSuscriptorChain;
});
