define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadSuscriptorChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.suscriptorId 
     */
    async run(context, { suscriptorId }) {
      const { $page, $flow, $application } = context;
      const verificarPermisos = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: 'CONFIGURAR_SUSCRIPTOR',
        },
      });
      if (verificarPermisos.existe === false) {
        const guardarLog = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'INTENTO_INGRESO_NH',
            funcionalidad: 'CONFIGURAR_SUSCRIPTOR',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
          },
        });

       
         const toMain = await Actions.navigateToFlow(context, {
          flow: 'main',
          target: 'parent',
          page: 'acceso-no-autorizado',
        });
      } else {
        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'INGRESA',
            funcionalidad: 'CONFIGURAR_SUSCRIPTOR',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            transaccion: suscriptorId ? suscriptorId:"",
          },
        });
        
      }
      // Test valid input
      if (true && suscriptorId !== undefined) {
        // Clears Suscriptor data the variable holds
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.suscriptor',
          ],
        }, { id: 'resetSuscriptorData' });

        // Initiates REST call loading Suscriptor data
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/get_Suscriptor',
          responseType: 'getSuscriptorResponse',
          uriParams: {
            'Suscriptor_Id': suscriptorId,
          },
        }, { id: 'loadSuscriptor' });

        if (!callRestResult.ok) {
          // Shows an error message informing about data load failure
          await Actions.fireNotificationEvent(context, {
            summary: 'Could not load data',
            message: `Could not load data: status ${callRestResult.status}`,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Assigns data loaded by the REST call to the Suscriptor variable
        $page.variables.suscriptor = callRestResult.body;
      }
    }
  }

  return loadSuscriptorChain;
});
