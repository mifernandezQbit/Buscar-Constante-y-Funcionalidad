define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class saveViajeAmostrarChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      // Sets the progress variable to true
      $page.variables.saveViajeAmostrarChainInProgress = true;

      try {
        
        // Validates ViajeAmostrar form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'validation-group',
          },
        });

        if (!validateFormResult) {
          return;
        }

        const payload = await this.preparePatchPayload(context, {
          updatedRecord: $page.variables.viajeAmostrar,
          fetchedRecord: $page.variables.fetchedViajeAmostrar,
        });

        if (payload === undefined) {
          // Return from the action chain when there are no changes to save
          return;
        }

        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/update_ViajeAmostrar',
          body: payload,
          uriParams: {
            'ViajeAmostrar_Id': $page.variables.viajeAmostrarId,
          },
        }, { id: 'saveViajeAmostrar' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not update ViajeAmostrar: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
            summary: 'Error al guardar',
            message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'EDITAR_OK',
            funcionalidad: 'CONFIGURAR_VIAJES_MOSTRAR',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            transaccion:
              ($page.variables.viajeAmostrar.viajeAmostrarId ?? "") + "|" +
              ($page.variables.viajeAmostrar.titulo ?? "") + "|" +
              ($page.variables.viajeAmostrar.estado ?? ""),
          },
        });

        await Actions.fireNotificationEvent(context, {
          summary: 'ViajeAmostrar guardado',
          message: 'Registro actualizado correctamente',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        await Actions.navigateBack(context, {}, { id: 'navigateBack' });
      } finally {
        // Sets the progress variable to false
        $page.variables.saveViajeAmostrarChainInProgress = false;
      }
    }

    /**
     * Prepares PATCH endpoint payload, calculates changed fields.
     * @param {any} updatedRecord
     * @param {any} fetchedRecord
     * @return {any} calculated payload
     */
    async preparePatchPayload(context, { updatedRecord, fetchedRecord }) {
      let payload = updatedRecord;
      let hasChanges = true;
      if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
        // filter the object to only those top-level fields that differ from the original fetched record
        payload = Object.fromEntries(Object.entries(payload).filter(([field, value]) =>
          JSON.stringify(value) !== JSON.stringify(fetchedRecord?.[field])
        ));
        hasChanges = Object.keys(payload).length > 0;
      }

      if (!hasChanges) {
        payload = undefined;
      }

      return payload;
    }

  }

  return saveViajeAmostrarChain;
});
