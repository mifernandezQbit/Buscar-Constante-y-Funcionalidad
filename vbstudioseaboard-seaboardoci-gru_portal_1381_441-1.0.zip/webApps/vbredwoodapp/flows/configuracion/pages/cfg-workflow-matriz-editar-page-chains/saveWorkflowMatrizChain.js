define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class saveWorkflowMatrizChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Sets the progress variable to true
      $variables.saveWorkflowMatrizChainInProgress = true;

      try {
        // Validates WorkflowMatriz form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'validation-group',
          },
        });

        if (!validateFormResult) {
          return;
        }

        const payload = await this.preparePatchPayload(context, {
          updatedRecord: $variables.workflowMatriz,
          fetchedRecord: $variables.fetchedWorkflowMatriz,
        });

        if (payload === undefined) {
          // Return from the action chain when there are no changes to save
          return;
        }

        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/update_WorkflowMatriz',
          body: payload,
          uriParams: {
            'WorkflowMatriz_Id': $variables.workflowMatrizId,
          },
        }, { id: 'saveWorkflowMatriz' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not update WorkflowMatriz: status ${callRestResult.status}`;

          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
            summary: 'Error al guardar',
            message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Guardar log
        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'EDITAR_OK',
            funcionalidad: 'CONFIGURAR_WORKFLOW_MATRIZ',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            transaccion:$variables.workflowMatrizId
          },
        });
        
        await Actions.fireNotificationEvent(context, {
          summary: 'WorkflowMatriz guardado',
          message: 'WorkflowMatriz correctamente actualizado',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        await Actions.navigateBack(context, {}, { id: 'navigateBack' });

      } finally {
        // Sets the progress variable to false
        $variables.saveWorkflowMatrizChainInProgress = false;
      }
    }

    /**
     * Prepares PATCH endpoint payload, calculates changed fields.
     * @param {any} updatedRecord
     * @param {any} fetchedRecord
     * @return {any} calculated payload
     */
    async preparePatchPayload(context, { updatedRecord, fetchedRecord }) {
      let payload = updatedRecord;
      let hasChanges = true;

      if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
        // filter the object to only those top-level fields that differ from the original fetched record
        payload = Object.fromEntries(
          Object.entries(payload).filter(([field, value]) =>
            JSON.stringify(value) !== JSON.stringify(fetchedRecord?.[field])
          )
        );

        hasChanges = Object.keys(payload).length > 0;
      }

      if (!hasChanges) {
        payload = undefined;
      }

      return payload;
    }

  }

  return saveWorkflowMatrizChain;
});