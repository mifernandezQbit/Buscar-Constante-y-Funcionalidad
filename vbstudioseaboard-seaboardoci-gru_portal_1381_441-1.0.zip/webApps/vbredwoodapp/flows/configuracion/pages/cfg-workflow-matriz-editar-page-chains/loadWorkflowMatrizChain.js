define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadWorkflowMatrizChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Verificar permisos
      const verificarPermisos = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: 'CONFIGURAR_WORKFLOW_MATRIZ',
        },
      });

      if (!verificarPermisos.existe) {

        // Registrar intento de ingreso sin permisos
        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'INTENTO_INGRESO_NH',
            funcionalidad: 'CONFIGURAR_WORKFLOW_MATRIZ',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
          },
        });

        await Actions.navigateToFlow(context, {
          flow: 'main',
          target: 'parent',
          page: 'acceso-no-autorizado',
        });

        return;
      }

      // Registrar ingreso
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'INGRESA',
          funcionalidad: 'CONFIGURAR_WORKFLOW_MATRIZ',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
        },
      });

      // Cargar WorkflowMatriz
      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_WorkflowMatriz',
        responseType: 'getWorkflowMatrizResponse',
        uriParams: {
          'WorkflowMatriz_Id': $variables.workflowMatrizId,
        },
      }, { id: 'loadWorkflowMatriz' });

      if (!callRestResult.ok) {
        const errorMessage =
          callRestResult.body?.detail ||
          callRestResult.body?.['o:errorDetails']?.[0]?.detail ||
          `Could not load data: status ${callRestResult.status}`;

        await Actions.fireNotificationEvent(context, {
          summary: 'Could not load data',
          message: errorMessage,
        }, { id: 'fireErrorNotification' });

        return;
      }

      $variables.fetchedWorkflowMatriz = callRestResult.body;
      $variables.workflowMatriz = $variables.fetchedWorkflowMatriz;
      $variables.workflowMatrizETag = callRestResult.headers.get('ETag');
    }
  }

  return loadWorkflowMatrizChain;
});