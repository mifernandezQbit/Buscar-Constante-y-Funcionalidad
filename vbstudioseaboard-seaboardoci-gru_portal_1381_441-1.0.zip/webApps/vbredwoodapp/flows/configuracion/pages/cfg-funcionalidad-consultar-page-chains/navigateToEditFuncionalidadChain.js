define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditFuncionalidadChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.funcionalidadId
     */
    async run(context, { funcionalidadId }) {
      const { $page, $flow, $application } = context;
           const guardarLog2 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
                  funcionalidad: 'CONFIGURAR_FUNCIONALIDAD',
                  accion: 'EDITAR',
                  pagina: $flow.currentPage,
                  proveedor: $application.variables.user.esProveedor,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  numeroAn8: $application.variables.user.numeroAn8,
                  transaccion: funcionalidadId,
                  roles: $application.variables.userRoles.userRolesSt,
                },
          });
      const navigateToPageCfgFuncionalidadEditarResult = await Actions.navigateToPage(context, {
        page: 'cfg-funcionalidad-editar',
        params: {
          funcionalidadId: funcionalidadId,
        },
      });
    }
  }

  return navigateToEditFuncionalidadChain;
});
