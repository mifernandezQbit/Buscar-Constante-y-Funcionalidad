define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable2459431071ChangeSelectionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.funcionalidadId
     */
    async run(context, { funcionalidadId }) {
      const { $page, $flow, $application } = context;
      $page.variables.oj_table_245943107_1SelectedId = funcionalidadId;
    }
  }

  return ojTable2459431071ChangeSelectionChain;
});
