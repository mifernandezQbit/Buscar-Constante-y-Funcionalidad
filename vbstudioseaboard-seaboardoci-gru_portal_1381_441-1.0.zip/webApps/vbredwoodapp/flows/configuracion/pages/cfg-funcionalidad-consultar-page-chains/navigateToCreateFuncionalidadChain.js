define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToCreateFuncionalidadChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;
           const guardarLog2 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
                  funcionalidad: 'CONFIGURAR_FUNCIONALIDAD',
                  accion: 'CREAR', // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
                  pagina: $flow.currentPage,
                  proveedor: $application.variables.user.esProveedor,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  numeroAn8: $application.variables.user.numeroAn8,
                  roles: $application.variables.userRoles.userRolesSt,
                },
          });
      const navigateToPageCfgFuncionalidadAgregarResult = await Actions.navigateToPage(context, {
        page: 'cfg-funcionalidad-agregar',
        params: {},
      });
    }
  }

  return navigateToCreateFuncionalidadChain;
});
