define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actConfirmar extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { params, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      let actualizadas = "";
      if ($variables.activar === undefined) {

        const notificarError = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            descripcion: 'Debe indicar si desea activar o desactivar las funcionalidades elegidas',
            tipoNotificacion: 'error',
            titulo: 'Se debe elegir una acción',
          },
        });
      } else {
        // iterar funcionalidades elegidas y por cada una actualizar campo 'desactivada' en tabla funcionalidad
        //let desactivar= $variables.activar ==="1" ? false: true;
        let desactivar = $variables.activar === "1" ? false : true;

        const results = await ActionUtils.forEach($variables.funcionalidadesElegidas, async (item, index) => {
          const response = await Actions.callRest(context, {
            endpoint: 'businessObjects/update_Funcionalidad',
            uriParams: {
              'Funcionalidad_Id': item,
              fields: 'desactivada',
            },
            body: {
              desactivada: desactivar,
            },
          });
          actualizadas = actualizadas + " - " + item;
        }, { mode: 'serial' });

        const notificarError2 = await Actions.callChain(context, {
          chain: 'application:notificar_error',
          params: {
            descripcion: actualizadas,
            titulo: 'Se actualizaron las siguientes funcionalidades',
            tipoNotificacion: 'info',
          },
        });

        // P286: Ajuste Tabla Historica de Acciones
        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: $variables.activar === "1" ? "ACTIVAR_OK" : "DESACTIVAR_OK",
            funcionalidad: 'CONFIGURAR_FUNCIONALIDAD',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            transaccion: actualizadas ?? "",
          },
        });

        await Actions.resetVariables(context, {
          variables: [
            '$variables.activar',
            '$variables.funcionalidadesElegidas',
          ],
        });

        await Actions.fireDataProviderEvent(context, {
          refresh: null,
          target: $variables.funcionalidadListSDP,
        });



        const activarDesactivarClose = await Actions.callComponentMethod(context, {
          selector: '#activarDesactivar',
          method: 'close',
        });

      }
    }
  }

  return actConfirmar;
});
