define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToFuncionalidadDetailChain2 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.funcionalidadId
     */
    async run(context, { funcionalidadId }) {
      const { $page, $flow, $application } = context;
      const navigateToPageConfiguracionFuncionalidadDetailResult = await Actions.navigateToPage(context, {
        page: 'configuracion-funcionalidad-detail',
        params: {
          funcionalidadId: funcionalidadId,
        },
      });
    }
  }

  return navigateToFuncionalidadDetailChain2;
});
