define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBuscar extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
             
      $page.variables.criterioBusqueda = [{
          attribute: 'suscriptorID',
          op: '$eq',
          value: $application.variables.suscriptor.id,
      }];
      if (($page.variables.incluidoFiltro !== undefined) && ($page.variables.incluidoFiltro !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'incluirEnMenu',
          op: '$eq',
          value: $page.variables.incluidoFiltro ,
        });
      }
      if (($page.variables.usadaPor !== undefined) && ($page.variables.usadaPor !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'usadaPor',
          op: '$eq',
          value: $page.variables.usadaPor ,
        });
      }
     
      if (($page.variables.tipoObjetoChat !== undefined) && ($page.variables.tipoObjetoChat !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'tipoObjetoChat',
          op: '$eq',
          value: $page.variables.tipoObjetoChat ,
        });
      }
      if (($page.variables.funcionalidad !== undefined) && ($page.variables.funcionalidad !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'funcionalidad',
          op: '$co',
          value: $page.variables.funcionalidad ,
        });
      }

      // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'BUSCAR',
          funcionalidad: 'CONFIGURAR_FUNCIONALIDAD',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion:
            ($page.variables.funcionalidad ?? "") + "|" +
            ($page.variables.usadaPor ?? "") + "|" +
            ($page.variables.tipoObjetoChat ?? "") + "|" +
            ($page.variables.incluidoFiltro ?? ""),
        },
      });
    }
  }

  return actBuscar;
});
