define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToFuncionalidadDetailChain3 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.funcionalidadId
     */
    async run(context, { funcionalidadId }) {
      const { $page, $flow, $application } = context;

      // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'VER_DETALLE',
          funcionalidad: 'CONFIGURAR_FUNCIONALIDAD',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion: funcionalidadId ?? "",
        },
      });
      
      const navigateToPageCfgFuncionalidadRevisarResult = await Actions.navigateToPage(context, {
        page: 'cfg-funcionalidad-revisar',
        params: {
          funcionalidadId: funcionalidadId,
        },
      });
    }
  }

  return navigateToFuncionalidadDetailChain3;
});
