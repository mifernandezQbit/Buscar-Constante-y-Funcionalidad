define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actCerrarDialogo extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$variables.activar',
    '$variables.funcionalidadesElegidas',
  ],
      });

      const activarDesactivarClose = await Actions.callComponentMethod(context, {
        selector: '#activarDesactivar',
        method: 'close',
      });
    }
  }

  return actCerrarDialogo;
});
