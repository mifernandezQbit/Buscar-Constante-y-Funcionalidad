define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadSeguridadJdeChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_SeguridadJde',
        responseType: 'getSeguridadJdeResponse',
        uriParams: {
          'SeguridadJde_Id': $variables.seguridadJdeId,
        },
      }, { id: 'loadSeguridadJde' });

      if (!callRestResult.ok) {
        // Create error message
        const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not load data: status ${callRestResult.status}`;
        // Fires a notification event about failed load
        await Actions.fireNotificationEvent(context, {
          summary: 'Could not load data',
          message: errorMessage,
        }, { id: 'fireErrorNotification' });

        return;
      }

      $variables.fetchedSeguridadJde = callRestResult.body;
      $variables.seguridadJde = $variables.fetchedSeguridadJde;
      $variables.seguridadJdeETag = callRestResult.headers.get('ETag');
    }
  }

  return loadSeguridadJdeChain;
});
