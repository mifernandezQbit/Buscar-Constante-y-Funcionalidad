define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditTipoChatChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.tipoChatId
     */
    async run(context, { tipoChatId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

       const guardarLog2 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
                  funcionalidad: 'CONFIGURAR_TIPO_CHAT',
                  accion: 'EDITAR',
                  pagina: $flow.currentPage,
                  proveedor: $application.variables.user.esProveedor,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  numeroAn8: $application.variables.user.numeroAn8,
                  transaccion: tipoChatId ,
                  roles: $application.variables.userRoles.userRolesSt,
                },
          });
      const navigateToPageConfiguracionEditarTipoChatResult = await Actions.navigateToPage(context, {
        page: 'configuracion-editar-tipo-chat',
        params: {
          tipoChatId: tipoChatId,
        },
      });
    }
  }

  return navigateToEditTipoChatChain;
});
