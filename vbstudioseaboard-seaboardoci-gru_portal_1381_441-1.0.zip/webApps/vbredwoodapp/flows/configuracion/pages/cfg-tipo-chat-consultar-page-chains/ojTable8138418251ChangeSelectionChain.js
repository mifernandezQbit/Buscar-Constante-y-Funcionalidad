define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable8138418251ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.tipoChatId
     */
    async run(context, { tipoChatId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $variables.oj_table_813841825_1SelectedId = tipoChatId;
    }
  }

  return ojTable8138418251ChangeSelectionChain;
});
