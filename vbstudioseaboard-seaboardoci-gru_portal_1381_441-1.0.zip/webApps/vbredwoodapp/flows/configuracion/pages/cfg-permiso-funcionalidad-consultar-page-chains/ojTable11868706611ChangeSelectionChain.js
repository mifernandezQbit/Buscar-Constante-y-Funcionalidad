define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable11868706611ChangeSelectionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.permisoFuncionalidadId
     */
    async run(context, { permisoFuncionalidadId }) {
      const { $page, $flow, $application } = context;
      $page.variables.oj_table_1186870661_1SelectedId = permisoFuncionalidadId;
    }
  }

  return ojTable11868706611ChangeSelectionChain;
});
