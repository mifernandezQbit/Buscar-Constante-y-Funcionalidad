define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class deletePermisoFuncionalidadChain2 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.permisoFuncionalidadId 
     */
    async run(context, { permisoFuncionalidadId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const guardarLog2 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
                  funcionalidad: 'CONFIGURAR_PERMISO_FUNCIONALIDAD',
                  accion: 'ELIMINAR',// P286: Ajuste Tabla Historica de Acciones -
                  pagina: $flow.currentPage,
                  proveedor: $application.variables.user.esProveedor,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  numeroAn8: $application.variables.user.numeroAn8,
                  transaccion: permisoFuncionalidadId ,
                  roles: $application.variables.userRoles.userRolesSt,
                },
          });


      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/delete_PermisoFuncionalidad',
        uriParams: {
          'PermisoFuncionalidad_Id': permisoFuncionalidadId,
        },
      }, { id: 'deletePermisoFuncionalidad' });

      if (!callRestResult.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Delete failed',
          message: `Could not delete data: status ${callRestResult.status}`,
          displayMode: 'persist',
          type: 'error',
        }, { id: 'fireErrorNotification' });

        return;
      }
 await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
                  funcionalidad: 'CONFIGURAR_PERMISO_FUNCIONALIDAD',
                  accion: 'ELIMINAR_OK',// P286: Ajuste Tabla Historica de Acciones -
                  pagina: $flow.currentPage,
                  proveedor: $application.variables.user.esProveedor,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  numeroAn8: $application.variables.user.numeroAn8,
                  transaccion: permisoFuncionalidadId ,
                  roles: $application.variables.userRoles.userRolesSt,
                },
          });
      // Resets selection variable
      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.oj_table_1186870661_2SelectedId',
        ],
      }, { id: 'resetSelection' });

      await Actions.fireDataProviderEvent(context, {
        target: $variables.permisoFuncionalidadListSDP3,
        refresh: null,
      }, { id: 'refreshDataProvider' });

      await Actions.fireNotificationEvent(context, {
        summary: 'PermisoFuncionalidad eliminada',
        message: `PermisoFuncionalidad [${permisoFuncionalidadId}] eliminada correctamente`,
        displayMode: 'transient',
        type: 'confirmation',
      }, { id: 'fireSuccessNotification' });
    }
  }

  return deletePermisoFuncionalidadChain2;
});
