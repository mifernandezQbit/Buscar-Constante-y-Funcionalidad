define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable11868706612ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.permisoFuncionalidadId
     */
    async run(context, { permisoFuncionalidadId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $variables.oj_table_1186870661_2SelectedId = permisoFuncionalidadId;
    }
  }

  return ojTable11868706612ChangeSelectionChain;
});
