define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getall_PermisoFuncionalidadFetch extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{hookHandler:'vb/RestHookHandler'}} params.configuration
     */
    async run(context, { configuration }) {
      const { $page, $flow, $application } = context;
      const callRestEndpoint1 = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_PermisoFuncionalidad',
        uriParams: {
          limit: 1000,
        },
        responseType: 'getallPermisoFuncionalidadResponse',
        requestTransformOptions: {
          filter: {
            op: 'eq',
            attribute: 'suscriptorID',
            value: $application.variables.suscriptor.id,
          },
        },
        hookHandler: configuration.hookHandler,
        requestType: 'json',
      });

      return callRestEndpoint1;
    }
  }

  return getall_PermisoFuncionalidadFetch;
});
