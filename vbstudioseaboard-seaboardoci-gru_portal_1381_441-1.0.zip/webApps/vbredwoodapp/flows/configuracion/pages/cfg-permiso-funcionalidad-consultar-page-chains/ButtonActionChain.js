define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context, { configuration }) {
      const { $page, $flow, $application, $constants, $variables, $eq, $co } = context;
//funcionalidad

      $variables.criterioBusqueda = [{
          attribute: 'suscriptorID',
          op: '$eq',
          value: $application.variables.suscriptor.id,
      }];
      if (($page.variables.funcionalidad !== undefined) && ($page.variables.funcionalidad !== "")) {
        $variables.criterioBusqueda.push({
          attribute: 'funcionalidadID',
          op: '$eq',
          value: $page.variables.funcionalidad ,
        });
      }
      if (($page.variables.rol !== undefined) && ($page.variables.rol !== "")) {
        $variables.criterioBusqueda.push({
          attribute: 'rolID',
          op: '$eq',
          value: $page.variables.rol ,
        });
      }
      if (($page.variables.incluirMenu !== undefined) && ($page.variables.incluirMenu !== "")) {
        $variables.criterioBusqueda.push({
          attribute: 'rolID',
          op: '$eq',
          value: $page.variables.incluirMenu ,
        });
      }

      // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'BUSCAR',
          funcionalidad: 'CONFIGURAR_PERMISO_FUNCIONALIDAD',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion:
            ($page.variables.funcionalidad ?? "") + "|" +
            ($page.variables.rol ?? "") + "|" +
            ($page.variables.incluirMenu ?? ""),
        },
      });
      //let criterioBusqueda =   "suscriptorID = "+ $application.variables.suscriptor.id +""
      //criterioBusqueda +=    " and funcionalidadID like '%"+$page.variables.funcionalidad.value +"%' "
      //const callRestEndpoint1 = await Actions.callRest{
      //  endpoint: 'businessObjects/getall_PermisoFuncionalidad',
      //  uriParams: {$page.variables.funcionalidad.value
      //    limit: 1000,
      //    q: criterioBusqueda,
      //  },
      //  responseType: 'getallPermisoFuncionalidadResponse',
      //  requestTransformOptions: {
      //    filter: criterioBusqueda,
      //  },
      //  hookHandler: configuration.hookHandler,
      //  requestType: 'json',
      //}',
      //});
      
      
     
      //const callRestEndpoint1 = await Actions.callRest(context, {
      //    endpoint: 'businessObjects/getall_PermisoFuncionalidad',
      //    uriParams: {
      //        //q: $application.variables.q,
      //        q: criterioBusqueda, // Ajuste CJC
      //        limit: 1000,
      //    },
      //    requestType: 'json',
      //});
//
//
      //$page.variables.permisoFuncionalidadListSDP = callRestEndpoint1.body.items;
      //await Actions.fireDataProviderEvent(context, {
      //  target: $page.variables.permisoFuncionalidadListSDP,
      //  refresh: null,
      //}, { id: 'refreshDataProvider' });
      //const callRestEndpoint1 = await Actions.callRest(context, {
      //  endpoint: 'businessObjects/getall_PermisoFuncionalidad',
      //  uriParams: {
      //    limit: 1000,
      //    q: criterioBusqueda,
      //  },
      //  responseType: 'getallPermisoFuncionalidadResponse',
      // //requestTransformOptions: {
      // //  filter: {
      // //    op: 'eq',
      // //    attribute: 'suscriptorID',
      // //    value: $application.variables.suscriptor.id,
      // //  },
      // //},
      //  //hookHandler: configuration.hookHandler,
      //  requestType: 'json',
      //});

    }
  }

  return ButtonActionChain;
});
