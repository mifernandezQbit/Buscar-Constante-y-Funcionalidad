define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditPermisoFuncionalidadChain2 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.permisoFuncionalidadId
     */
    async run(context, { permisoFuncionalidadId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
            
             const guardarLog2 = await Actions.callChain(context, {
               chain: 'application:guardar_log',
               params: {
                 funcionalidad: 'CONFIGURAR_PERMISO_FUNCIONALIDAD',
                 accion: 'EDITAR',
                 pagina: $flow.currentPage,
                 proveedor: $application.variables.user.esProveedor,
                 suscriptorId: $application.variables.suscriptor.id,
                 usuario: $application.variables.user.ociUser,
                 numeroAn8: $application.variables.user.numeroAn8,
                 transaccion:permisoFuncionalidadId,
                 roles: $application.variables.userRoles.userRolesSt,
               },
             });
      const navigateToPageCfgPermisoFuncionalidadEditar2Result = await Actions.navigateToPage(context, {
        page: 'cfg-permiso-funcionalidad-editar2',
        params: {
          permisoFuncionalidadId: permisoFuncionalidadId,
        },
      });
    }
  }

  return navigateToEditPermisoFuncionalidadChain2;
});
