define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable5056264001ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.viajeAmostrarId
     */
    async run(context, { viajeAmostrarId }) {
      const { $page, $flow, $application } = context;
      $page.variables.oj_table_505626400_1SelectedId = viajeAmostrarId;
    }
  }

  return ojTable5056264001ChangeSelectionChain;
});
