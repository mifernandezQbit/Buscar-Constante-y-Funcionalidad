define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class deleteViajeAmostrarChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.viajeAmostrarId 
     */
    async run(context, { viajeAmostrarId }) {
      const { $page, $flow, $application } = context;
       const guardarLog2 = await Actions.callChain(context, {
         chain: 'application:guardar_log',
         params: {
           funcionalidad: 'CONFIGURAR_VIAJES_MOSTRAR',
           accion: 'ELIMINAR',
           pagina: $flow.currentPage,
           proveedor: $application.variables.user.esProveedor,
           suscriptorId: $application.variables.suscriptor.id,
           usuario: $application.variables.user.ociUser,
           numeroAn8: $application.variables.user.numeroAn8,
           transaccion: [[$application.variables.selectedCompany.company]] + '|' + [[viajeAmostrarId]],
           roles: $application.variables.userRoles.userRolesSt,
         },
       });


      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/delete_ViajeAmostrar',
        uriParams: {
          'ViajeAmostrar_Id': viajeAmostrarId,
        },
      }, { id: 'deleteViajeAmostrar' });

      if (!callRestResult.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Error al eliminar',
          message: `No pudo eliminar el registro: estado ${callRestResult.status}`,
          displayMode: 'persist',
          type: 'error',
        }, { id: 'fireErrorNotification' });

        return;
      }

await Actions.callChain(context, {
         chain: 'application:guardar_log',
         params: {
           funcionalidad: 'CONFIGURAR_VIAJES_MOSTRAR',
           accion: 'ELIMINAR_OK',
           pagina: $flow.currentPage,
           proveedor: $application.variables.user.esProveedor,
           suscriptorId: $application.variables.suscriptor.id,
           usuario: $application.variables.user.ociUser,
           numeroAn8: $application.variables.user.numeroAn8,
           transaccion: viajeAmostrarId,
           roles: $application.variables.userRoles.userRolesSt,
         },
       });

      // Resets selection variable
      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.oj_table_505626400_1SelectedId',
        ],
      }, { id: 'resetSelection' });

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.viajeAmostrarListSDP,
        refresh: null,
      }, { id: 'refreshDataProvider' });

      await Actions.fireNotificationEvent(context, {
        summary: 'ViajeAmostrar eliminada',
        message: `ViajeAmostrar [${viajeAmostrarId}] eliminada correctamente`,
        displayMode: 'transient',
        type: 'confirmation',
      }, { id: 'fireSuccessNotification' });
    }
  }

  return deleteViajeAmostrarChain;
});
