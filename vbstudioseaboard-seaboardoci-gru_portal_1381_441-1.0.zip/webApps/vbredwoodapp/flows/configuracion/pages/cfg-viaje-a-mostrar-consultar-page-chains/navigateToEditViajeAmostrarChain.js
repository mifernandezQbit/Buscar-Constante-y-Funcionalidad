define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditViajeAmostrarChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.viajeAmostrarId
     */
    async run(context, { viajeAmostrarId }) {
      const { $page, $flow, $application } = context;

      // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'EDITAR',
          funcionalidad: 'CONFIGURAR_VIAJES_MOSTRAR',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion: viajeAmostrarId,
        },
      });

      const navigateToPageCfgViajeAMostrarEditarResult = await Actions.navigateToPage(context, {
        page: 'cfg-viaje-a-mostrar-editar',
        params: {
          viajeAmostrarId: viajeAmostrarId,
        },
      });
    }
  }

  return navigateToEditViajeAmostrarChain;
});
