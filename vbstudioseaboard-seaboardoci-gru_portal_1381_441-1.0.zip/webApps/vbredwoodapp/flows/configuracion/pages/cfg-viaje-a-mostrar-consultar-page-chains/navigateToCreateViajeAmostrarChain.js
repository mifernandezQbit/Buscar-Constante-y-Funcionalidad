define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToCreateViajeAmostrarChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;
             const guardarLog2 = await Actions.callChain(context, {
               chain: 'application:guardar_log',
               params: {
                 funcionalidad: 'CONFIGURAR_VIAJES_MOSTRAR',
                 accion: 'CREAR',
                 pagina: $flow.currentPage,
                 proveedor: $application.variables.user.esProveedor,
                 suscriptorId: $application.variables.suscriptor.id,
                 usuario: $application.variables.user.ociUser,
                 numeroAn8: $application.variables.user.numeroAn8,
                 roles: $application.variables.userRoles.userRolesSt,
               },
             });

      const navigateToPageCfgViajeAMostrarAgregarResult = await Actions.navigateToPage(context, {
        page: 'cfg-viaje-a-mostrar-agregar',
        params: {},
      });
    }
  }

  return navigateToCreateViajeAmostrarChain;
});
