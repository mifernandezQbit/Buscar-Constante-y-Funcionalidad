define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable10140744871ChangeSelectionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.menuId
     */
    async run(context, { menuId }) {
      const { $page, $flow, $application } = context;
      $page.variables.oj_table_1014074487_1SelectedId = menuId;
    }
  }

  return ojTable10140744871ChangeSelectionChain;
});
