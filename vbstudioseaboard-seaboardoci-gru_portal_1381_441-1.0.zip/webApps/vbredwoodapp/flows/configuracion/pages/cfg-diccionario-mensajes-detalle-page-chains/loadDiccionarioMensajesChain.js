define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadDiccionarioMensajesChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_DiccionarioMensajes',
        responseType: 'getDiccionarioMensajesResponse',
        uriParams: {
          'DiccionarioMensajes_Id': $variables.diccionarioMensajesId,
        },
      }, { id: 'loadDiccionarioMensajes' });

      if (!callRestResult.ok) {
        await Actions.fireNotificationEvent(context, {
          message: 'No se pudieron cargar los datos: estado ' + callRestResult.status,
          displayMode: 'persist',
          type: 'error',
          summary: 'No se pudieron cargar los datos',
        }, { id: 'fireErrorNotification' });

        return;
      }

      $variables.diccionarioMensajes = callRestResult.body;
    }
  }

  return loadDiccionarioMensajesChain;
});
