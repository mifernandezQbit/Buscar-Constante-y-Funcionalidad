define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $page.variables.criterioBusqueda = [{
          attribute: 'suscriptorID',
          op: '$eq',
          value: $application.variables.suscriptor.id,
      }];
      if (($page.variables.workflow !== undefined) && ($page.variables.workflow !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'workflow',
          op: '$co',
          value: $page.variables.workflow ,
        });
      }
      if (($page.variables.rol !== undefined) && ($page.variables.rol !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'rolID',
          op: '$eq',
          value: $page.variables.rol ,
        });
      }
      if (($page.variables.nodo !== undefined) && ($page.variables.nodo !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'nodo',
          op: '$co',
          value: $page.variables.nodo ,
        });
      }
      
      // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'BUSCAR',
          funcionalidad: 'CONFIGURAR_WORKFLOW_NODO',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion:
            ($page.variables.workflow ?? "") + "|" +
            ($page.variables.rol ?? "") + "|" +
            ($page.variables.nodo ?? ""),
        },
      });

    }
  }

  return ButtonActionChain;
});
