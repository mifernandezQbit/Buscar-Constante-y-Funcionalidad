define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class idWorkflowNodeChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.workflowNodoId
     */
    async run(context, { workflowNodoId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.IdWorkflowNodeSelectedId = workflowNodoId;
    }
  }

  return idWorkflowNodeChangeSelectionChain;
});
