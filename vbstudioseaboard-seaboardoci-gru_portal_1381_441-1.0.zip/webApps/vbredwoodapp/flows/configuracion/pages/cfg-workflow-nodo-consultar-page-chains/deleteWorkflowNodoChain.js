define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class deleteWorkflowNodoChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.workflowNodoId
     */
    async run(context, { workflowNodoId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
  // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'ELIMINAR',
          funcionalidad: 'CONFIGURAR_WORKFLOW_NODO',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion: workflowNodoId,
        },
      });

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/delete_WorkflowNodo',
        uriParams: {
          'WorkflowNodo_Id': workflowNodoId,
        },
      }, { id: 'deleteWorkflowNodo' });

      if (!callRestResult.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Falló al eliminar',
          message: `No pudo eliminar el registro: estado ${callRestResult.status}`,
          displayMode: 'persist',
          type: 'error',
        }, { id: 'fireErrorNotification' });

        return;
      }

      // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'ELIMINAR_OK',
          funcionalidad: 'CONFIGURAR_WORKFLOW_NODO',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion: workflowNodoId,
        },
      });

      // Resets selection variable
      await Actions.resetVariables(context, {
        variables: [
          '$variables.IdWorkflowNodeSelectedId',
        ],
      }, { id: 'resetSelection' });

      await Actions.fireDataProviderEvent(context, {
        target: $variables.workflowNodoListSDP,
        refresh: null,
      }, { id: 'refreshDataProvider' });

      await Actions.fireNotificationEvent(context, {
        summary: 'WorkflowNodo deleted',
        message: `WorkflowNodo [${workflowNodoId}] successfully deleted`,
        displayMode: 'transient',
        type: 'confirmation',
      }, { id: 'fireSuccessNotification' });
    }
  }

  return deleteWorkflowNodoChain;
});
