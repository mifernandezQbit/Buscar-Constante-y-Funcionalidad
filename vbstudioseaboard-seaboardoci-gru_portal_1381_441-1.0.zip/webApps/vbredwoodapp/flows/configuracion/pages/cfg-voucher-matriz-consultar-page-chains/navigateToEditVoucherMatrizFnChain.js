define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditVoucherMatrizFnChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.voucherMatrizFnId
     */
    async run(context, { voucherMatrizFnId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
     const guardarLog2 = await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
              funcionalidad: 'CONFIGURAR_VOUCHER_MATRIZ',
              accion: 'EDITAR', // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
              pagina: $flow.currentPage,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
              transaccion: voucherMatrizFnId ,
              roles: $application.variables.userRoles.userRolesSt,
            },
      });
      const navigateToPageCfgVoucherMatrizEditarResult = await Actions.navigateToPage(context, {
        page: 'cfg-voucher-matriz-editar',
        params: {
          voucherMatrizFnId: voucherMatrizFnId,
        },
      });
    }
  }

  return navigateToEditVoucherMatrizFnChain;
});
