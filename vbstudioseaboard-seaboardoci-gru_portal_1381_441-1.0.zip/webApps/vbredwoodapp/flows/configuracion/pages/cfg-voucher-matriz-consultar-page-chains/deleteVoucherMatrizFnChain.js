define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class deleteVoucherMatrizFnChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.voucherMatrizFnId 
     */
    async run(context, { voucherMatrizFnId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          funcionalidad: 'CONFIGURAR_VOUCHER_MATRIZ',
          accion: 'ELIMINAR',
          pagina: $flow.currentPage,
          proveedor: $application.variables.user.esProveedor,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          numeroAn8: $application.variables.user.numeroAn8,
          transaccion: voucherMatrizFnId,
          roles: $application.variables.userRoles.userRolesSt,
        },
      });

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/delete_VoucherMatrizFn',
        uriParams: {
          'VoucherMatrizFn_Id': voucherMatrizFnId,
        },
      }, { id: 'deleteVoucherMatrizFn' });

      if (!callRestResult.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Error al eliminar',
          message: `No pudo eliminar el registro: estado ${callRestResult.status}`,
          displayMode: 'persist',
          type: 'error',
        }, { id: 'fireErrorNotification' });

        return;
      }

      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          funcionalidad: 'CONFIGURAR_VOUCHER_MATRIZ',
          accion: 'ELIMINAR_OK',
          pagina: $flow.currentPage,
          proveedor: $application.variables.user.esProveedor,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          numeroAn8: $application.variables.user.numeroAn8,
          transaccion: voucherMatrizFnId,
          roles: $application.variables.userRoles.userRolesSt,
        },
      });

      // Resets selection variable
      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.oj_table_1150031316_1SelectedId',
        ],
      }, { id: 'resetSelection' });

      await Actions.fireDataProviderEvent(context, {
        target: $variables.voucherMatrizFnListSDP,
        refresh: null,
      }, { id: 'refreshDataProvider' });

      await Actions.fireNotificationEvent(context, {
        summary: 'VoucherMatrizFn eliminada',
        message: `VoucherMatrizFn [${voucherMatrizFnId}] eliminada correctamente`,
        displayMode: 'transient',
        type: 'confirmation',
      }, { id: 'fireSuccessNotification' });
    }
  }

  return deleteVoucherMatrizFnChain;
});
