define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable11500313161ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.voucherMatrizFnId
     */
    async run(context, { voucherMatrizFnId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $variables.oj_table_1150031316_1SelectedId = voucherMatrizFnId;
    }
  }

  return ojTable11500313161ChangeSelectionChain;
});
