define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $page.variables.criterioBusqueda = [{
          attribute: 'suscriptorID',
          op: '$eq',
          value: $application.variables.suscriptor.id,
      }];


      if (($page.variables.tipoDocumento !== undefined) && ($page.variables.tipoDocumento !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'tipoDocARCA',
          op: '$co',
          value: $page.variables.tipoDocumento ,
        });
      }
      if (($page.variables.versionP0411 !== undefined) && ($page.variables.versionP0411 !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'versionP0411',
          op: '$co',
          value: $page.variables.versionP0411 ,
        });
      }
      if (($page.variables.tipoFuncionalidad !== undefined) && ($page.variables.tipoFuncionalidad !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'funcionalidadPortal',
          op: '$eq',
          value: $page.variables.tipoFuncionalidad ,
        });
      }
      
      // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'BUSCAR',
          funcionalidad: 'CONFIGURAR_VOUCHER_MATRIZ',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion:
            ($page.variables.tipoDocumento ?? "") + "|" +
            ($page.variables.versionP0411 ?? "") + "|" +
            ($page.variables.tipoFuncionalidad ?? ""),
        },
      });

    }
  }

  return ButtonActionChain;
});
