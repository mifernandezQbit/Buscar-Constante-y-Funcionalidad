define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class createWorkflowMatrizChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
     

      const verificarPermisos = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: 'CREAR_WORKFLOW_MATRIZ',
        },
      });
      if (verificarPermisos.existe === false) {
        const guardarLog = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'INTENTO_INGRESO_CONFIGURAR_WORKFLOW_MATRIZ',
            funcionalidad: 'CONFIGURAR_WORKFLOW_MATRIZ',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
          },
        });

         const toMain = await Actions.navigateToFlow(context, {
          flow: 'main',
          target: 'parent',
          page: 'acceso-no-autorizado',
        });
      }
      // Sets the progress variable to true
      $variables.createWorkflowMatrizChainInProgress = true;
      $variables.workflowMatriz.accionWF = $variables.accionWFArr[ $variables.workflowMatriz.accionWF].data
      $variables.workflowMatriz.accionJDE = $variables.accionJDEArr[ $variables.workflowMatriz.accionJDE].data
      if ($variables.workflowMatriz.modoNodoInicial != ""){
        $variables.workflowMatriz.modoNodoInicial = $variables.modoInicialArr[ $variables.workflowMatriz.modoNodoInicial].data
      }else{
        $variables.workflowMatriz.modoNodoInicial = ""
      }
      try {
        // Validates WorkflowMatriz form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'validation-group',
          },
        }, { id: 'validateWorkflowMatriz' });

        if (!validateFormResult) {
          return;
        }

        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/create_WorkflowMatriz',
          body: $variables.workflowMatriz,
        }, { id: 'createWorkflowMatriz' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not create new WorkflowMatriz: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
              summary: 'Save failed',
              message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'CREAR_OK',
            funcionalidad: 'CONFIGURAR_WORKFLOW_MATRIZ',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            transaccion: ($variables.workflowMatriz.funcionalidadPortal ?? "") + "|" +
              ($variables.workflowMatriz.accionJDE ?? "") + "|" +
              ($variables.workflowMatriz.accionWF ?? "") + "|" +
              ($variables.workflowMatriz.modoNodoInicial ?? ""),
          },
        });

        await Actions.fireNotificationEvent(context, {
          summary: 'WorkflowMatriz guardado',
          message: 'Registro creado correctamente',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        await Actions.navigateBack(context, {}, { id: 'navigateBack' });
      } finally {
        // Sets the progress variable to false
        $variables.createWorkflowMatrizChainInProgress = false;
      }
    }
  }

  return createWorkflowMatrizChain;
});
