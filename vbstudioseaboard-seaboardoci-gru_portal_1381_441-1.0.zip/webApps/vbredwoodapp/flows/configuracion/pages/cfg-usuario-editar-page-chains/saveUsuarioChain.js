define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class saveUsuarioChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      // Sets the progress variable to true
      $page.variables.saveUsuarioChainInProgress = true;

      try {
        // Validates Usuario form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'validation-group',
          },
        });

        if (!validateFormResult) {
          return;
        }

        const payload = await this.preparePatchPayload(context, {
          updatedRecord: $page.variables.usuario,
          fetchedRecord: $page.variables.fetchedUsuario,
        });

        if (payload === undefined) {
          // Return from the action chain when there are no changes to save
          return;
        }

        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/update_Usuario',
          body: payload,
          uriParams: {
            'Usuario_Id': $page.variables.usuarioId,
          },
        }, { id: 'saveUsuario' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not update Usuario: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
            summary: 'Error al guardar',
            message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'EDITAR_OK',
            funcionalidad: 'CONFIGURAR_USUARIO',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            transaccion:
              ($page.variables.usuario.usuarioId ?? "") + "|" +
              ($page.variables.usuario.nombre ?? "") + "|" +
              ($page.variables.usuario.email ?? "") + "|" +
              ($page.variables.usuario.ociUser ?? "") + "|" +
              ($page.variables.usuario.numeroAn8 ?? "") + "|" +
              ($page.variables.usuario.ciaDefault ?? "") + "|" +
              ($page.variables.usuario.estaActivo ?? "") + "|" +
              ($page.variables.usuario.esProveedor ?? "") + "|" +
              ($page.variables.usuario.aprobado ?? ""),
          },
        });

        await Actions.fireNotificationEvent(context, {
          summary: 'Usuario guardado',
          message: 'Registro creado correctamente',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        await Actions.navigateBack(context, {}, { id: 'navigateBack' });
      } finally {
        // Sets the progress variable to false
        $page.variables.saveUsuarioChainInProgress = false;
      }
    }

    /**
     * Prepares PATCH endpoint payload, calculates changed fields.
     * @param {any} updatedRecord
     * @param {any} fetchedRecord
     * @return {any} calculated payload
     */
    async preparePatchPayload(context, { updatedRecord, fetchedRecord }) {
      let payload = updatedRecord;
      let hasChanges = true;
      if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
        // filter the object to only those top-level fields that differ from the original fetched record
        payload = Object.fromEntries(Object.entries(payload).filter(([field, value]) =>
          JSON.stringify(value) !== JSON.stringify(fetchedRecord?.[field])
        ));
        hasChanges = Object.keys(payload).length > 0;
      }

      if (!hasChanges) {
        payload = undefined;
      }

      return payload;
    }

  }

  return saveUsuarioChain;
});
