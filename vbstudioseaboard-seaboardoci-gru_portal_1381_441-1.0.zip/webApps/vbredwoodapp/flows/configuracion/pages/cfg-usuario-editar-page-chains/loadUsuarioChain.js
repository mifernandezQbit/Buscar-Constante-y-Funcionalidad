define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadUsuarioChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_Usuario',
        responseType: 'getUsuarioResponse',
        uriParams: {
          'Usuario_Id': $page.variables.usuarioId,
        },
      }, { id: 'loadUsuario' });

      if (!callRestResult.ok) {
        // Create error message
        const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not load data: status ${callRestResult.status}`;
        // Fires a notification event about failed load
        await Actions.fireNotificationEvent(context, {
          summary: 'Could not load data',
          message: errorMessage,
        }, { id: 'fireErrorNotification' });

        return;
      }

      $page.variables.fetchedUsuario = callRestResult.body;
      $page.variables.usuario = $page.variables.fetchedUsuario;
      $page.variables.usuarioETag = callRestResult.headers.get('ETag');
    }
  }

  return loadUsuarioChain;
});
