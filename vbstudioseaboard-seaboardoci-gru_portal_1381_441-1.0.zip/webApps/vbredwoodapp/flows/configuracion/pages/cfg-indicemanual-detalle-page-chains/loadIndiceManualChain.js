define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadIndiceManualChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_IndiceManual',
        responseType: 'getIndiceManualResponse',
        uriParams: {
          'IndiceManual_Id': $variables.indiceManualId,
        },
      }, { id: 'loadIndiceManual' });

      if (!callRestResult.ok) {
        await Actions.fireNotificationEvent(context, {
          message: 'Could not load data: status ' + callRestResult.status,
          displayMode: 'persist',
          type: 'error',
          summary: 'Could not load data',
        }, { id: 'fireErrorNotification' });

        return;
      }

      $variables.indiceManual = callRestResult.body;
    }
  }

  return loadIndiceManualChain;
});
