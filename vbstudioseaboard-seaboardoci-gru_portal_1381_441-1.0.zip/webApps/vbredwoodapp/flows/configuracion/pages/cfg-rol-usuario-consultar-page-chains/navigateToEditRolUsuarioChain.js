define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditRolUsuarioChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.rolUsuarioId
     */
    async run(context, { rolUsuarioId }) {
      const { $page, $flow, $application } = context;
      const guardarLog2 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
                  funcionalidad: 'CONFIGURAR_ROL_USUARIO',
                  accion: 'EDITAR', // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
                  pagina: $flow.currentPage,
                  proveedor: $application.variables.user.esProveedor,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  numeroAn8: $application.variables.user.numeroAn8,
                  transaccion:rolUsuarioId,
                  roles: $application.variables.userRoles.userRolesSt,
                },
          });
      const navigateToPageCfgRolUsuarioEditarResult = await Actions.navigateToPage(context, {
        page: 'cfg-rol-usuario-editar',
        params: {
          rolUsuarioId: rolUsuarioId,
        },
      });
    }
  }

  return navigateToEditRolUsuarioChain;
});
