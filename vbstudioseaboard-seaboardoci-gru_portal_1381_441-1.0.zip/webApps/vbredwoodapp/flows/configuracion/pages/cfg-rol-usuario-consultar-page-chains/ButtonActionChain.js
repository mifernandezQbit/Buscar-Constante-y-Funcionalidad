define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */

    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      
          
      $page.variables.criterioBusqueda = [{
          attribute: 'suscriptorID',
          op: '$eq',
          value: $application.variables.suscriptor.id,
      }];

      if (($page.variables.usuarioID !== undefined) && ($page.variables.usuarioID !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'usuarioID',
          op: '$eq',
          value: $page.variables.usuarioID ,
        });
      }
      if (($page.variables.rolID !== undefined) && ($page.variables.rolID !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'rolID',
          op: '$eq',
          value: $page.variables.rolID ,
        });
      }
      if (($page.variables.usuarioOCI !== undefined) && ($page.variables.usuarioOCI !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'usuarioID',
          op: '$eq',
          value: $page.variables.usuarioOCI ,
        });
      }

      // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'BUSCAR',
          funcionalidad: 'CONFIGURAR_ROL_USUARIO',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion:
            ($page.variables.usuarioID ?? "") + "|" +
            ($page.variables.rolID ?? "") + "|" +
            ($page.variables.usuarioOCI ?? ""),
        },
      });
      
    }
     


  }

  return ButtonActionChain;
});
