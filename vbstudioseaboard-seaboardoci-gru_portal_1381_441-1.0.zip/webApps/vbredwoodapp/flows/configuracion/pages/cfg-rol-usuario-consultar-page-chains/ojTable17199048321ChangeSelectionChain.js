define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable17199048321ChangeSelectionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.rolUsuarioId
     */
    async run(context, { rolUsuarioId }) {
      const { $page, $flow, $application } = context;
      $page.variables.oj_table_1719904832_1SelectedId = rolUsuarioId;
    }
  }

  return ojTable17199048321ChangeSelectionChain;
});
