define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class createTipoChatChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Sets the progress variable to true
      $variables.createTipoChatChainInProgress = true;

      try {
        // Validates TipoChat form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'validation-group',
          },
        }, { id: 'validateTipoChat' });

        if (!validateFormResult) {
          return;
        }

        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/create_TipoChat',
          body: $variables.tipoChat,
        }, { id: 'createTipoChat' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not create new TipoChat: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
            summary: 'Falló al guardar',
            message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'CREAR_OK',
            funcionalidad: 'CONFIGURAR_TIPO_CHAT',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            transaccion: callRestResult.body.id + "|" +($variables.tipoChat.tipoObjetoChat ?? "") + "|" +
              ($variables.tipoChat.descripcion ?? "") + "|" +
              ($variables.tipoChat.rolInterlocutorID ?? "") + "|" +
              ($variables.tipoChat.eligeDestinatario ?? ""),
          },
        });

        await Actions.fireNotificationEvent(context, {
          summary: 'Registro guardado',
          message: 'El registro para el tipo de objeto de mensajería se guardó correctamente',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        await Actions.navigateBack(context, {}, { id: 'navigateBack' });
      } finally {
        // Sets the progress variable to false
        $variables.createTipoChatChainInProgress = false;
      }
    }
  }

  return createTipoChatChain;
});
