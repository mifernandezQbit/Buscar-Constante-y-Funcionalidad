define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditIndiceManualChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.indiceManualId
     */
    async run(context, { indiceManualId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const guardarLog2 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
                  funcionalidad: 'CONFIGURAR_GUIA_USO_PORTAL',
                  accion: 'EDITAR', // P286: Ajuste Tabla Historica de Acciones
                  pagina: $flow.currentPage,
                  proveedor: $application.variables.user.esProveedor,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  numeroAn8: $application.variables.user.numeroAn8,
                  transaccion: indiceManualId,
                  roles: $application.variables.userRoles.userRolesSt,
                },
          });

      const navigateToPageCfgIndicemanualEditarResult = await Actions.navigateToPage(context, {
        page: 'cfg-indicemanual-editar',
        params: {
          indiceManualId: indiceManualId,
        },
      });
    }
  }

  return navigateToEditIndiceManualChain;
});
