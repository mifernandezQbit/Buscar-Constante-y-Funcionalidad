define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnConsultar extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $page.variables.criterioBusqueda = [{
          attribute: 'suscriptorID',
          op: '$eq',
          value: $application.variables.suscriptor.id,
      }];
      if (($page.variables.indiceTab !== undefined) && ($page.variables.indiceTab !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'indiceTab',
          op: '$co',
          value: $page.variables.indiceTab ,
        });
      }
      if (($page.variables.indiceTitulo !== undefined) && ($page.variables.indiceTitulo !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'indiceTitulo',
          op: '$co',
          value: $page.variables.indiceTitulo ,
        });
      }
      if (($page.variables.visiblePor !== undefined) && ($page.variables.visiblePor !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'visiblePor',
          op: '$co',
          value: $page.variables.visiblePor ,
        });
      }

      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'BUSCAR',
          funcionalidad: 'CONFIGURAR_GUIA_USO_PORTAL',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion:
            ($page.variables.indiceTab ?? "") + "|" +
            ($page.variables.indiceTitulo ?? "") + "|" +
            ($page.variables.visiblePor ?? ""),
        },
      });
    }
  }
  
  return actBtnConsultar;
});

