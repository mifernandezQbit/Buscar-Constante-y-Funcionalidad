define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable8444828841ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.indiceManualId
     */
    async run(context, { indiceManualId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.oj_table_844482884_1SelectedId = indiceManualId;
    }
  }

  return ojTable8444828841ChangeSelectionChain;
});
