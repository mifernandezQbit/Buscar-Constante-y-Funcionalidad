define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class deleteIndiceManualChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.indiceManualId
     */
    async run(context, { indiceManualId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const guardarLog2 = await Actions.callChain(context, {
            chain: 'application:guardar_log',
            params: {
                  accion: 'ELIMINAR', 
                  funcionalidad: 'CONFIGURAR_GUIA_USO_PORTAL',
                  pagina: $flow.currentPage,
                  proveedor: $application.variables.user.esProveedor,
                  suscriptorId: $application.variables.suscriptor.id,
                  usuario: $application.variables.user.ociUser,
                  numeroAn8: $application.variables.user.numeroAn8,
                  transaccion: indiceManualId,
                  roles: $application.variables.userRoles.userRolesSt,
                },
          });

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/delete_IndiceManual',
        uriParams: {
          'IndiceManual_Id': indiceManualId,
        },
      }, { id: 'deleteIndiceManual' });

      if (!callRestResult.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Falló al eliminar',
          message: `No pudo eliminar el registro: estado ${callRestResult.status}`,
          displayMode: 'persist',
          type: 'error',
        }, { id: 'fireErrorNotification' });

        return;
      }

      // P286: Ajuste Tabla Historica de Acciones
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'ELIMINAR_OK',
          funcionalidad: 'CONFIGURAR_GUIA_USO_PORTAL',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion: indiceManualId,
        },
      });

      // Resets selection variable
      await Actions.resetVariables(context, {
        variables: [
          '$variables.oj_table_844482884_1SelectedId',
        ],
      }, { id: 'resetSelection' });

      await Actions.fireDataProviderEvent(context, {
        target: $variables.indiceManualListSDP,
        refresh: null,
      }, { id: 'refreshDataProvider' });

      await Actions.fireNotificationEvent(context, {
        summary: 'Indice Guia Uso Portal eliminada',
        message: `Indice Guia Uso Portal [${indiceManualId}] eliminada correctamente`,
        displayMode: 'transient',
        type: 'confirmation',
      }, { id: 'fireSuccessNotification' });
    }
  }

  return deleteIndiceManualChain;
});
