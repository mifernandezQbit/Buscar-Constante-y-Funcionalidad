define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable11631012331ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.diccionarioMensajesId
     */
    async run(context, { diccionarioMensajesId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $variables.oj_table_1163101233_1SelectedId = diccionarioMensajesId;
    }
  }

  return ojTable11631012331ChangeSelectionChain;
});
