define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $page.variables.criterioBusqueda = [{
          attribute: 'id',
          op: '$co',
          value: "%%",
      }];
      if (($page.variables.codigo !== undefined) && ($page.variables.codigo !== "")) {
        $variables.criterioBusqueda.push({
          attribute: 'codigo',
          op: '$co',
          value: $page.variables.codigo ,
        });
      }
      if (($page.variables.resumen !== undefined) && ($page.variables.resumen !== "")) {
        $variables.criterioBusqueda.push({
          attribute: 'resumen',
          op: '$co',
          value: $page.variables.resumen ,
        });
      }
      if (($page.variables.tipoNotificacion !== undefined) && ($page.variables.tipoNotificacion !== "")) {
        $variables.criterioBusqueda.push({
          attribute: 'tipoNotificacion',
          op: '$co',
          value: $page.variables.tipoNotificacion ,
        });
      }
      
      // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'BUSCAR',
          funcionalidad: 'CONFIGURAR_DICCIONARIO_MENSAJES',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion:
            ($page.variables.codigo ?? "") + "|" +
            ($page.variables.resumen ?? "") + "|" +
            ($page.variables.tipoNotificacion ?? ""),
        },
      });

    }
  }

  return ButtonActionChain;
});
