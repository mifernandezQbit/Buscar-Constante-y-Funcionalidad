define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditDiccionarioMensajesChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.diccionarioMensajesId
     */
    async run(context, { diccionarioMensajesId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const guardarLog2 = await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
              funcionalidad: 'CONFIGURAR_DICCIONARIO_MENSAJES',
              accion: 'EDITAR', // P286: Ajuste Tabla Historica de Acciones
              pagina: $flow.currentPage,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
              transaccion: diccionarioMensajesId,
              roles: $application.variables.userRoles.userRolesSt,
            },
      });

      const navigateToPageCfgDiccionarioMensajesEditarResult = await Actions.navigateToPage(context, {
        page: 'cfg-diccionario-mensajes-editar',
        params: {
          diccionarioMensajesId: diccionarioMensajesId,
        },
      });
    }
  }

  return navigateToEditDiccionarioMensajesChain;
});
