define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToCreateDiccionarioMensajesChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const guardarLog2 = await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
              funcionalidad: 'CONFIGURAR_DICCIONARIO_MENSAJES',
              accion: 'CREAR', // P286: Ajuste Tabla Historica de Acciones
              pagina: $flow.currentPage,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
              roles: $application.variables.userRoles.userRolesSt,
            },
      });
      const navigateToPageCfgDiccionarioMensajesCrearResult = await Actions.navigateToPage(context, {
        page: 'cfg-diccionario-mensajes-crear',
        params: {},
      });
    }
  }

  return navigateToCreateDiccionarioMensajesChain;
});
