define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class deleteDiccionarioMensajesChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.diccionarioMensajesId 
     */
    async run(context, { diccionarioMensajesId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const guardarLog2 = await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
              funcionalidad: 'CONFIGURAR_DICCIONARIO_MENSAJES',
              accion: 'ELIMINAR', // P286: Ajuste Tabla Historica de Acciones
              pagina: $flow.currentPage,
              proveedor: $application.variables.user.esProveedor,
              suscriptorId: $application.variables.suscriptor.id,
              usuario: $application.variables.user.ociUser,
              numeroAn8: $application.variables.user.numeroAn8,
              transaccion: diccionarioMensajesId,
              roles: $application.variables.userRoles.userRolesSt,
            },
      });

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/delete_DiccionarioMensajes',
        uriParams: {
          'DiccionarioMensajes_Id': diccionarioMensajesId,
        },
      }, { id: 'deleteDiccionarioMensajes' });

      if (!callRestResult.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Falló al eliminar',
          message: `No pudo eliminar el registro: estado ${callRestResult.status}`,
          displayMode: 'persist',
          type: 'error',
        }, { id: 'fireErrorNotification' });

        return;
      }

      // P286: Ajuste Tabla Historica de Acciones
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'ELIMINAR_OK',
          funcionalidad: 'CONFIGURAR_DICCIONARIO_MENSAJES',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion: diccionarioMensajesId,
        },
      });

      // Resets selection variable
      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.oj_table_1163101233_1SelectedId',
        ],
      }, { id: 'resetSelection' });

      await Actions.fireDataProviderEvent(context, {
        target: $variables.diccionarioMensajesListSDP,
        refresh: null,
      }, { id: 'refreshDataProvider' });

      await Actions.fireNotificationEvent(context, {
        summary: 'DiccionarioMensajes eliminada',
        message: `DiccionarioMensajes [${diccionarioMensajesId}] eliminada correctamente`,
        displayMode: 'transient',
        type: 'confirmation',
      }, { id: 'fireSuccessNotification' });
    }
  }

  return deleteDiccionarioMensajesChain;
});
