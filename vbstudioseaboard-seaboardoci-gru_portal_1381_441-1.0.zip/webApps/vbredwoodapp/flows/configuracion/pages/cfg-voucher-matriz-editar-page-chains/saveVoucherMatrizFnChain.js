define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class saveVoucherMatrizFnChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Sets the progress variable to true
      $variables.saveVoucherMatrizFnChainInProgress = true;

      try {
        // Validates VoucherMatrizFn form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'validation-group',
          },
        });

        if (!validateFormResult) {
          return;
        }

        const payload = await this.preparePatchPayload(context, {
          updatedRecord: $variables.voucherMatrizFn,
          fetchedRecord: $variables.fetchedVoucherMatrizFn,
        });

        if (payload === undefined) {
          // Return from the action chain when there are no changes to save
          return;
        }

        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/update_VoucherMatrizFn',
          body: payload,
          uriParams: {
            'VoucherMatrizFn_Id': $variables.voucherMatrizFnId,
          },
        }, { id: 'saveVoucherMatrizFn' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not update VoucherMatrizFn: status ${callRestResult.status}`;
          const notificarError = await Actions.callChain(context, {
            chain: 'application:notificar_error',
            params: {
              descripcion: errorMessage,
              titulo: 'Error al guardar',
              tipoNotificacion: 'error',
              modoVisualizacion: 'persist',
            },
          });

          return;
        }

        // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'EDITAR_OK',
            funcionalidad: 'CONFIGURAR_VOUCHER_MATRIZ',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
            transaccion:
              ($variables.voucherMatrizFnId ?? "") + "|" +
              ($variables.voucherMatrizFn.funcionalidadPortal ?? "") + "|" +
              ($variables.voucherMatrizFn.tipoDocARCA ?? "") + "|" +
              ($variables.voucherMatrizFn.versionP0411 ?? "") + "|" +
              ($variables.voucherMatrizFn.tipoNroVoucher ?? "") + "|" +
              ($variables.voucherMatrizFn.ordenCompra ?? "") + "|" +
              ($variables.voucherMatrizFn.tipoBusqConceptos ?? "") + "|" +
              ($variables.voucherMatrizFn.usaMatrizRetenciones ?? "") + "|" +
              ($variables.voucherMatrizFn.usaMatrizPercepciones ?? "") + "|" +
              ($variables.voucherMatrizFn.validarCAE ?? "") + "|" +
              ($variables.voucherMatrizFn.invertirSigno ?? ""),
          },
        });

        await Actions.fireNotificationEvent(context, {
          summary: 'VoucherMatrizFn guardado',
          message: 'Registro creado correctamente',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        await Actions.navigateBack(context, {}, { id: 'navigateBack' });
      } finally {
        // Sets the progress variable to false
        $variables.saveVoucherMatrizFnChainInProgress = false;
      }
    }

    /**
     * Prepares PATCH endpoint payload, calculates changed fields.
     * @param {any} updatedRecord
     * @param {any} fetchedRecord
     * @return {any} calculated payload
     */
    async preparePatchPayload(context, { updatedRecord, fetchedRecord }) {
      let payload = updatedRecord;
      let hasChanges = true;
      if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
        // filter the object to only those top-level fields that differ from the original fetched record
        payload = Object.fromEntries(Object.entries(payload).filter(([field, value]) =>
          JSON.stringify(value) !== JSON.stringify(fetchedRecord?.[field])
        ));
        hasChanges = Object.keys(payload).length > 0;
      }

      if (!hasChanges) {
        payload = undefined;
      }

      return payload;
    }

  }

  return saveVoucherMatrizFnChain;
});
