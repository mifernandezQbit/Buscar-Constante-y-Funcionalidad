define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class deleteSeguridadJdeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.seguridadJdeId
     */
    async run(context, { seguridadJdeId }) {
      const { $page, $flow, $application, $constants, $variables } = context;


      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: ' ELIMINAR',
          funcionalidad: 'CONFIGURAR_SEGURIDAD_JDE',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion:seguridadJdeId,
        },
      });

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/delete_SeguridadJde',
        uriParams: {
          'SeguridadJde_Id': seguridadJdeId,
        },
      }, { id: 'deleteSeguridadJde' });

      if (!callRestResult.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Fallo al eliminar',
          message: `La fila no pudo ser eliminada: Estado ${callRestResult.status}`,
          displayMode: 'persist',
          type: 'error',
        }, { id: 'fireErrorNotification' });

        return;
      }
else {
      // Resets selection variable
      await Actions.resetVariables(context, {
        variables: [
    '$variables.oj_table_155215774_1SelectedId',
    '$variables.criterioBusqueda',
    '$variables.accionJDE',
    '$variables.accionObjeto',
    '$variables.aliasDD',
    '$variables.funcionalidad',
  ],
      }, { id: 'resetSelection' });

      await Actions.fireDataProviderEvent(context, {
        target: $variables.seguridadJdeListSDP,
        refresh: null,
      }, { id: 'refreshDataProvider' });

      await Actions.fireNotificationEvent(context, {
        summary: 'SeguridadJde eliminada',
        message: `SeguridadJde [${seguridadJdeId}] eliminada correctamente`,
        displayMode: 'transient',
        type: 'confirmation',
      }, { id: 'fireSuccessNotification' });

      // guardar log
        await Actions.callChain(context, {
      chain: 'application:guardar_log',
      params: {
        accion: 'ELIMINAR_OK',
        funcionalidad: 'CONFIGURAR_SEGURIDAD_JDE',
        numeroAn8: $application.variables.user.numeroAn8,
        pagina: $flow.currentPage,
        suscriptorId: $application.variables.suscriptor.id,
        usuario: $application.variables.user.ociUser,
        proveedor: $application.variables.user.esProveedor,
        roles: $application.variables.userRoles.userRolesSt,
        observaciones: "",
        transaccion: seguridadJdeId
      },
    });
    } }
  }

  return deleteSeguridadJdeChain;
});
