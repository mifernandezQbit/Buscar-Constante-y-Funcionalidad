define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const verificarPermisos = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: 'CONFIGURAR_SEGURIDAD_JDE',
        },
      });
      if (verificarPermisos.existe === false) {
        await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'INTENTO_INGRESO_NH',
            funcionalidad: 'CONFIGURAR_SEGURIDAD_JDE',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
          },
        });

       
         const toMain = await Actions.navigateToFlow(context, {
          flow: 'main',
          target: 'parent',
          page: 'acceso-no-autorizado',
        });
      }
      else {
 await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'INGRESA',
            funcionalidad: 'CONFIGURAR_SEGURIDAD_JDE',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
          },
        });
      }
    }
  }

  return PageVbEnterChain;
});
