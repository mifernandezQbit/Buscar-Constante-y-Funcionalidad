define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable1552157741ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.seguridadJdeId
     */
    async run(context, { seguridadJdeId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.oj_table_155215774_1SelectedId = seguridadJdeId;
    }
  }

  return ojTable1552157741ChangeSelectionChain;
});
