define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToCreateSeguridadJdeChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

    await Actions.callChain(context, {
      chain: 'application:guardar_log',
      params: {
        accion: 'CREAR',
        funcionalidad: 'CONFIGURAR_SEGURIDAD_JDE',
        numeroAn8: $application.variables.user.numeroAn8,
        pagina: $flow.currentPage,
        suscriptorId: $application.variables.suscriptor.id,
        usuario: $application.variables.user.ociUser,
        proveedor: $application.variables.user.esProveedor,
        roles: $application.variables.userRoles.userRolesSt,
        observaciones: "",
        transaccion: ""
      },
    });

      const navigateToPageCfgSeguridadJdeAgregarResult = await Actions.navigateToPage(context, {
        page: 'cfg-seguridad-jde-agregar',
        params: {},
      });
    }
  }

  return navigateToCreateSeguridadJdeChain;
});
