define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actBtnBuscar extends ActionChain {

    async run(context) {
      const { $page, $flow, $application } = context;

      $page.variables.criterioBusqueda = [{
        attribute: 'suscriptorID',
        op: '$eq',
        value: $application.variables.suscriptor.id,
      }];

      if ($page.variables.accionJDE) {
        $page.variables.criterioBusqueda.push({
          attribute: 'accionJDE',
          op: '$co',
          value: $page.variables.accionJDE,
        });
      }
      
      if ($page.variables.funcionalidadID) {
        $page.variables.criterioBusqueda.push({
          attribute: 'funcionalidadID',
          op: '$eq',
          value: Number($page.variables.funcionalidadID),
        });
      }

      if ($page.variables.accionObjeto) {
        $page.variables.criterioBusqueda.push({
          attribute: 'accionObjeto',
          op: '$co',
          value: $page.variables.accionObjeto,
        });
      }

      if ($page.variables.aliasDD) {
        $page.variables.criterioBusqueda.push({
          attribute: 'aliasDD',
          op: '$co',
          value: $page.variables.aliasDD,
        });
      }

         if ($page.variables.nombreObjeto) {
        $page.variables.criterioBusqueda.push({
          attribute: 'nombreObjeto',
          op: '$co',
          value: $page.variables.nombreObjeto,
        });
      }

      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'BUSCAR',
          funcionalidad: 'CONFIGURAR_SEGURIDAD_JDE',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion:
            ($page.variables.accionJDE ?? "") + "|" +
            ($page.variables.funcionalidadID ?? "") + "|" +
            ($page.variables.accionObjeto ?? "") + "|" +
            ($page.variables.aliasDD ?? ""),
        },
      });

    }
  }

  return actBtnBuscar;
});