define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class deleteWorkflowMatrizChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.workflowMatrizId
     */
    async run(context, { workflowMatrizId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
  // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'ELIMINAR',
          funcionalidad: 'CONFIGURAR_WORKFLOW_MATRIZ',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion: workflowMatrizId,
        },
      });
      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/delete_WorkflowMatriz',
        uriParams: {
          'WorkflowMatriz_Id': workflowMatrizId,
        },
      }, { id: 'deleteWorkflowMatriz' });

      if (!callRestResult.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Delete failed',
          message: `Could not delete data: status ${callRestResult.status}`,
          displayMode: 'persist',
          type: 'error',
        }, { id: 'fireErrorNotification' });

        return;
      }
   
      // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'ELIMINAR',
          funcionalidad: 'CONFIGURAR_WORKFLOW_MATRIZ',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion: workflowMatrizId,
        },
      });

      // Resets selection variable
      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.oj_table_1362969951_1SelectedId',
        ],
      }, { id: 'resetSelection' });

      await Actions.fireDataProviderEvent(context, {
        target: $variables.workflowMatrizListSDP,
        refresh: null,
      }, { id: 'refreshDataProvider' });

      await Actions.fireNotificationEvent(context, {
        summary: 'WorkflowMatriz eliminada',
        message: `WorkflowMatriz [${workflowMatrizId}] eliminada correctamente`,
        displayMode: 'transient',
        type: 'confirmation',
      }, { id: 'fireSuccessNotification' });
    }
  }

  return deleteWorkflowMatrizChain;
});
