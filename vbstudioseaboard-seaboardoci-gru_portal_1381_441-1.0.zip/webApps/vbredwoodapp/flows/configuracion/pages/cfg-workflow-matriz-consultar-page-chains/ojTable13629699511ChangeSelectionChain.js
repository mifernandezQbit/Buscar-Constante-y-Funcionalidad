define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable13629699511ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.workflowMatrizId
     */
    async run(context, { workflowMatrizId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const verificarPermisos = await Actions.callChain(context, {
        chain: 'application:verificar_permisos_funcionalidad_obj',
        params: {
          funcionalidad: 'CONFIGURAR_WORKFLOW_MATRIZ',
        },
      });
      if (verificarPermisos.existe === false) {
        const guardarLog = await Actions.callChain(context, {
          chain: 'application:guardar_log',
          params: {
            accion: 'INTENTO_INGRESO_WORKFLOW_MATRIZ',
            funcionalidad: 'CONFIGURAR_WORKFLOW_MATRIZ',
            numeroAn8: $application.variables.user.numeroAn8,
            pagina: $flow.currentPage,
            suscriptorId: $application.variables.suscriptor.id,
            usuario: $application.variables.user.ociUser,
            proveedor: $application.variables.user.esProveedor,
            roles: $application.variables.userRoles.userRolesSt,
          },
        });

         const toMain = await Actions.navigateToFlow(context, {
          flow: 'main',
          target: 'parent',
          page: 'acceso-no-autorizado',
        });
      }
      $variables.oj_table_1362969951_1SelectedId = workflowMatrizId;
    }
  }

  return ojTable13629699511ChangeSelectionChain;
});
