define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditWorkflowMatrizChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.workflowMatrizId
     */
    async run(context, { workflowMatrizId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'EDITAR',
          funcionalidad: 'CONFIGURAR_WORKFLOW_MATRIZ',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
        },
      });

      const navigateToPageCfgWorkflowMatrizEditarResult = await Actions.navigateToPage(context, {
        page: 'cfg-workflow-matriz-editar',
        params: {
          workflowMatrizId: workflowMatrizId,
        },
      });
    }
  }

  return navigateToEditWorkflowMatrizChain;
});
