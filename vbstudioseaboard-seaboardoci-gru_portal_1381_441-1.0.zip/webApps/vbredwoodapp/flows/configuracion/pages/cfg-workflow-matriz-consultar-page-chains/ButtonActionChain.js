define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class buttonAction extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $page.variables.criterioBusqueda = [{
          attribute: 'suscriptorID',
          op: '$eq',
          value: $application.variables.suscriptor.id,
      }];

       if (($page.variables.modoInicial !== undefined) && ($page.variables.modoInicial !== "") && ( $page.variables.modoInicial !== null )) {
        $page.variables.criterioBusqueda.push({
          attribute: 'modoNodoInicial',
          op: '$co',
          value: $page.variables.modoInicial  ,
        });
      }
      if (($page.variables.accionJDE !== undefined) && ($page.variables.accionJDE !== "") && ( $page.variables.accionJDE !== null )) {
        $page.variables.criterioBusqueda.push({
          attribute: 'accionJDE',
          op: '$co',
          value: $page.variables.accionJDE  ,
        });
      }

       if (($page.variables.accionWF !== undefined) && ($page.variables.accionWF !== "") && ( $page.variables.accionWF !== null )) {
        $page.variables.criterioBusqueda.push({
          attribute: 'accionWF',
          op: '$co',
          value: $page.variables.accionWF  ,
        });
      }
       if (($page.variables.tipoFuncionalidad !== undefined) &&( $page.variables.tipoFuncionalidad.value !== null )&& ($page.variables.tipoFuncionalidad !== "")) {
        $page.variables.criterioBusqueda.push({
          attribute: 'funcionalidadPortal',
          op: '$eq',
          value: $page.variables.tipoFuncionalidad.value,
        });
      }

      // P286: Ajuste Tabla Historica de Acciones - MN - 27/07/2026
      await Actions.callChain(context, {
        chain: 'application:guardar_log',
        params: {
          accion: 'BUSCAR',
          funcionalidad: 'CONFIGURAR_WORKFLOW_MATRIZ',
          numeroAn8: $application.variables.user.numeroAn8,
          pagina: $flow.currentPage,
          suscriptorId: $application.variables.suscriptor.id,
          usuario: $application.variables.user.ociUser,
          proveedor: $application.variables.user.esProveedor,
          roles: $application.variables.userRoles.userRolesSt,
          transaccion:
            ($page.variables.modoInicial ?? "") + "|" +
            ($page.variables.accionJDE ?? "") + "|" +
            ($page.variables.accionWF ?? "") + "|" +
            ($page.variables.tipoFuncionalidad?.value ?? ""),
        },
});
    }
  }

  return buttonAction;
});
